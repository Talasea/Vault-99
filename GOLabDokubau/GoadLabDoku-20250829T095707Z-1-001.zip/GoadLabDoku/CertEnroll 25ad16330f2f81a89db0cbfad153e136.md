# CertEnroll

Anonymous_Access: None
Attack_Vector: Certificate template enumeration, ESC1/ESC2/ESC3 attacks possible
Comment: Active Directory Certificate Services share
Current_User_Access: READ
GOAD_Context: ADCS Certificate Authority - Template abuse vector
Host_IP: 192.168.20.23
Host_Name: BRAAVOS
Risk_Level: Critical
Share_Type: STYPE_DISKTREE