# All Hosts

CVE_ID: N/A
Host_Type: Multiple
Impact: System Compromise
Port: Multiple
Recommendation: Change default passwords
Service: Various
Severity: HIGH
Status: VULNERABLE
Vulnerability_Type: Default Credentials