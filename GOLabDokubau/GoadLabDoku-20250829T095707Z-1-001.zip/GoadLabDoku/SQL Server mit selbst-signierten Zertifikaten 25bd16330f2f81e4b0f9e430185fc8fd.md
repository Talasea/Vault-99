# SQL Server mit selbst-signierten Zertifikaten

Betroffene_Hosts: 192.168.20.22,23
CVSS_Score: 7,5
Ausnutzbarkeit: Man-in-the-Middle
Empfohlene_Tools: mssqlclient, sqlmap