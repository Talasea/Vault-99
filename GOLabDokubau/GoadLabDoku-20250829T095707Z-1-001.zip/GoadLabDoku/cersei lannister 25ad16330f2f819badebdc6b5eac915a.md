# cersei.lannister

Account_Type: Domain Admin
Attack_Vector: Domain Admin, high-value target
Description: Queen of Westeros
Domain: sevenkingdoms.local
Group_Membership: Domain Admins
Risk_Level: Critical
Status: Active