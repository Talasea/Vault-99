# Authentication

Affected_Systems: samwell.tarly (Password: Heartsbane)
CVSS_Score: 8,8
Exploitability: Easy
Impact: Credential Exposure
Remediation: Remove password from description, rotate credentials
Risk_Level: High
Vulnerability: Password in LDAP Description