# Kerberos

Affected_Systems: brandon.stark (NoPreauth enabled)
CVSS_Score: 8,2
Exploitability: Moderate
Impact: Credential Compromise
Remediation: Enable Kerberos Pre-Authentication
Risk_Level: High
Vulnerability: ASREPRoasting