# Domain Structure

Configuration: 3 Domains, 2 Forests
Network: sevenkingdoms.local (root) + north.sevenkingdoms.local (child) + essos.local (separate)
Notes: Game of Thrones themed Active Directory environment