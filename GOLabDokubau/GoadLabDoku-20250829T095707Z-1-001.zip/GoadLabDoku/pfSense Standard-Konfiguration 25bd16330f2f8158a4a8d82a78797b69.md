# pfSense Standard-Konfiguration

Betroffene_Hosts: 192.168.20.1
CVSS_Score: 7,2
Ausnutzbarkeit: Web GUI Exploitation
Empfohlene_Tools: Nessus, OpenVAS