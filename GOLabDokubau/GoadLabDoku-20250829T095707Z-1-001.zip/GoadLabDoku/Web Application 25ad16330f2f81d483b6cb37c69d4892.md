# Web Application

Affected_Systems: IIS servers (.10, .22, .23)
CVSS_Score: 5,3
Exploitability: Easy
GOAD_Specific: No
Impact: Cross-Site Tracing (XST) attacks
Remediation: Disable TRACE method in IIS configuration
Risk_Level: Medium
Vulnerability: HTTP TRACE Method Enabled