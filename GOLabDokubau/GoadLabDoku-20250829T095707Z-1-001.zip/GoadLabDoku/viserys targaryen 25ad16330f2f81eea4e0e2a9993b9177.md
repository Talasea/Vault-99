# viserys.targaryen

Account_Type: Domain User
Attack_Vector: Write property on jorah.mormont
Description: The Beggar King
Domain: essos.local
Group_Membership: Targaryen Family
Risk_Level: High
Status: Active