root@tala-HP-255-15-6-inch-G10-Notebook-PC:/home/tala# nmap -Pn 192.168.10.0/24 -sn   
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-08-22 14:25 CEST

root@tala-HP-255-15-6-inch-G10-Notebook-PC:/home/tala# nmap -Pn 192.168.20.0/24 -sn   
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-08-22 14:25 CEST
Nmap scan report for localhost (192.168.20.0)
Host is up.
Nmap scan report for localhost (192.168.20.1)
Host is up.
Nmap scan report for localhost (192.168.20.2)
Host is up.
Nmap scan report for localhost (192.168.20.3)
Host is up.
Nmap scan report for localhost (192.168.20.4)
Host is up.
Nmap scan report for localhost (192.168.20.5)
Host is up.
Nmap scan report for localhost (192.168.20.6)
Host is up.
Nmap scan report for localhost (192.168.20.7)
Host is up.
Nmap scan report for localhost (192.168.20.8)
Host is up.
Nmap scan report for localhost (192.168.20.9)
Host is up.
Nmap scan report for localhost (192.168.20.10)
Host is up.
Nmap scan report for localhost (192.168.20.11)
Host is up.
Nmap scan report for localhost (192.168.20.12)
Host is up.
Nmap scan report for localhost (192.168.20.13)
Host is up.
Nmap scan report for localhost (192.168.20.14)
Host is up.
Nmap scan report for localhost (192.168.20.15)
Host is up.
Nmap scan report for localhost (192.168.20.16)
Host is up.
Nmap scan report for localhost (192.168.20.17)
Host is up.
Nmap scan report for localhost (192.168.20.18)
Host is up.
Nmap scan report for localhost (192.168.20.19)
Host is up.
Nmap scan report for localhost (192.168.20.20)
Host is up.
Nmap scan report for localhost (192.168.20.21)
Host is up.
Nmap scan report for localhost (192.168.20.22)
Host is up.
Nmap scan report for localhost (192.168.20.23)
Host is up.
Nmap scan report for localhost (192.168.20.24)
Host is up.
Nmap scan report for localhost (192.168.20.25)
Host is up.
Nmap scan report for localhost (192.168.20.26)
Host is up.
Nmap scan report for localhost (192.168.20.27)
Host is up.
Nmap scan report for localhost (192.168.20.28)
Host is up.
Nmap scan report for localhost (192.168.20.29)
Host is up.
Nmap scan report for localhost (192.168.20.30)
Host is up.
Nmap scan report for localhost (192.168.20.31)
Host is up.
Nmap scan report for localhost (192.168.20.32)
Host is up.
Nmap scan report for localhost (192.168.20.33)
Host is up.
Nmap scan report for localhost (192.168.20.34)
Host is up.
Nmap scan report for localhost (192.168.20.35)
Host is up.
Nmap scan report for localhost (192.168.20.36)
Host is up.
Nmap scan report for localhost (192.168.20.37)
Host is up.
Nmap scan report for localhost (192.168.20.38)
Host is up.
Nmap scan report for localhost (192.168.20.39)
Host is up.
Nmap scan report for localhost (192.168.20.40)
Host is up.
Nmap scan report for localhost (192.168.20.41)
Host is up.
Nmap scan report for localhost (192.168.20.42)
Host is up.
Nmap scan report for localhost (192.168.20.43)
Host is up.
Nmap scan report for localhost (192.168.20.44)
Host is up.
Nmap scan report for localhost (192.168.20.45)
Host is up.
Nmap scan report for localhost (192.168.20.46)
Host is up.
Nmap scan report for localhost (192.168.20.47)
Host is up.
Nmap scan report for localhost (192.168.20.48)
Host is up.
Nmap scan report for localhost (192.168.20.49)
Host is up.
Nmap scan report for localhost (192.168.20.50)
Host is up.
Nmap scan report for localhost (192.168.20.51)
Host is up.
Nmap scan report for localhost (192.168.20.52)
Host is up.
Nmap scan report for localhost (192.168.20.53)
Host is up.
Nmap scan report for localhost (192.168.20.54)
Host is up.
Nmap scan report for localhost (192.168.20.55)
Host is up.
Nmap scan report for localhost (192.168.20.56)
Host is up.
Nmap scan report for localhost (192.168.20.57)
Host is up.
Nmap scan report for localhost (192.168.20.58)
Host is up.
Nmap scan report for localhost (192.168.20.59)
Host is up.
Nmap scan report for localhost (192.168.20.60)
Host is up.
Nmap scan report for localhost (192.168.20.61)
Host is up.
Nmap scan report for localhost (192.168.20.62)
Host is up.
Nmap scan report for localhost (192.168.20.63)
Host is up.
Nmap scan report for localhost (192.168.20.64)
Host is up.
Nmap scan report for localhost (192.168.20.65)
Host is up.
Nmap scan report for localhost (192.168.20.66)
Host is up.
Nmap scan report for localhost (192.168.20.67)
Host is up.
Nmap scan report for localhost (192.168.20.68)
Host is up.
Nmap scan report for localhost (192.168.20.69)
Host is up.
Nmap scan report for localhost (192.168.20.70)
Host is up.
Nmap scan report for localhost (192.168.20.71)
Host is up.
Nmap scan report for localhost (192.168.20.72)
Host is up.
Nmap scan report for localhost (192.168.20.73)
Host is up.
Nmap scan report for localhost (192.168.20.74)
Host is up.
Nmap scan report for localhost (192.168.20.75)
Host is up.
Nmap scan report for localhost (192.168.20.76)
Host is up.
Nmap scan report for localhost (192.168.20.77)
Host is up.
Nmap scan report for localhost (192.168.20.78)
Host is up.
Nmap scan report for localhost (192.168.20.79)
Host is up.
Nmap scan report for localhost (192.168.20.80)
Host is up.
Nmap scan report for localhost (192.168.20.81)
Host is up.
Nmap scan report for localhost (192.168.20.82)
Host is up.
Nmap scan report for localhost (192.168.20.83)
Host is up.
Nmap scan report for localhost (192.168.20.84)
Host is up.
Nmap scan report for localhost (192.168.20.85)
Host is up.
Nmap scan report for localhost (192.168.20.86)
Host is up.
Nmap scan report for localhost (192.168.20.87)
Host is up.
Nmap scan report for localhost (192.168.20.88)
Host is up.
Nmap scan report for localhost (192.168.20.89)
Host is up.
Nmap scan report for localhost (192.168.20.90)
Host is up.
Nmap scan report for localhost (192.168.20.91)
Host is up.
Nmap scan report for localhost (192.168.20.92)
Host is up.
Nmap scan report for localhost (192.168.20.93)
Host is up.
Nmap scan report for localhost (192.168.20.94)
Host is up.
Nmap scan report for localhost (192.168.20.95)
Host is up.
Nmap scan report for localhost (192.168.20.96)
Host is up.
Nmap scan report for localhost (192.168.20.97)
Host is up.
Nmap scan report for localhost (192.168.20.98)
Host is up.
Nmap scan report for localhost (192.168.20.99)
Host is up.
Nmap scan report for localhost (192.168.20.100)
Host is up.
Nmap scan report for localhost (192.168.20.101)
Host is up.
Nmap scan report for localhost (192.168.20.102)
Host is up.
Nmap scan report for localhost (192.168.20.103)
Host is up.
Nmap scan report for localhost (192.168.20.104)
Host is up.
Nmap scan report for localhost (192.168.20.105)
Host is up.
Nmap scan report for localhost (192.168.20.106)
Host is up.
Nmap scan report for localhost (192.168.20.107)
Host is up.
Nmap scan report for localhost (192.168.20.108)
Host is up.
Nmap scan report for localhost (192.168.20.109)
Host is up.
Nmap scan report for localhost (192.168.20.110)
Host is up.
Nmap scan report for localhost (192.168.20.111)
Host is up.
Nmap scan report for localhost (192.168.20.112)
Host is up.
Nmap scan report for localhost (192.168.20.113)
Host is up.
Nmap scan report for localhost (192.168.20.114)
Host is up.
Nmap scan report for localhost (192.168.20.115)
Host is up.
Nmap scan report for localhost (192.168.20.116)
Host is up.
Nmap scan report for localhost (192.168.20.117)
Host is up.
Nmap scan report for localhost (192.168.20.118)
Host is up.
Nmap scan report for localhost (192.168.20.119)
Host is up.
Nmap scan report for localhost (192.168.20.120)
Host is up.
Nmap scan report for localhost (192.168.20.121)
Host is up.
Nmap scan report for localhost (192.168.20.122)
Host is up.
Nmap scan report for localhost (192.168.20.123)
Host is up.
Nmap scan report for localhost (192.168.20.124)
Host is up.
Nmap scan report for localhost (192.168.20.125)
Host is up.
Nmap scan report for localhost (192.168.20.126)
Host is up.
Nmap scan report for localhost (192.168.20.127)
Host is up.
Nmap scan report for localhost (192.168.20.128)
Host is up.
Nmap scan report for localhost (192.168.20.129)
Host is up.
Nmap scan report for localhost (192.168.20.130)
Host is up.
Nmap scan report for localhost (192.168.20.131)
Host is up.
Nmap scan report for localhost (192.168.20.132)
Host is up.
Nmap scan report for localhost (192.168.20.133)
Host is up.
Nmap scan report for localhost (192.168.20.134)
Host is up.
Nmap scan report for localhost (192.168.20.135)
Host is up.
Nmap scan report for localhost (192.168.20.136)
Host is up.
Nmap scan report for localhost (192.168.20.137)
Host is up.
Nmap scan report for localhost (192.168.20.138)
Host is up.
Nmap scan report for localhost (192.168.20.139)
Host is up.
Nmap scan report for localhost (192.168.20.140)
Host is up.
Nmap scan report for localhost (192.168.20.141)
Host is up.
Nmap scan report for localhost (192.168.20.142)
Host is up.
Nmap scan report for localhost (192.168.20.143)
Host is up.
Nmap scan report for localhost (192.168.20.144)
Host is up.
Nmap scan report for localhost (192.168.20.145)
Host is up.
Nmap scan report for localhost (192.168.20.146)
Host is up.
Nmap scan report for localhost (192.168.20.147)
Host is up.
Nmap scan report for localhost (192.168.20.148)
Host is up.
Nmap scan report for localhost (192.168.20.149)
Host is up.
Nmap scan report for localhost (192.168.20.150)
Host is up.
Nmap scan report for localhost (192.168.20.151)
Host is up.
Nmap scan report for localhost (192.168.20.152)
Host is up.
Nmap scan report for localhost (192.168.20.153)
Host is up.
Nmap scan report for localhost (192.168.20.154)
Host is up.
Nmap scan report for localhost (192.168.20.155)
Host is up.
Nmap scan report for localhost (192.168.20.156)
Host is up.
Nmap scan report for localhost (192.168.20.157)
Host is up.
Nmap scan report for localhost (192.168.20.158)
Host is up.
Nmap scan report for localhost (192.168.20.159)
Host is up.
Nmap scan report for localhost (192.168.20.160)
Host is up.
Nmap scan report for localhost (192.168.20.161)
Host is up.
Nmap scan report for localhost (192.168.20.162)
Host is up.
Nmap scan report for localhost (192.168.20.163)
Host is up.
Nmap scan report for localhost (192.168.20.164)
Host is up.
Nmap scan report for localhost (192.168.20.165)
Host is up.
Nmap scan report for localhost (192.168.20.166)
Host is up.
Nmap scan report for localhost (192.168.20.167)
Host is up.
Nmap scan report for localhost (192.168.20.168)
Host is up.
Nmap scan report for localhost (192.168.20.169)
Host is up.
Nmap scan report for localhost (192.168.20.170)
Host is up.
Nmap scan report for localhost (192.168.20.171)
Host is up.
Nmap scan report for localhost (192.168.20.172)
Host is up.
Nmap scan report for localhost (192.168.20.173)
Host is up.
Nmap scan report for localhost (192.168.20.174)
Host is up.
Nmap scan report for localhost (192.168.20.175)
Host is up.
Nmap scan report for localhost (192.168.20.176)
Host is up.
Nmap scan report for localhost (192.168.20.177)
Host is up.
Nmap scan report for localhost (192.168.20.178)
Host is up.
Nmap scan report for localhost (192.168.20.179)
Host is up.
Nmap scan report for localhost (192.168.20.180)
Host is up.
Nmap scan report for localhost (192.168.20.181)
Host is up.
Nmap scan report for localhost (192.168.20.182)
Host is up.
Nmap scan report for localhost (192.168.20.183)
Host is up.
Nmap scan report for localhost (192.168.20.184)
Host is up.
Nmap scan report for localhost (192.168.20.185)
Host is up.
Nmap scan report for localhost (192.168.20.186)
Host is up.
Nmap scan report for localhost (192.168.20.187)
Host is up.
Nmap scan report for localhost (192.168.20.188)
Host is up.
Nmap scan report for localhost (192.168.20.189)
Host is up.
Nmap scan report for localhost (192.168.20.190)
Host is up.
Nmap scan report for localhost (192.168.20.191)
Host is up.
Nmap scan report for localhost (192.168.20.192)
Host is up.
Nmap scan report for localhost (192.168.20.193)
Host is up.
Nmap scan report for localhost (192.168.20.194)
Host is up.
Nmap scan report for localhost (192.168.20.195)
Host is up.
Nmap scan report for localhost (192.168.20.196)
Host is up.
Nmap scan report for localhost (192.168.20.197)
Host is up.
Nmap scan report for localhost (192.168.20.198)
Host is up.
Nmap scan report for localhost (192.168.20.199)
Host is up.
Nmap scan report for localhost (192.168.20.200)
Host is up.
Nmap scan report for localhost (192.168.20.201)
Host is up.
Nmap scan report for localhost (192.168.20.202)
Host is up.
Nmap scan report for localhost (192.168.20.203)
Host is up.
Nmap scan report for localhost (192.168.20.204)
Host is up.
Nmap scan report for localhost (192.168.20.205)
Host is up.
Nmap scan report for localhost (192.168.20.206)
Host is up.
Nmap scan report for localhost (192.168.20.207)
Host is up.
Nmap scan report for localhost (192.168.20.208)
Host is up.
Nmap scan report for localhost (192.168.20.209)
Host is up.
Nmap scan report for localhost (192.168.20.210)
Host is up.
Nmap scan report for localhost (192.168.20.211)
Host is up.
Nmap scan report for localhost (192.168.20.212)
Host is up.
Nmap scan report for localhost (192.168.20.213)
Host is up.
Nmap scan report for localhost (192.168.20.214)
Host is up.
Nmap scan report for localhost (192.168.20.215)
Host is up.
Nmap scan report for localhost (192.168.20.216)
Host is up.
Nmap scan report for localhost (192.168.20.217)
Host is up.
Nmap scan report for localhost (192.168.20.218)
Host is up.
Nmap scan report for localhost (192.168.20.219)
Host is up.
Nmap scan report for localhost (192.168.20.220)
Host is up.
Nmap scan report for localhost (192.168.20.221)
Host is up.
Nmap scan report for localhost (192.168.20.222)
Host is up.
Nmap scan report for localhost (192.168.20.223)
Host is up.
Nmap scan report for localhost (192.168.20.224)
Host is up.
Nmap scan report for localhost (192.168.20.225)
Host is up.
Nmap scan report for localhost (192.168.20.226)
Host is up.
Nmap scan report for localhost (192.168.20.227)
Host is up.
Nmap scan report for localhost (192.168.20.228)
Host is up.
Nmap scan report for localhost (192.168.20.229)
Host is up.
Nmap scan report for localhost (192.168.20.230)
Host is up.
Nmap scan report for localhost (192.168.20.231)
Host is up.
Nmap scan report for localhost (192.168.20.232)
Host is up.
Nmap scan report for localhost (192.168.20.233)
Host is up.
Nmap scan report for localhost (192.168.20.234)
Host is up.
Nmap scan report for localhost (192.168.20.235)
Host is up.
Nmap scan report for localhost (192.168.20.236)
Host is up.
Nmap scan report for localhost (192.168.20.237)
Host is up.
Nmap scan report for localhost (192.168.20.238)
Host is up.
Nmap scan report for localhost (192.168.20.239)
Host is up.
Nmap scan report for localhost (192.168.20.240)
Host is up.
Nmap scan report for localhost (192.168.20.241)
Host is up.
Nmap scan report for localhost (192.168.20.242)
Host is up.
Nmap scan report for localhost (192.168.20.243)
Host is up.
Nmap scan report for localhost (192.168.20.244)
Host is up.
Nmap scan report for localhost (192.168.20.245)
Host is up.
Nmap scan report for localhost (192.168.20.246)
Host is up.
Nmap scan report for localhost (192.168.20.247)
Host is up.
Nmap scan report for localhost (192.168.20.248)
Host is up.
Nmap scan report for localhost (192.168.20.249)
Host is up.
Nmap scan report for localhost (192.168.20.250)
Host is up.
Nmap scan report for localhost (192.168.20.251)
Host is up.
Nmap scan report for localhost (192.168.20.252)
Host is up.
Nmap scan report for localhost (192.168.20.253)
Host is up.
Nmap scan report for localhost (192.168.20.254)
Host is up.
Nmap scan report for localhost (192.168.20.255)
Host is up.
Nmap done: 256 IP addresses (256 hosts up) scanned in 5.45 seconds
root@tala-HP-255-15-6-inch-G10-Notebook-PC:/home/tala# nmap -Pn -sV -sC 192.168.20.10-23 -oA goad_scan
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-08-22 14:27 CEST
Nmap scan report for localhost (192.168.20.10)
Host is up (0.019s latency).
Not shown: 987 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
53/tcp   open  domain        Simple DNS Plus
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-title: IIS Windows Server
|_http-server-header: Microsoft-IIS/10.0
| http-methods: 
|_  Potentially risky methods: TRACE
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2025-08-22 12:27:21Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=kingslanding.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:kingslanding.sevenkingdoms.local
| Not valid before: 2025-04-13T16:42:45
|_Not valid after:  2026-04-13T16:42:45
445/tcp  open  microsoft-ds?
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=kingslanding.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:kingslanding.sevenkingdoms.local
| Not valid before: 2025-04-13T16:42:45
|_Not valid after:  2026-04-13T16:42:45
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=kingslanding.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:kingslanding.sevenkingdoms.local
| Not valid before: 2025-04-13T16:42:45
|_Not valid after:  2026-04-13T16:42:45
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
3269/tcp open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=kingslanding.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:kingslanding.sevenkingdoms.local
| Not valid before: 2025-04-13T16:42:45
|_Not valid after:  2026-04-13T16:42:45
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| ssl-cert: Subject: commonName=kingslanding.sevenkingdoms.local
| Not valid before: 2025-04-12T16:22:47
|_Not valid after:  2025-10-12T16:22:47
| rdp-ntlm-info: 
|   Target_Name: SEVENKINGDOMS
|   NetBIOS_Domain_Name: SEVENKINGDOMS
|   NetBIOS_Computer_Name: KINGSLANDING
|   DNS_Domain_Name: sevenkingdoms.local
|   DNS_Computer_Name: kingslanding.sevenkingdoms.local
|   DNS_Tree_Name: sevenkingdoms.local
|   Product_Version: 10.0.17763
|_  System_Time: 2025-08-22T12:28:06+00:00
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
Service Info: Host: KINGSLANDING; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-time: 
|   date: 2025-08-22T12:28:07
|_  start_date: N/A
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required
|_clock-skew: mean: -3s, deviation: 0s, median: -3s

Nmap scan report for localhost (192.168.20.11)
Host is up (0.021s latency).
Not shown: 988 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
53/tcp   open  domain        Simple DNS Plus
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2025-08-22 12:27:21Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=winterfell.north.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:winterfell.north.sevenkingdoms.local
| Not valid before: 2025-04-13T17:05:17
|_Not valid after:  2026-04-13T17:05:17
445/tcp  open  microsoft-ds?
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=winterfell.north.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:winterfell.north.sevenkingdoms.local
| Not valid before: 2025-04-13T17:05:17
|_Not valid after:  2026-04-13T17:05:17
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=winterfell.north.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:winterfell.north.sevenkingdoms.local
| Not valid before: 2025-04-13T17:05:17
|_Not valid after:  2026-04-13T17:05:17
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
3269/tcp open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: sevenkingdoms.local0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=winterfell.north.sevenkingdoms.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:winterfell.north.sevenkingdoms.local
| Not valid before: 2025-04-13T17:05:17
|_Not valid after:  2026-04-13T17:05:17
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| rdp-ntlm-info: 
|   Target_Name: NORTH
|   NetBIOS_Domain_Name: NORTH
|   NetBIOS_Computer_Name: WINTERFELL
|   DNS_Domain_Name: north.sevenkingdoms.local
|   DNS_Computer_Name: winterfell.north.sevenkingdoms.local
|   DNS_Tree_Name: sevenkingdoms.local
|   Product_Version: 10.0.17763
|_  System_Time: 2025-08-22T12:28:07+00:00
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=winterfell.north.sevenkingdoms.local
| Not valid before: 2025-04-12T16:31:49
|_Not valid after:  2025-10-12T16:31:49
Service Info: Host: WINTERFELL; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
|_clock-skew: mean: -3s, deviation: 0s, median: -3s
| smb2-time: 
|   date: 2025-08-22T12:28:17
|_  start_date: N/A
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required

Nmap scan report for localhost (192.168.20.12)
Host is up (0.020s latency).
Not shown: 988 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
53/tcp   open  domain        Simple DNS Plus
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2025-08-22 12:27:26Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: essos.local, Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
| ssl-cert: Subject: commonName=meereen.essos.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:meereen.essos.local
| Not valid before: 2025-04-13T16:43:00
|_Not valid after:  2026-04-13T16:43:00
445/tcp  open  microsoft-ds  Windows Server 2016 Standard Evaluation 14393 microsoft-ds (workgroup: ESSOS)
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: essos.local, Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=meereen.essos.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:meereen.essos.local
| Not valid before: 2025-04-13T16:43:00
|_Not valid after:  2026-04-13T16:43:00
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: essos.local, Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=meereen.essos.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:meereen.essos.local
| Not valid before: 2025-04-13T16:43:00
|_Not valid after:  2026-04-13T16:43:00
3269/tcp open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: essos.local, Site: Default-First-Site-Name)
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
| ssl-cert: Subject: commonName=meereen.essos.local
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:meereen.essos.local
| Not valid before: 2025-04-13T16:43:00
|_Not valid after:  2026-04-13T16:43:00
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| ssl-cert: Subject: commonName=meereen.essos.local
| Not valid before: 2025-04-12T16:22:52
|_Not valid after:  2025-10-12T16:22:52
| rdp-ntlm-info: 
|   Target_Name: ESSOS
|   NetBIOS_Domain_Name: ESSOS
|   NetBIOS_Computer_Name: MEEREEN
|   DNS_Domain_Name: essos.local
|   DNS_Computer_Name: meereen.essos.local
|   DNS_Tree_Name: essos.local
|   Product_Version: 10.0.14393
|_  System_Time: 2025-08-22T12:28:10+00:00
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
Service Info: Host: MEEREEN; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required
| smb-security-mode: 
|   account_used: <blank>
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: required
| smb2-time: 
|   date: 2025-08-22T12:28:21
|_  start_date: 2025-08-13T14:05:32
|_clock-skew: mean: -13m22s, deviation: 39m55s, median: -4s
| smb-os-discovery: 
|   OS: Windows Server 2016 Standard Evaluation 14393 (Windows Server 2016 Standard Evaluation 6.3)
|   Computer name: meereen
|   NetBIOS computer name: MEEREEN\x00
|   Domain name: essos.local
|   Forest name: essos.local
|   FQDN: meereen.essos.local
|_  System time: 2025-08-22T14:28:18+02:00

Nmap scan report for localhost (192.168.20.13)
Host is up.
All 1000 scanned ports on localhost (192.168.20.13) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.14)
Host is up.
All 1000 scanned ports on localhost (192.168.20.14) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.15)
Host is up.
All 1000 scanned ports on localhost (192.168.20.15) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.16)
Host is up.
All 1000 scanned ports on localhost (192.168.20.16) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.17)
Host is up.
All 1000 scanned ports on localhost (192.168.20.17) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.18)
Host is up.
All 1000 scanned ports on localhost (192.168.20.18) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.19)
Host is up.
All 1000 scanned ports on localhost (192.168.20.19) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.20)
Host is up.
All 1000 scanned ports on localhost (192.168.20.20) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.21)
Host is up.
All 1000 scanned ports on localhost (192.168.20.21) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)

Nmap scan report for localhost (192.168.20.22)
Host is up (0.019s latency).
Not shown: 994 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-server-header: Microsoft-IIS/10.0
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-title: IIS Windows Server
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
445/tcp  open  microsoft-ds?
1433/tcp open  ms-sql-s      Microsoft SQL Server 2019 15.00.2000.00; RTM
|_ms-sql-ntlm-info: ERROR: Script execution failed (use -d to debug)
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| ssl-cert: Subject: commonName=SSL_Self_Signed_Fallback
| Not valid before: 2025-08-13T14:05:10
|_Not valid after:  2055-08-13T14:05:10
|_ms-sql-info: ERROR: Script execution failed (use -d to debug)
3389/tcp open  ms-wbt-server Microsoft Terminal Services
|_ssl-date: 2025-08-22T12:28:48+00:00; -3s from scanner time.
| rdp-ntlm-info: 
|   Target_Name: NORTH
|   NetBIOS_Domain_Name: NORTH
|   NetBIOS_Computer_Name: CASTELBLACK
|   DNS_Domain_Name: north.sevenkingdoms.local
|   DNS_Computer_Name: castelblack.north.sevenkingdoms.local
|   DNS_Tree_Name: sevenkingdoms.local
|   Product_Version: 10.0.17763
|_  System_Time: 2025-08-22T12:28:07+00:00
| ssl-cert: Subject: commonName=castelblack.north.sevenkingdoms.local
| Not valid before: 2025-04-12T16:38:33
|_Not valid after:  2025-10-12T16:38:33
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled but not required
|_clock-skew: mean: -3s, deviation: 0s, median: -3s
| smb2-time: 
|   date: 2025-08-22T12:28:25
|_  start_date: N/A

Nmap scan report for localhost (192.168.20.23)
Host is up (0.019s latency).
Not shown: 994 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-title: IIS Windows Server
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-server-header: Microsoft-IIS/10.0
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
445/tcp  open  microsoft-ds  Windows Server 2016 Standard Evaluation 14393 microsoft-ds
1433/tcp open  ms-sql-s      Microsoft SQL Server 2019 15.00.2000.00; RTM
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
|_ms-sql-info: ERROR: Script execution failed (use -d to debug)
|_ms-sql-ntlm-info: ERROR: Script execution failed (use -d to debug)
| ssl-cert: Subject: commonName=SSL_Self_Signed_Fallback
| Not valid before: 2025-08-13T14:05:09
|_Not valid after:  2055-08-13T14:05:09
3389/tcp open  ms-wbt-server Microsoft Terminal Services
|_ssl-date: 2025-08-22T12:28:47+00:00; -4s from scanner time.
| rdp-ntlm-info: 
|   Target_Name: ESSOS
|   NetBIOS_Domain_Name: ESSOS
|   NetBIOS_Computer_Name: BRAAVOS
|   DNS_Domain_Name: essos.local
|   DNS_Computer_Name: braavos.essos.local
|   DNS_Tree_Name: essos.local
|   Product_Version: 10.0.14393
|_  System_Time: 2025-08-22T12:28:08+00:00
| ssl-cert: Subject: commonName=braavos.essos.local
| Not valid before: 2025-04-12T16:36:10
|_Not valid after:  2025-10-12T16:36:10
Service Info: OSs: Windows, Windows Server 2008 R2 - 2012; CPE: cpe:/o:microsoft:windows

Host script results:
|_clock-skew: mean: -19m59s, deviation: 48m49s, median: -4s
| smb2-time: 
|   date: 2025-08-22T12:28:27
|_  start_date: 2025-08-13T14:05:07
| smb-os-discovery: 
|   OS: Windows Server 2016 Standard Evaluation 14393 (Windows Server 2016 Standard Evaluation 6.3)
|   Computer name: braavos
|   NetBIOS computer name: BRAAVOS\x00
|   Domain name: essos.local
|   Forest name: essos.local
|   FQDN: braavos.essos.local
|_  System time: 2025-08-22T14:28:30+02:00
| smb-security-mode: 
|   account_used: guest
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: disabled (dangerous, but default)
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled but not required

Post-scan script results:
| clock-skew: 
|   -19m59s: 
|     192.168.20.23 (localhost)
|     192.168.20.12 (localhost)
|   -3s: 
|     192.168.20.11 (localhost)
|     192.168.20.10 (localhost)
|_    192.168.20.22 (localhost)
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 14 IP addresses (14 hosts up) scanned in 110.54 seconds
root@tala-HP-255-15-6-inch-G10-Notebook-PC:/home/tala# nmap -Pn --script vuln 192.168.10.10-23         
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-08-22 14:29 CEST
Nmap scan report for localhost (192.168.10.10)
Host is up (0.018s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.11)
Host is up (0.018s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.12)
Host is up (0.018s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.13)
Host is up (0.020s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.14)
Host is up (0.020s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.15)
Host is up (0.012s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.16)
Host is up (0.016s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.17)
Host is up (0.019s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.18)
Host is up (0.019s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.19)
Host is up (0.020s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.20)
Host is up (0.022s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.21)
Host is up (0.022s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.22)
Host is up (0.034s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap scan report for localhost (192.168.10.23)
Host is up (0.021s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE  SERVICE
25/tcp closed smtp

Nmap done: 14 IP addresses (14 hosts up) scanned in 69.26 seconds
root@tala-HP-255-15-6-inch-G10-Notebook-PC:/home/tala# nmap -Pn -sU --top-ports 1000 192.168.20.10-23
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-08-22 14:32 CEST
Nmap scan report for localhost (192.168.20.10)
Host is up (0.019s latency).
Not shown: 971 closed udp ports (port-unreach)
PORT      STATE         SERVICE
53/udp    open          domain
88/udp    open          kerberos-sec
123/udp   open          ntp
137/udp   open|filtered netbios-ns
138/udp   open|filtered netbios-dgm
389/udp   open          ldap
464/udp   open|filtered kpasswd5
500/udp   open|filtered isakmp
3389/udp  open|filtered ms-wbt-server
4500/udp  open|filtered nat-t-ike
5353/udp  open|filtered zeroconf
5355/udp  open|filtered llmnr
49968/udp open|filtered unknown
50099/udp open|filtered unknown
50164/udp open|filtered unknown
50497/udp open|filtered unknown
50612/udp open|filtered unknown
50708/udp open|filtered unknown
50919/udp open|filtered unknown
51255/udp open|filtered unknown
51456/udp open|filtered unknown
51554/udp open|filtered unknown
51586/udp open|filtered unknown
51690/udp open|filtered unknown
51717/udp open|filtered unknown
51905/udp open|filtered unknown
51972/udp open|filtered unknown
52144/udp open|filtered unknown
52225/udp open|filtered unknown

Nmap scan report for localhost (192.168.20.11)
Host is up (0.020s latency).
Not shown: 976 closed udp ports (port-unreach)
PORT      STATE         SERVICE
53/udp    open          domain
88/udp    open          kerberos-sec
123/udp   open          ntp
137/udp   open|filtered netbios-ns
138/udp   open|filtered netbios-dgm
389/udp   open          ldap
464/udp   open|filtered kpasswd5
500/udp   open|filtered isakmp
3389/udp  open|filtered ms-wbt-server
4500/udp  open|filtered nat-t-ike
5353/udp  open|filtered zeroconf
5355/udp  open|filtered llmnr
49503/udp open|filtered unknown
49640/udp open|filtered unknown
49968/udp open|filtered unknown
50099/udp open|filtered unknown
50164/udp open|filtered unknown
50497/udp open|filtered unknown
50612/udp open|filtered unknown
50708/udp open|filtered unknown
50919/udp open|filtered unknown
55544/udp open|filtered unknown
55587/udp open|filtered unknown
56141/udp open|filtered unknown

Nmap scan report for localhost (192.168.20.12)
Host is up (0.020s latency).
Not shown: 972 closed udp ports (port-unreach)
PORT      STATE         SERVICE
53/udp    open          domain
88/udp    open          kerberos-sec
123/udp   open          ntp
137/udp   open|filtered netbios-ns
138/udp   open|filtered netbios-dgm
389/udp   open          ldap
464/udp   open|filtered kpasswd5
500/udp   open|filtered isakmp
3389/udp  open|filtered ms-wbt-server
4500/udp  open|filtered nat-t-ike
5050/udp  open|filtered mmcc
5353/udp  open|filtered zeroconf
5355/udp  open|filtered llmnr
51255/udp open|filtered unknown
51456/udp open|filtered unknown
51554/udp open|filtered unknown
51586/udp open|filtered unknown
51690/udp open|filtered unknown
51717/udp open|filtered unknown
51905/udp open|filtered unknown
51972/udp open|filtered unknown
52144/udp open|filtered unknown
52225/udp open|filtered unknown
52503/udp open|filtered unknown
53006/udp open|filtered unknown
53037/udp open|filtered unknown
53571/udp open|filtered unknown
53589/udp open|filtered unknown

Nmap scan report for localhost (192.168.20.13)
Host is up.
All 1000 scanned ports on localhost (192.168.20.13) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.14)
Host is up.
All 1000 scanned ports on localhost (192.168.20.14) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.15)
Host is up.
All 1000 scanned ports on localhost (192.168.20.15) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.16)
Host is up.
All 1000 scanned ports on localhost (192.168.20.16) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.17)
Host is up.
All 1000 scanned ports on localhost (192.168.20.17) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.18)
Host is up.
All 1000 scanned ports on localhost (192.168.20.18) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.19)
Host is up.
All 1000 scanned ports on localhost (192.168.20.19) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.20)
Host is up.
All 1000 scanned ports on localhost (192.168.20.20) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.21)
Host is up.
All 1000 scanned ports on localhost (192.168.20.21) are in ignored states.
Not shown: 1000 open|filtered udp ports (no-response)

Nmap scan report for localhost (192.168.20.22)
Host is up (0.019s latency).
Not shown: 992 closed udp ports (port-unreach)
PORT     STATE         SERVICE
123/udp  open|filtered ntp
137/udp  open|filtered netbios-ns
138/udp  open|filtered netbios-dgm
500/udp  open|filtered isakmp
3389/udp open|filtered ms-wbt-server
4500/udp open|filtered nat-t-ike
5353/udp open|filtered zeroconf
5355/udp open|filtered llmnr

Nmap scan report for localhost (192.168.20.23)
Host is up (0.021s latency).
Not shown: 991 closed udp ports (port-unreach)
PORT     STATE         SERVICE
123/udp  open|filtered ntp
137/udp  open|filtered netbios-ns
138/udp  open|filtered netbios-dgm
500/udp  open|filtered isakmp
3389/udp open|filtered ms-wbt-server
4500/udp open|filtered nat-t-ike
5050/udp open|filtered mmcc
5353/udp open|filtered zeroconf
5355/udp open|filtered llmnr

Nmap done: 14 IP addresses (14 hosts up) scanned in 1256.93 seconds
