# Active Directory Domains

Category: Infrastructure
Status: Identified
Value: 3