1. richtigen Netzwerkadapter auswählen

  

2. ovpn Dateien downloaden und die ZIP Datei entpacken

  

3. Ein Terminal (z.B. in Kali) öffnen und …

  

   sudo OpenVPN >Pfad zur ovpn Datei>

  

   Username: 24-6

   Passwort: VPNLab2406

  

  

   IPs der Labs:

   Lab 1 -> 192.168.10.x

   Lab 2 -> 192.168.20.x

   Lab 3 -> 192.168.30.x

   Lab 4 -> 192.168.40.x

   Lab 5 -> 192.168.50.x

  

  

   Als "roten Faden" -> An der Cyber Kill Chain entlang arbeiten:

   Punkt 1 (Reconaissence, Beschaffung der Informationen):

     - nmap

     - Bloodhound / sharphound

     - powerview

     - kerberoasting

     - nslookup 

     - get-DomainGPO

     - crackmapexec


https://docs.google.com/document/d/1BNsrfXDhSSukXEQ_JunWFhi96ChzYEgar9FqzWmgA0c/edit?tab=t.26c1b7iwprdl





  

  

  Daniel Ferdinand Hensen
12:22
https://github.com/nxnjz/RustBuster

Daniel Ferdinand Hensen
12:22
https://github.com/epi052/feroxbuster