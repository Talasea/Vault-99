# Total Hosts Discovered

Category: Infrastructure
Status: Complete
Value: 5