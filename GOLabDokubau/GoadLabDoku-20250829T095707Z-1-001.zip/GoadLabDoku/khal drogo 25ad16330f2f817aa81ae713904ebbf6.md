# khal.drogo

Account_Type: Administrative
Attack_Vector: MSSQL Admin + GenericAll on viserys + Shadow Credentials
Description: Great Khal
Domain: essos.local
Group_Membership: Dothraki, Domain Admins
Risk_Level: Critical
Status: Active