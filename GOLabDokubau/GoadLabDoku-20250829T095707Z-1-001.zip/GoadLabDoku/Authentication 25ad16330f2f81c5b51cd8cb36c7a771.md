# Authentication

Affected_Systems: hodor account (hodor:hodor)
CVSS_Score: 9,8
Exploitability: Trivial
Impact: Initial Access, Privilege Escalation
Remediation: Change password immediately, enforce complexity policy
Risk_Level: Critical
Vulnerability: Weak Password Policy