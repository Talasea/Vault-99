# SMB Signierung deaktiviert (BRAAVOS)

Betroffene_Hosts: 192.168.20.23
CVSS_Score: 9,1
Ausnutzbarkeit: SMB Relay, NTLM Hash Capture
Empfohlene_Tools: ntlmrelayx, Responder