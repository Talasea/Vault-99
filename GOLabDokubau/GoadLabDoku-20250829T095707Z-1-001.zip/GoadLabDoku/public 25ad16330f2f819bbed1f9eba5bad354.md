# public

Access_Level: READ
Anonymous_Access: No
Description: Basic Read share for all domain users
Host: BRAAVOS (192.168.20.23)
Risk_Level: Medium
Type: User Share