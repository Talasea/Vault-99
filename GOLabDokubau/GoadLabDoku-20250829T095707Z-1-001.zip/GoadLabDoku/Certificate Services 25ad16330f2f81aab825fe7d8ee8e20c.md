# Certificate Services

Affected_Systems: CertEnroll share accessible
CVSS_Score: 8,8
Exploitability: Moderate
Impact: Authentication Bypass, Privilege Escalation
Remediation: Restrict CertEnroll access, review certificate templates
Risk_Level: High
Vulnerability: Certificate Template Abuse