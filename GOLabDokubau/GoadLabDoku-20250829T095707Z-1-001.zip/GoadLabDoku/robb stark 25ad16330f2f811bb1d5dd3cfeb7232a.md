# robb.stark

Account_Type: Domain Admin
Attack_Vector: Domain Admin, RESPONDER bot (3min intervals)
Description: Young Wolf
Domain: north.sevenkingdoms.local
Group_Membership: Domain Admins, Stark Family
Risk_Level: High
Status: Active