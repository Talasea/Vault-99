# rickon.stark

Account_Type: Domain User
Attack_Vector: Password Spraying - WinterYYYY pattern
Description: Rickon Stark
Domain: north.sevenkingdoms.local
Risk_Level: Medium
Status: Active