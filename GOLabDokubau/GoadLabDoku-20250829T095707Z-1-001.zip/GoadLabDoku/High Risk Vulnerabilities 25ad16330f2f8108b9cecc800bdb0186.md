# High Risk Vulnerabilities

Category: Security
Status: Identified
Value: 4