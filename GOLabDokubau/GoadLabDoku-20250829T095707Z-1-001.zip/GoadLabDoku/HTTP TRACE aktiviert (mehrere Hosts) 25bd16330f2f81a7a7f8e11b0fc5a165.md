# HTTP TRACE aktiviert (mehrere Hosts)

Betroffene_Hosts: 192.168.20.10,22,23
CVSS_Score: 6,1
Ausnutzbarkeit: Cross-Site Tracing (XST)
Empfohlene_Tools: Burp Suite, OWASP ZAP