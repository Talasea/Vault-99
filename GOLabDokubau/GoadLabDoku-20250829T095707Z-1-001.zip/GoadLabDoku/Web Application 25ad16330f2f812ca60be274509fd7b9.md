# Web Application

Affected_Systems: IIS servers (.10, .23)
CVSS_Score: 5,3
Exploitability: Easy
Impact: Cross-Site Tracing (XST)
Remediation: Disable TRACE method in IIS configuration
Risk_Level: Medium
Vulnerability: HTTP TRACE Method Enabled