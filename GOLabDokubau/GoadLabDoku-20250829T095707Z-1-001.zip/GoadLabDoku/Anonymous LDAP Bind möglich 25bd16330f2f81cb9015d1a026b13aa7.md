# Anonymous LDAP Bind möglich

Betroffene_Hosts: 192.168.20.10,11,12
CVSS_Score: 5,3
Ausnutzbarkeit: Domain Enumeration
Empfohlene_Tools: ldapsearch, enum4linux