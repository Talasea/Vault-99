# hodor

Account_Type: Domain User
Attack_Vector: Password = Username (hodor:hodor)
Description: Brainless Giant
Domain: north.sevenkingdoms.local
Risk_Level: Critical
Status: Active