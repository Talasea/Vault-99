# daenerys.targaryen

Account_Type: Domain Admin
Attack_Vector: Domain Admin ESSOS forest
Description: Mother of Dragons
Domain: essos.local
Group_Membership: Domain Admins, Targaryen Family
Risk_Level: Critical
Status: Active