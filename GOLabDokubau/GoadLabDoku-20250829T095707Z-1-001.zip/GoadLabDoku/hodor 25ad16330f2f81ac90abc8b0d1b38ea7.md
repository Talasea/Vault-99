# hodor

Account_Type: Domain User
Attack_Vector: Password = Username (hodor:hodor)
Description: Brainless Giant
Domain: north.sevenkingdoms.local
Group_Membership: Domain Users
Risk_Level: Critical
Status: Active