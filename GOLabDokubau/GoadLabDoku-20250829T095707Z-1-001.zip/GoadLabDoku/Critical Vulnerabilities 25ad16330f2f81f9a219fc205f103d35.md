# Critical Vulnerabilities

Category: Security
Status: Confirmed
Value: 4