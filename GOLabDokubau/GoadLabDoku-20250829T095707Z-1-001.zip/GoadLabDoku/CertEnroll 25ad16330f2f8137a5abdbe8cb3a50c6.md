# CertEnroll

Access_Level: READ
Anonymous_Access: No
Description: Active Directory Certificate Services share - Certificate template abuse potential
Host: BRAAVOS (192.168.20.23)
Risk_Level: Critical
Type: Certificate Services