# catelyn.stark

Account_Type: Domain Admin
Attack_Vector: Domain Admin privileges
Description: Lady of Winterfell
Domain: north.sevenkingdoms.local
Group_Membership: Domain Admins, Stark Family
Risk_Level: High
Status: Active