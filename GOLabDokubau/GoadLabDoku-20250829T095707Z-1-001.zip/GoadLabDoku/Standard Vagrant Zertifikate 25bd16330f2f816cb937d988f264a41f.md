# Standard Vagrant Zertifikate

Betroffene_Hosts: 192.168.20.10,11,12
CVSS_Score: 5,9
Ausnutzbarkeit: Certificate Spoofing
Empfohlene_Tools: Custom SSL/TLS tools