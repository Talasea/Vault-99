# Attack Paths Identified

Category: Attack Surface
Status: Mapped
Value: 3+