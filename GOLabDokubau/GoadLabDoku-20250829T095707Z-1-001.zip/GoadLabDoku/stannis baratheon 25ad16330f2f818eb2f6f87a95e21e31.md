# stannis.baratheon

Account_Type: Domain User
Attack_Vector: GenericAll on computer kingslanding
Description: Lord of Dragonstone
Domain: sevenkingdoms.local
Group_Membership: Baratheon Family
Risk_Level: High
Status: Active