# jeor.mormont

Account_Type: Administrative
Attack_Vector: Administrative privileges
Description: Jeor Mormont
Domain: north.sevenkingdoms.local
Risk_Level: High
Status: Active