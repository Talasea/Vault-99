# robert.baratheon

Account_Type: Domain Admin
Attack_Vector: Protected User, Domain Admin privileges
Description: King of Westeros
Domain: sevenkingdoms.local
Group_Membership: Domain Admins, Small Council
Risk_Level: High
Status: Active