# tyrion.lannister

Account_Type: Domain User
Attack_Vector: Self membership on Small Council
Description: The Imp
Domain: sevenkingdoms.local
Group_Membership: Small Council, Lannister Family
Risk_Level: Medium
Status: Active