# joffrey.baratheon

Account_Type: Domain User
Attack_Vector: Write DACL on tyrion.lannister
Description: Prince
Domain: sevenkingdoms.local
Group_Membership: Baratheon Family
Risk_Level: High
Status: Active