# Critical Services

Configuration: MSSQL, Certificate Services, IIS
Network: CASTELBLACK (.22), BRAAVOS (.23)
Notes: Key exploitation targets for lateral movement