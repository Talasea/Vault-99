# jorah.mormont

Account_Type: Service Account
Attack_Vector: MSSQL execute as login + Trusted Links + LAPS password reading
Description: Ser Jorah the Andal
Domain: essos.local
Group_Membership: Mormont Family, Spys Group
Risk_Level: Critical
Status: Active