# Guest

Account_Type: Built-in
Attack_Vector: Standard Account
Description: Built-in account for guest access
Domain: north.sevenkingdoms.local
Risk_Level: Low
Status: Active