# Active Directory

Affected_Systems: sevenkingdoms.local ↔ essos.local trusts
CVSS_Score: 8,3
Exploitability: Advanced
GOAD_Specific: Yes
Impact: Cross-forest compromise, complete environment takeover
Remediation: Review trust relationships, implement SID filtering
Risk_Level: High
Vulnerability: Cross-Forest Trust Abuse