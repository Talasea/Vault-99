# Authentication

Affected_Systems: samwell.tarly (Password: Heartsbane)
CVSS_Score: 9,1
Exploitability: Easy
GOAD_Specific: Yes
Impact: GPO abuse via STARKWALLPAPER policy
Remediation: Remove password from description, rotate credentials
Risk_Level: Critical
Vulnerability: Password in LDAP Description Field