# missandei

Account_Type: Domain User
Attack_Vector: ASREPRoasting + GenericAll on khal.drogo
Description: Advisor to Daenerys
Domain: essos.local
Group_Membership: Targaryen Retinue
Risk_Level: Critical
Status: Active