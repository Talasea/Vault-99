# Web Application

Affected_Systems: CASTELBLACK IIS server
CVSS_Score: 7,5
Exploitability: Easy
GOAD_Specific: Yes
Impact: Web shell upload, remote code execution
Remediation: Disable file upload capability, implement upload restrictions
Risk_Level: High
Vulnerability: IIS ASPX File Upload