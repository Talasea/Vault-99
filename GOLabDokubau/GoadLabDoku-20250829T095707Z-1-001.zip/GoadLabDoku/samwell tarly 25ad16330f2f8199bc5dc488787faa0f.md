# samwell.tarly

Account_Type: Domain User
Attack_Vector: Password in LDAP description + GPO abuse
Description: Samwell Tarly (Password : Heartsbane)
Domain: north.sevenkingdoms.local
Risk_Level: Critical
Status: Active