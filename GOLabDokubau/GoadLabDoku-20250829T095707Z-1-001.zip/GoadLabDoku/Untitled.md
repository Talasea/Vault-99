0821 78985028





Daniel Ferdinand Hensen

16:06

smbclient //192.168.20.11/NETLOGON -U jon.snow

Daniel Ferdinand Hensen

16:07

smbclient //192.168.20.11/SYSVOL -U jon.snow