# SMB Signierung nicht erforderlich (CASTELBLACK)

Betroffene_Hosts: 192.168.20.22
CVSS_Score: 8,8
Ausnutzbarkeit: SMB Relay, Credential Theft
Empfohlene_Tools: ntlmrelayx, Responder