# petyr.baelish

Account_Type: Domain User
Attack_Vector: Small Council membership
Description: Littlefinger
Domain: sevenkingdoms.local
Group_Membership: Small Council
Risk_Level: Medium
Status: Active