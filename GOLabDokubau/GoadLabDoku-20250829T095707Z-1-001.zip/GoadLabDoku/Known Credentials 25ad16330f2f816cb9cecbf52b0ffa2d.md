# Known Credentials

Configuration: hodor:hodor, samwell.tarly:Heartsbane
Network: north.sevenkingdoms.local domain
Notes: Immediate access credentials for initial compromise