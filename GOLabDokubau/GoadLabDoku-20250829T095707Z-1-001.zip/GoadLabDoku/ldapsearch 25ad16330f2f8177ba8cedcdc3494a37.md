# ldapsearch

Dependencies: OpenLDAP client libraries
GOAD_Usage: LDAP enumeration, domain reconnaissance, anonymous binding tests
Installation_Method: ldap-utils package
Installation_Source: neue-ergebnisse-vor.md (usage examples)
Key_Features: LDAP queries, schema enumeration, bind testing
Performance_Optimization: Connection pooling, timeout settings
Version: System package