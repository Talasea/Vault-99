# Guest Account aktiviert

Betroffene_Hosts: 192.168.20.12,23
CVSS_Score: 4,3
Ausnutzbarkeit: Brute Force Attacks
Empfohlene_Tools: Hydra, Medusa