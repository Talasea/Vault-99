# Group Policy

Affected_Systems: STARKWALLPAPER GPO via samwell.tarly
CVSS_Score: 8,7
Exploitability: Moderate
GOAD_Specific: Yes
Impact: Domain-wide privilege escalation via scheduled tasks
Remediation: Review and restrict GPO permissions, implement delegation model
Risk_Level: High
Vulnerability: GPO Write Access Abuse