# rickon.stark

Account_Type: Domain User
Attack_Vector: Password Spraying - WinterYYYY pattern
Description: Rickon Stark
Domain: north.sevenkingdoms.local
Group_Membership: Stark Family
Risk_Level: Medium
Status: Active