# Active Directory

Affected_Systems: sansa.stark account
CVSS_Score: 8,8
Exploitability: Advanced
GOAD_Specific: Yes
Impact: TGT theft, privilege escalation
Remediation: Remove unconstrained delegation, implement constrained delegation
Risk_Level: High
Vulnerability: Unconstrained Delegation