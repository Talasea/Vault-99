# eddard.stark

Account_Type: Domain Admin
Attack_Vector: Domain Admin, LLMNR bot (5min intervals)
Description: Lord of Winterfell
Domain: north.sevenkingdoms.local
Group_Membership: Domain Admins, Stark Family
Risk_Level: Critical
Status: Active