
# Windows Server 2022 für Quereinsteiger

## Inhaltsverzeichnis

**1. Grundlagen und Einstieg in Windows Server 2022**
  - 1.1 Systemanforderungen und Editionsüberblick
  - 1.2 Windows Server 2022 Editions und Lifecycle
  - 1.3 Grundbegriffe: Server Core vs Desktop Experience, Rollen und Features
  - 1.4 Grundprinzipien der Serververwaltung für Quereinsteiger

**2. Installation, Erstkonfiguration und Grundnetzwerk**
  - 2.1 Installationsoptionen: Server Core vs Desktop Experience
  - 2.2 Erste Anmeldung und grundlegende Systemeinstellungen
  - 2.3 Netzwerkkonfiguration: IP, DNS, Hostname und Domänenbeitritt
  - 2.4 Sicherheits- und Updategrundlagen: Grundschutz und Updates

**3. Verwaltung und Automatisierung**
  - 3.1 Server Manager, MMC und grundlegende Verwaltungstools
  - 3.2 Windows Admin Center: zentrale Verwaltung
  - 3.3 PowerShell-Grundlagen und Remoting
  - 3.4 Automatisierung und Skripting: Grundlagen der Automatisierung

**4. Kernrollen und Dienste**
  - 4.1 Active Directory Domain Services – Grundlagen
  - 4.2 DNS-Server: Aufbau und Grundkonfiguration
  - 4.3 DHCP-Server: Zuweisung und Optionen
  - 4.4 Dateifreigaben, Storage Management und DFS-Grundlagen

**5. Virtualisierung, Speicher und Netzwerk**
  - 5.1 Hyper-V-Grundlagen und VM-Verwaltung
  - 5.2 Virtuelle Netzwerke und virtuelle Switches
  - 5.3 Storage Spaces, Storage Spaces Direct und SMB-Shared-Konfiguration
  - 5.4 Sicherung, Replikation und Grundsicherung von Hyper-V-Umgebungen

**6. Sicherheit, Updates und Zugriffsschutz**
  - 6.1 Sicherheitskonzepte und Baseline-Strategien
  - 6.2 Windows Defender for Server und Richtlinien
  - 6.3 Patch- und Update-Strategien (WSUS, Windows Update for Business)
  - 6.4 Firewall-Konfiguration und sicherer Remotezugriff

**7. Betrieb, Wartung und Notfallvorsorge**
  - 7.1 Backup- und Wiederherstellungsverfahren
  - 7.2 Monitoring, Logging und Performance-Analyse
  - 7.3 Notfallplanung, Migrationen und Rollouts
  - 7.4 Best Practices, Troubleshooting und Lernpfade


---

## KAPITEL: Grundlagen und Einstieg in Windows Server 2022

### 1.1 Systemanforderungen und Editionsüberblick

Windows Server 2022 setzt auf moderne Hardware und eine klare Editionsstruktur, die den Einsatz je nach Anforderung und Größe der IT-Infrastruktur erleichtert. Für Einsteiger ist es wichtig, die grundlegenden Hardwarevoraussetzungen zu kennen, um eine stabile Installation und ein solides Laufverhalten zu gewährleisten. Gleichzeitig bietet ein Überblick über die Editionsmöglichkeiten Orientierung bei Lizenzierung, Virtualisierung und hybriden Einsatzszenarien.

Grundlegende Systemanforderungen (Minimumziele)  
- CPU: 64-Bit-Prozessor mit mindestens 1,4 GHz, 2 Kerne werden empfohlen (bei größeren Systemen steigt der Bedarf entsprechend).  
- Arbeitsspeicher: Mindestens 512 MB RAM, für eine Desktop Experience (GUI) deutlich mehr, typischerweise 2 GB oder mehr. Für produktive Rollen wie Dateiserver, Hyper-V oder Domänencontroller sind 4–8 GB oder mehr sinnvoll.  
- Festplattenspeicher: Mindestens 32 GB freier Speicherplatz. Die tatsächliche Anforderung hängt stark von installierten Rollen, Funktionen und zukünftiger Speicherplatzreservierung ab.  
- Netzwerkanbindung: Eine Gigabit-Netzwerkverbindung wird empfohlen, insbesondere für Serverrollen wie DHCP, DNS, Dateiserver oder Hyper-V.  
- Zusätzliche Anforderungen: Moderne Mainboards, UEFI-Boot mit Secure Boot empfohlen; Daten- und Laufwerkstypen (z. B. NTFS/ReFS) je nach Rolle; Virtualisierungshardware sollte unterstützt werden, wenn Hyper-V geplant ist.

Editionsüberblick (Kernideen)  
- Standard: Leistungskernlizenzierung mit begrenzten Virtualisierungsmöglichkeiten (typisch 2 OSEs/VMs pro Lizenz) und ausreichenden Funktionen für kleine bis mittlere Umgebungen.  
- Datacenter: Unlimited Virtualisierung, erweiterte Funktionen für Rechenzentren und Private Clouds, ideal für dichte Virtualisierungsumgebungen.  
- Datacenter: Azure Edition: Spezielle Variante mit integrierten Hybridfunktionen für Azure-Integration und spezielle Lizenzbedingungen.

Beispiele, wie sich Editionen unterscheiden (vereinfacht):  
```
| Edition               | Virtualisierung | Hauptanwendungsfall                         | Typische Umgebung                      |
|-----------------------|----------------|---------------------------------------------|----------------------------------------|
| Standard              | Bis zu 2 VM-Instanzen pro Lizenz | Kleine bis mittlere Betriebe, Single-Server-Lösungen | Datei-/Druckserver, Remote-Apps         |
| Datacenter            | Unbegrenzt      | Rechenzentrums- und Multi-Host-Umgebungen       | Private Cloud, Virtualisierungshäuser   |
| Datacenter: Azure Edition | Unbegrenzt  | Hybrid-Szenarien mit Azure-Integration           | On-Premises mit stärkerer Cloud-Integration |
```

Hinweise zur Lifecycle-Policy  
- Windows Server 2022 folgt dem herkömmlichen Lifecycle-Modell von Microsoft: Mainstream-Support für einen festgelegten Zeitraum nach Veröffentlichung, gefolgt von erweitertem Support mit Sicherheitsupdates. Die konkreten Enddaten hängen von der Produktversion ab; aktuelle Details sollten immer in der Microsoft-Lifecycle-Dokumentation geprüft werden. Grundlegend gilt: planen Sie regelmäßige Sicherheitsupdates, Funktionsupdates und ggf. Lizenz- bzw. Activation-Strategien (KMS, MAK, Cloud-Activation).

Wichtige Praxis-Tipps  
- Prüfen Sie vor der Installation, ob die Hardware-Kompatibilitätsliste des Herstellers erfüllt ist.  
- Berücksichtigen Sie zukünftige Wachstumspläne (z. B. mehr VMs, zusätzliche Rollen) bei der Wahl der Edition.  
- Dokumentieren Sie Lizenzmodelle und Aktivierungswege (KMS, MAK, oder Cloud-Activation), um Compliance sicherzustellen.  
- Nutzen Sie Testumgebungen oder VMs, um Rollen und Updates risikofrei zu evaluieren, bevor produktiv migriert wird.

```
# Beispielbefehle zur ersten Informationsaufnahme
Get-WindowsEdition
Get-WindowsFeature
```

```
# Beispiel: Überblick über Edition und Aktivierung (lokal)
slmgr /dli
slmgr /xpr
```

### 1.2 Windows Server 2022 Editions und Lifecycle

Windows Server 2022 bietet unterschiedliche Editionen und folgt dem standardisierten Lifecycle-Modell von Microsoft. Die Editionspolitik beeinflusst Lizenzierung, Virtualisierungsmöglichkeiten, Funktionsumfang und den Einsatz in verschiedenen Umgebungen. Für Quereinsteiger ist es wichtig, die Unterschiede zu kennen, um eine passende Auswahl zu treffen und rechtzeitig über Updates und Support-Fristen informiert zu bleiben.

Wichtige Editionsmerkmale  
- Standard: Lizenzierung pro Kern, begrenzte Virtualisierung, geeignet für kleinere Umgebungen oder Einzelserver-Lösungen.  
- Datacenter: Unbegrenzte Virtualisierung, erweiterte Funktionen, ideale Lösung für Rechenzentren oder Private Clouds.  
- Datacenter: Azure Edition: Enthält Hybrid-Funktionen, die eine engere Integration mit Azure-Diensten ermöglichen; sinnvoll, wenn hybride Cloud-Szenarien geplant sind.

Lifecycle-Grundlagen  
- Mainstream-Support: Sicherheitsupdates, Funktionsupdates und technischer Support.  
- Erweiterter Support: Sicherheitsupdates über längeren Zeitraum nach Ende des Mainstream-Supports.  
- Microsoft aktualisiert regelmäßig die genauen Termine in der Lifecycle-Dokumentation; daher ist es sinnvoll, sich auf der offiziellen Website über aktuelle Enddaten zu informieren.

Lizenzierungsthemen im Überblick  
- Core-basierte Lizenzierung: Jede physische Kernkapazität des Servers muss lizenziert werden.  
- Virtualisierung: Standard erlaubt eine begrenzte Anzahl von betriebene VMs pro Lizenz, Datacenter ermöglicht unbegrenzte VMs.  
- Aktivierung: Typische Wege sind KMS (Key Management Service), MAK (Multiple Activation Key) oder Cloud-Aktivierung über Azure.

Beispielhafte Lizenz-Überlegungen  
- Ein physischer Server mit 24 Kernen: Bei Standard-Lizenzierung wären mindestens 24 Core-Lizenzen erforderlich; zwei OSE/VMs sind durch eine Standard-Lizenz abgedeckt, weitere VMs benötigen zusätzliche Lizenzierung.  
- Für eine virtuelle Infrastruktur mit vielen VMs ist Datacenter in der Regel wirtschaftlicher, da unbegrenzte Virtualisierungslizenzen gewährt sind.

Praktische Befehle und Checks  
```
# Anzeigen der aktuellen Edition und Installationsergänzungen
Get-WindowsEdition

# Prüfen, ob es sich um eine Datacenter oder Standard-Edition handelt
(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").EditionID

# Lizenzstatus prüfen (activation)
slmgr /dli
slmgr /xpr
```

Hinweise zur Planung  
- Dokumentieren Sie Ihre Anforderungen an Virtualisierung, Speicher, Netzwerkausstattung und Hybrid-Funktionen, bevor Sie eine Edition auswählen.  
- Prüfen Sie regelmäßig die Microsoft-Lifecycle-Policy, um passende Wartungsfenster und Enddaten zu kennen.  
- Beachten Sie, dass Hybrid-Optionen oft zusätzliche Planungen in Bezug auf Netzwerkkonfiguration, Identitätsmanagement (z. B. Azure AD) und Backups erfordern.

### 1.3 Grundbegriffe: Server Core vs Desktop Experience, Rollen und Features

In Windows Server 2022 unterscheiden sich die Bereitstellungsformen grundlegend durch zwei zentrale Konzepte: Server Core und Desktop Experience. Dazu kommen Rollen und Features, die das Funktionsspektrum eines Servers definieren. Ein klares Verständnis dieser Begriffe erleichtert die Planung, Installation und spätere Verwaltung, insbesondere für Quereinsteiger, die zunächst eine schlanke und zuverlässige Umgebung bevorzugen.

Server Core vs. Desktop Experience (GUI)  
- Server Core: Minimalinstallation ohne grafische Benutzeroberfläche; Fokus auf Stabilität, geringeren Ressourcenbedarf und geringeres Angriffsrisiko. Verwaltung primär über PowerShell, Remote-Verwaltungswerkzeuge und Windows Admin Center. Vorteil: geringerer Patch- und Wartungsaufwand; Nachteil: eingeschränkte lokale Bedienung.  
- Desktop Experience (GUI): Vollständige grafische Benutzeroberfläche und Shell; geeignet für Anwender, die sich stärker an herkömmlichen Windows-Administrationsprozessen orientieren oder komplexe GUI-Tools benötigen. Nachteil: höherer Ressourcenbedarf und potenziell größerer Sicherheits- und Wartungsaufwand.

Rollen und Features: Definition und Einsatzgebiete  
- Rollen (Roles): Bündeln Funktionen, die konkrete Aufgaben erfüllen. Beispiele: DNS-Server, DHCP-Server, Dateiserver und -dienste, Hyper-V, Active Directory Domain Services (AD DS).  
- Features: Ergänzende Funktionalitäten, die nicht zwingend eine eigenständige Aufgabe darstellen, aber für den Betrieb einer Rolle notwendig sind (z. B. Management-Tools, Failover-Clustering-Komponenten, Dienste wie Web-Server).  
- Installation und Verwaltung: Rollen werden meist in der Serverrolle installiert; Features können zusätzlich aktiviert bleiben oder separat entfernt werden, je nach Bedarf.

Verwaltungswege und Best Practices  
- Lokale Verwaltung: Server Manager (bei GUI-Version), MMC-basierte Snap-Ins, Command-Line-Tools.  
- Remote-Verwaltung: Windows Admin Center (zentraler Zugriff auf mehrere Server), PowerShell Remoting (Remote-Management über ps-Remoting).  
- Sicherheitsbewusste Verwaltung: Minimale installierte Rollen, regelmäßige Updates, Überwachung von Protokollen, Scope-Basierte Admin-Rechte (Least Privilege).  
- Typische Schritte zur Rolleninstallation per PowerShell (Beispiel: DNS-Rolle):  
```
Install-WindowsFeature -Name DNS -IncludeManagementTools
```
- Erweiterte Verwaltung: Verbindungsaufbau zu entfernten Servern über PowerShell Remoting oder Windows Admin Center, regelmäßige Sicherungen, Auditing und Monitoring aktivieren.

Um ein konkretes Verständnis zu ermöglichen, hier eine kompakte Gegenüberstellung:

```
| Bereitstellung | Typische Verwaltung |
|----------------|----------------------|
| Server Core    | PowerShell, Remote-Tools, Windows Admin Center |
| Desktop Experience | Lokale GUI, Server Manager, MMC-Snap-Ins, Windows Admin Center |
```

Beispiele für häufig genutzte Rollen und zugehörige Features (Auswahl)  
- DNS-Server: Rolle DNS, Management-Tools  
- DHCP-Server: Rolle DHCP, Management-Tools  
- Dateiserver: Rolle File and Storage Services, ggf. Distributed File System (DFS)  
- Hyper-V: Rolle Hyper-V, Management-Tools, ggf. Failover Clustering-Features  
- Active Directory: Rolle Active Directory Domain Services (AD DS)

Verwaltungshilfen und Schritt-für-Schritt-Beispiele  
- Überprüfen, welche Features vorhanden sind und welche installiert werden können:  
```
Get-WindowsFeature
```
- Eine neue Rolle installieren (Beispiel DNS):  
```
Install-WindowsFeature -Name DNS -IncludeManagementTools
```
- Server von GUI (Desktop Experience) zu Server Core wechseln (falls supported):  
```
# Hinweis: Der Wechsel zwischen GUI- und Core-Installation ist je nach Version unterschiedlich;
# hier wird die typische Vorgehensweise für den Wechsel beschrieben.
Uninstall-WindowsFeature -Name Server-Gui-Shell
Restart-Computer
```

Hinweis: In Windows Server 2022 ist der GUI-Umfang restriktiv gestaltet; der Wechsel von Core zu GUI kann je nach konkreter Bildversion variieren. Prüfen Sie vorab die verfügbaren GUI-Optionen mit Get-WindowsFeature und planen Sie denindest eine klare Entscheidung, um Komplexität zu minimieren.

### 1.4 Grundprinzipien der Serververwaltung für Quereinsteiger

Für Quereinsteiger ist eine schrittweise, methodische Herangehensweise an die Serververwaltung besonders hilfreich. Die folgenden Grundprinzipien unterstützen den Einstieg, fördern Nachhaltigkeit und erhöhen die Wahrscheinlichkeit, Betriebssysteme stabil und sicher zu betreiben.

Kernprinzipien  
- Zweckorientierte Architektur: Definieren Sie vorab die Rollen, die der Server erfüllen soll (Datei-Server, DNS/DHCP, Hyper-V, AD DS etc.). Vermeiden Sie „Jeden-Zugriff Alles“ und setzen Sie auf klare Verantwortlichkeiten.  
- Minimale Angriffsfläche: Starten Sie mit Server Core, wenn möglich, oder reduzieren Sie GUI-Anteil, um Sicherheitsrisiken zu minimieren. Deaktivieren Sie nicht benötigte Dienste.  
- Remote-Verwaltung bevorzugen: Nutzen Sie Windows Admin Center oder PowerShell Remoting, um serverseitige Änderungen von einem Verwaltungscomputer aus durchzuführen. Reduzieren Sie direkte physische Zugriffe.  
- Automatisierung und Konsistenz: Automatisieren Sie repetitive Aufgaben mittels Skripten (PowerShell) oder Desired State Configuration (DSC). Versionieren Sie Konfigurationen, um Reproduzierbarkeit zu gewährleisten.  
- Patch- und Sicherheitsmanagement: Planen Sie regelmäßige Updates, testen Sie Patches in einer Testumgebung, überwachen Sie Sicherheitsereignisse (Auditing und Ereignisprotokolle).  
- Backups und Wiederherstellung: Implementieren Sie regelmäßige Backups, testen Sie Wiederherstellungen, dokumentieren Sie Wiederherstellungsprozesse.  
- Monitoring und Logging: Verwenden Sie Monitoring-Tools, zentrale Logs und Warnungen; definieren Sie sinnvolle Metriken (CPU-Auslastung, RAM, Disk-I/O, Netztwerk).  
- Dokumentation: Halten Sie Mensch- und Prozess-Docu fest (Installationsschritte, Rollen, Netzwerkkonfiguration, Passwörter sicher verwahrt).  

Konkrete Einstiegsschritte für Einsteiger  
1) Grundaufbau planen: Welche Rollen werden benötigt? Welche SLAs gelten?  
2) Testumgebung aufsetzen: Eine VPS/VM oder Hyper-V-Host verwenden, um Rollen risikofrei zu evaluieren.  
3) Core-Installation erwägen: Beginnen Sie mit Server Core, testen Sie Remote-Verwaltung, erweitern Sie später bei Bedarf.  
4) Verwaltungstools installieren: Windows Admin Center auf dem Admin-Client installieren; PowerShell Remoting konfigurieren.  
5) Sicherheits- und Patchstrategie definieren: Grundkonfiguration, Firewall-Regeln, regelmäßige Updates planen.  
6) Erste Rolle implementieren: DNS oder Dateiserver als Einstieg; danach weitere Rollen schrittweise hinzufügen.  
7) Testszenarien durchführen: Failover, Backup-Wolltest, Wiederherstellung, Benutzer- und Berechtigungsprüfungen.

Beispielhafte Konfigurationsschritte (kompakte Darstellung)  
```
# Aktivierung von Remoting und Erster Zugriff
Enable-PSRemoting -Force

# Grundlegende Server-Rollen installieren (Beispiel DNS)
Install-WindowsFeature -Name DNS -IncludeManagementTools

# Liste der installierten Features prüfen
Get-WindowsFeature | Where-Object {$_.Installed -eq $true} | Select-Object DisplayName, Name
```

Zusammenfassung  
Die Grundlagen der Windows Server 2022-Verwaltung werden durch das Verständnis von Server Core vs Desktop Experience, Rollen vs. Features sowie durch eine strukturierte, remote gestützte Verwaltungsphilosophie getragen. Indem Sie mit klar definierten Zielrollen beginnen, schrittweise auf GUI-Funktionen verzichten oder diese gezielt einsetzen, und eine robuste Automatisierung, Dokumentation und Sicherheitsstrategie etablieren, legen Quereinsteiger den Grundstein für eine stabile, zukunftsorientierte Serverlandschaft.
## KAPITEL: Installation, Erstkonfiguration und Grundnetzwerk

### 2.1 Installationsoptionen: Server Core vs Desktop Experience

Windows Server 2022 bietet zwei grundsätzliche Installationsmodi, die sich in Umfang, Bedienung und Sicherheitsaspekten deutlich unterscheiden: Server Core (Headless-Installation) und Desktop Experience (Grafische Benutzeroberfläche). Die Wahl hat erhebliche Auswirkungen auf Ressourcenbedarf, Verwaltung, Sicherheitslage und späteren Wartungsaufwand. Die folgende Gegenüberstellung fasst zentrale Unterschiede zusammen und dient als Entscheidungsgrundlage für Quereinsteiger.

```
| Merkmal                                | Server Core                               | Desktop Experience                    |
|----------------------------------------|-------------------------------------------|--------------------------------------|
| GUI                                    | Nein                                      | Ja                                   |
| Ressourcenbedarf (RAM/CPU/Storage)     | Sehr gering                                | Höher                                 |
| Verwaltung                                 | Zentrale Verwaltungen über PowerShell, Remote Server Admin Tools, Windows Admin Center | Grafische Verwaltung lokal oder remote möglich (GUI) |
| Sicherheitslage                        | Geringere Angriffsfläche, weniger Updates | Größere Angriffsfläche, mehr Updates erforderlich |
| Typische Rollen/Anwendungen            | Domänencontroller, Dateidienste, Hyper-V, File-Server, Infrastruktur-Dienste | Ähnlich, aber weniger geeignet für stark skriptbasierte Verwaltung |
| Lernkurve für Quereinsteiger           | Höherer Einstieg durch Kommandozeile | Leichterer Einstieg durch GUI          |
| Update- und Patch-Strategie             | Wird oft automatisiert über WSUS/WUfB gesteuert | Ähnlich, aber GUI-Tools beschleunigen Konfiguration |
| Typische Einsatzszenarien              | Serversysteme mit geringem Overhead, Core-Only-Rollen | Entwickelte oder gemanagte Server mit grafischer Oberfläche |
```

Wichtige Hinweise:
- In Windows Server 2022 existiert sowohl Server Core als auch Desktop Experience. Die GUI-Option kann je nach Edition und Installation ausgewählt oder nachträglich als Feature ergänzt werden.
- Für produktive Querschnittsübungen ist Server Core oft die sicherere und ressourcenschonendere Wahl. Für Einsteiger, die sich zuerst mit der Konfiguration vertraut machen möchten, bietet Desktop Experience eine komfortablere Lernumgebung.
- Um GUI nachträglich zu installieren bzw. zu entfernen, eignen sich folgende PowerShell-Befehle:
```
Install-WindowsFeature Server-Gui-Mgmt-Infra, Server-Gui-Shell
```

```
Uninstall-WindowsFeature Server-Gui-Shell, Server-Gui-Mgmt-Infra
```

Beispiele für typische Aufgaben je Modus:
- Server Core: primär Remote-Verwaltung, PowerShell-Skripting, Windows Admin Center.
- Desktop Experience: manuelle GUI-Konfiguration, lokale Verwaltung, schnellere erste Schritte bei Netzwerkeinrichtungen.

Empfehlung für Einsteiger:
- Starte mit Desktop Experience, um Netzwerkeinstellungen, Domänenbeitritte und grundlegende Serverrollen visuell kennenzulernen.
- Plane später eine schrittweise Migration auf Server Core, um Security und Wartbarkeit zu erhöhen.

### 2.2 Erste Anmeldung und grundlegende Systemeinstellungen

Nach der Installation gilt es, die Ersteinrichtung sauber zu vollziehen, damit spätere Konfigurationen zuverlässig funktionieren. Die Schritte unterscheiden sich je nach Installationsmodus (Core vs GUI), aber die Grundprinzipien bleiben identisch: sichere Anmeldung, Namensgebung, Netzwerkkonfiguration und Grundlagen der Verwaltung.

Typische Ablaufsequenz:
- Erste Anmeldung am Server über die Konsole (bei Desktop Experience) oder per Remote-Verbindung (bei Server Core über PowerShell/Remoting). Der lokale Administrator ist standardmäßig vorhanden; bei der Erstkonfiguration ist ein sicheres Passwort erforderlich.
- Falls noch kein Passwort gesetzt ist, sofort ein starkes Kennwort setzen und ggf. Kennwortrichtlinien anpassen.
- Grundlegende Verwaltung anstoßen:
  - Aktivierung der Remotverwaltung (WinRM) zur späteren administrativen Fernsteuerung:
```
Enable-PSRemoting -Force
```
- Zeit- und Regionalsettings festlegen:
```
tzutil /s "Westeuropäische Normalzeit"   // oder die passende Zeitzone
```
- Management-Modus auswählen:
  - Mit Desktop Experience: über die grafische Oberfläche grundlegende Systemeinstellungen vornehmen.
  - Mit Server Core: über sconfig oder PowerShell weitere Einstellungen durchführen:
```
sconfig
```
- Vorbereitung auf Domänenbeitritt oder lokale Verwaltung:
  - Lokales Konto beibehalten oder ein dediziertes Administratorenkonto anlegen:
```
net user SERVERAdmin P@strongPa$$word123 /add
```
- Für eine schnelle erste Verwaltung per Remote-Verbindung ist der Zugriff per RDP möglich (im GUI-Modus). Für Core empfiehlt sich stattdessen PowerShell Remoting oder Windows Admin Center:
```
mstsc /v:WIN-SERVER-NAME
```

Wichtige Befehle für den Einstieg (Beispiele):
```
Rename-Computer -NewName W2K22-SERVER -Restart
```

```
Add-Computer -DomainName contoso.local -Credential (Get-Credential) -Restart
```

```
Test-Connection -ComputerName 8.8.8.8
```

Hinweise zur Verwaltung:
- In der Core-Variante ist der Schritt zur Ersteinrichtung häufig über sconfig leichter zu strukturieren.
- Dokumentiere Netzwerkpfade, Domainzugriffe und Admin-Accounts zentral, um spätere Nachweise und Audit-Trails sicherzustellen.
- Für langfristige Verwaltung empfiehlt sich der Einsatz von Windows Admin Center als zentrale Management-Oberfläche, unabhängig vom gewählten Installationsmodus.

### 2.3 Netzwerkkonfiguration: IP, DNS, Hostname und Domänenbeitritt

Eine stabile Netzwerkkonfiguration bildet die Grundlage für alle weiteren Aufgaben – insbesondere der Domänenbeitritt, zentrale Namensauflösung (DNS) und eine verlässliche Erreichbarkeit der Serverdienste. Die folgenden Schritte gelten sowohl für Server Core als auch Desktop Experience, wobei der konkrekte Weg (GUI vs PowerShell) variiert.

Schritte zur Netzwerkkonfiguration (PowerShell-Beispiele):
- IP-Adresse, Subnetzmaske und Gateway setzen:
```
# Beispiel: Ethernet-Verbindung verwenden
New-NetIPAddress -InterfaceAlias "Ethernet" -IPAddress 192.168.10.20 -PrefixLength 24 -DefaultGateway 192.168.10.1
```
- DNS-Serveradressen setzen:
```
Set-DnsClientServerAddress -InterfaceAlias "Ethernet" -ServerAddresses 192.168.10.1
```
- Hostnamen ändern (und ggf. Neustart einplanen):
```
Rename-Computer -NewName W2K22-SERVER01 -Restart
```
- Domänenbeitritt vorbereiten (Credential-Abfrage):
```
Add-Computer -DomainName contoso.local -Credential (Get-Credential) -Restart
```
- Test der Netzwerkkonnektivität und DNS:
```
Test-Connection -ComputerName contoso.local
nslookup contoso.local
```

GUI-Variante (falls Desktop Experience aktiv ist):
- Netzwerkverbindungen öffnen, Adapter auswählen, IPv4-Einstellungen bearbeiten.
- Hostname ändern: Systemsteuerung > System > Computernamen ändern.
- Domänenbeitritt: Systemsteuerung > Systemsteuerung > Computernamen > Ändern > Mitglied einer Domäne beitreten.

Wichtige Hinweise zur Namensauflösung und Domäne:
- AD-Domänen erfordern in der Regel eine passende DNS-Infrastruktur. Der Server sollte als DNS-Server fungieren oder DNS-Weiterleitungen/Glaubwürdigkeiten korrekt konfiguriert haben.
- Vermeiden Sie harte Codierungen von Servernamen in Skripten. Nutzen Sie stattdessen Variablen oder Hostname-Konvertierung, um Wartbarkeit zu erhöhen.
- Nach dem Domänenbeitritt ist ein Neustart oft sinnvoll, um alle Gruppenrichtlinienadaptionen zuverlässig zu übernehmen.

Diagnose-Checkliste:
- NetBIOS-/DNS-Namensauflösung prüfen:
```
nslookup <hostname>
```
- Verbindung zum Domänencontroller testen:
```
Test-Connection -ComputerName <DC-FQDN>
```
- Verwendete Netzwerkschnittstellen prüfen:
```
Get-NetAdapter | Format-Table -AutoSize
```

### 2.4 Sicherheits- und Updategrundlagen: Grundschutz und Updates

Ein sicherer Start ist zentral für jeden Windows-Server. Grundschutz umfasst eine robuste Basiskonfiguration, regelmäßige Updates, effektive Firewall- und Defender-Einstellungen sowie eine konsistente Auditierung. Die folgenden Empfehlungen geben eine praxisnahe Orientierung für Einsteiger.

Kernpunkte des Grundschutzes:
- Minimalinstallationen: Nur benötigte Rollen und Features installieren; nicht benötigte Dienste deaktivieren.
- Firewall konsequent nutzen: Eingehende Verbindungen nur für notwendige Ports zulassen (z. B. RDP, WinRM, DNS) und Standard-Ports sperren, wo sinnvoll.
- Antivirus/Defender aktivieren: Defender Antivirus ist integraler Bestandteil von Windows Server 2022; Echtzeitschutz und regelmäßige Scans sicherstellen.
- Patch-Strategie definieren: Automatische Updates bevorzugen, oder eine zentrale Patch-Strategie (WSUS/Windows Update for Business) implementieren.
- Auditing und Protokollierung: Relevante Ereigniskategorien erfassen und aufbewahren; zentrale Log-Strategien planen.

Wichtige Befehle und Beispiele:
- Defender aktivieren bzw. Status prüfen:
```
Set-MpPreference -DisableRealtimeMonitoring $false
```

```
Get-MpComputerStatus
```

- Windows-Updates automatisch verwalten (Beispiele mit PSWindowsUpdate-Modul):
```
Install-Module -Name PSWindowsUpdate -Force
```

```
Get-WindowsUpdate
```

```
Install-WindowsUpdate -AcceptAll -AutoReboot
```

- Grundlegende Firewall-Regel für Remotement okay:
```
New-NetFirewallRule -DisplayName "Allow WinRM Inbound" -Direction Inbound -Protocol TCP -LocalPort 5985 -Action Allow
```

- BitLocker-Verschlüsselung für sensible Systeme:
```
Enable-BitLocker -MountPoint "C:" -EncryptionMethod XtsAes256 -UsedSpaceOnly -RecoveryPasswordProtector
```

- Sicherheitsbaselines beachten:
  - Orientierung an allgemein anerkannten Baselines wie CIS Microsoft Windows Server 2022 Benchmark.
  - Dokumentierte Gruppenrichtlinien werden sorgfältig angewendet (lokal oder über AD-GPOs).

- Audit-Policies setzen (Beispiel):
```
auditpol /set /category:"Account Logon" /success:enable /failure:enable
```

- Backups sichern den Betrieb:
```
Install-WindowsFeature -Name Windows-Backup
```

Zusätzliche Empfehlungen:
- Aktivieren Sie regelmäßige Backups und testen Sie Wiederherstellungen regelmäßig.
- Verwenden Sie sichere Passwörter, Mehrfaktor-Authentifizierung dort, wo möglich, und за Domain-Accounts eingeschränkte Privilegien.
- Dokumentieren Sie Sicherheitsentscheidungen, Portfreigaben und Richtlinien in einem zentralen Leitfaden.

Die hier beschriebenen Grundprinzipien bilden eine solide Basis für den Einstieg in Windows Server 2022. Mit der Zeit können Sie dann gezielt weitere Rollen, Dienste und Sicherheitsmaßnahmen erarbeiten und adaptieren.
## Kapitel: Verwaltung und Automatisierung

### 3.1 Server Manager, MMC und grundlegende Verwaltungstools

Der Server Manager bildet unter Windows Server 2022 die zentrale GUI-basierte Konsole zur ersten Orientierung und grundlegenden Verwaltung eines Servers. Er erlaubt das gemeinsame Verwalten von Rollen, Features, lokalen und entfernten Servern in einer einheitlichen Oberfläche. Typische Aufgaben umfassen das Anzeigen des Server-Status, das Installieren oder Entfernen von Rollen und Features, sowie einfache Leistungs- und Ereignisüberwachung. Die Oberfläche bietet übersichtliche Dashboards, die Abhängigkeiten zwischen Rollendiensten sichtbar machen und eine schnelle Reaktion auf Warnungen ermöglichen.

Wichtige Konzepte:
- Zentralisierte Verwaltung mehrerer Server: Server Manager kann Server in einer Servergruppe zusammenfassen und so konsolidierte Kennzahlen und Tasks bereitstellen.
- Rollen und Features: Installation, Anpassung und Entfernen von Rollen (z. B. DHCP, DNS, Web-Server) sowie zugehöriger Verwaltungstools.
- Tools-Menü: Schneller Zugriff auf weitere Verwaltungsinstrumente wie Event Viewer, Leistungsüberwachung, Dienste oder Speicherverwaltung.

MMC (Microsoft Management Console) bietet eine flexible, separationsbasierte Verwaltungskonsole über Snap-Ins. Snap-Ins ermöglichen die Zusammenführung verschiedener Verwaltungstools in einer individuellen Konsole. Typische Snap-Ins sind:
- Ereignisanzeige (Event Viewer)
- Dienste (Services)
- Computerverwaltung (Computer Management)
- Leistungsüberwachung (Performance Monitor)

Beispiele und gängige Vorgehensweisen:
- MMC als leere Konsole öffnen und Snap-Ins hinzufügen:
  ```
  mmc
  ```
  In der geöffneten Konsole wählen Sie Datei → Snap-In hinzufügen und die gewünschten Elemente auswählen (Ereignisanzeige, Dienste, Leistungsüberwachung, etc.).
- Ereignisanzeige direkt starten:
  ```
  eventvwr.msc
  ```
- Computerspeicher- oder Dienste-Verwaltung direkt öffnen:
  ```
  compmgmt.msc
  services.msc
  ```
- Grundlegende Schritte zur Überwachung und Fehleranalyse:
  - Öffnen Sie das Event Log (Anwendungs- und Systemprotokolle) und prüfen Sie kritische Einträge.
  - Starten, stoppen oder konfigurieren Sie Dienste entsprechend den Betriebsanforderungen.
  - Prüfen Sie den Serverzustand (Verfügbarkeit von Speicher, CPU-Auslastung, Netzwerkkonnektivität) über den Leistungsmonitor.

Vorteile und Grenzen:
- Vorteil: Schnelle, lokal orientierte Verwaltung ohne zusätzliche Infrastruktur.
- Nachteil: Für verteilte Umgebungen oder heterogene Serverlandschaften sind spezialisiertere Tools erforderlich, insbesondere wenn Remote-Management, Auditing oder rollenbasierte Zugriffe zentral koordiniert werden sollen.

Laufende Aufgaben in der Praxis:
- Regelmäßiges Prüfen der Rollen- und Feature-Integrität.
- Konsistentes Monitoring wichtiger Dienste (z. B. DNS, DHCP, HTTP.sys).
- Dokumentation aller Änderungen in einer zentralen Versionskontrolle.

```
# Vorbereiten eines konsolidierten Konsolen-Setups
mmc

# Schnelle Startpunkte
eventvwr.msc
compmgmt.msc
services.msc
```

```
| Tool            | Zweck                               | Typische Anwendung                   |
| --------------- | ----------------------------------- | ------------------------------------ |
| Server Manager  | Zentralübersicht & Remote-Verwaltung | Rollen/Features, Health-Dashboard     |
| MMC (Snap-Ins)  | Build-your-own-Verwaltungskonsole     | Ereignisanzeige, Dienste, Leistung     |
| Ereignisanzeige | Protokolle und Diagnosen               | System-, Anwendungs- und Sicherheitslogs |
| Dienste          | Diensteverwaltung                      | Start/Stop, Starttyp, Abhängigkeiten  |
```

### 3.2 Windows Admin Center: zentrale Verwaltung

Windows Admin Center (WAC) ist eine moderne, browserbasierte Verwaltungsoberfläche, die Server, Hyper-V-Hosts, Storage Spaces und weitere Windows-Server-Ressourcen zentral zugänglich macht. Es ersetzt zwar nicht vollständig traditionelle GUI-Tools, ergänzt sie aber um eine zentrale Management-Instanz, die von einem Browser aus erreichbar ist. WAC erleichtert die Verwaltung mehrerer Server, nutzt Rollenbasierte Zugriffskontrollen und bietet Erweiterungen für spezifische Aufgabenbereiche (z. B. Hyper-V, IIS, SQL Server).

Kernfunktionen:
- Zentrale, browserbasierte Verwaltung mehrerer Server unabhängig von Remote-Verbindungen oder RDP-Sitzungen.
- Erweiterungen (Extensions) für spezifische Technologien wie Hyper-V, IIS, Failover Clustering oder Storage.
- Integrierte PowerShell-Umgebung, Audit-Logs und zentrale Benutzerverwaltung.
- Sichere Verbindungen über TLS, mit Gateway-Funktionalität zur Absicherung von Remote-Verbindungen hinter Firewalls.

Praktische Schritte zur Einführung:
- Voraussetzungen prüfen: unterstützte Windows Server-Versionen, Netzwerkzugang, TLS/HTTPS, ggf. AD-Anmeldung.
- Windows Admin Center installieren oder als Gateway-Server bereitstellen (Standardport 6516 für das Web-Interface; TLS ist empfohlen).
- Verbindungen hinzufügen: Servernamen oder IP-Adressen der zu verwaltenden Maschinen eintragen.
- Extensions installieren, um erweiterte Funktionen zu nutzen (z. B. Hyper-V- oder IIS-Verwaltung).
- Rollenspezifische Tasks ausführen: Starten von PowerShell-Sitzungen, Anzeigen von Logs, Ausführen von Wartungsaufgaben oder Patch-Management.

Sicherheit und Architektur:
- Zentrale Authentifizierung über Active Directory oder Azure AD, rollenbasierte Zugriffskontrollen (RBAC).
- Gateway-Funktion ermöglicht das Management hinter Firewalls, ohne direkte Remote-Verbindungen auf Zielserver zu eröffnen.
- Es wird empfohlen, für WAC ausschließlich isolierte Verwaltungskonten zu verwenden und regelmäßige Audits zu planen.

Beispielhafte Vorgehensweisen:
- Öffnen des Admin Centers: https://<WAC-Gateway>:6516
- Verbindung eines Servers hinzufügen und PowerShell-Sitzung starten.
- Installation von Extensions je nach Bedarf (Hyper-V-, IIS-Management etc.).

Vorteile gegenüber rein lokalen Tools:
- Konsolidierung der Verwaltung in einer einzigen Schnittstelle.
- Vereinfachte Verwaltung heterogener Umgebungen.
- Verbesserte Sicherheit durch zentrale Authentifizierung und RBAC.

```
https://<WAC-Gateway>:6516
```

| Aspekt | Vorteil | Hinweis |
|---|---|---|
| Zentralität | Einheitliche Managementoberfläche für mehrere Server | Erfordert Infrastruktur für Gateway/ RBAC |
| Erweiterbarkeit | Extensions für spezifische Technologien | Prüfen Sie Kompatibilität mit Server 2022 |
| Zugriff | Browser-basiert, remote nutzbar | TLS-Verschlüsselung verwenden, Benutzerrechte beachten |

### 3.3 PowerShell-Grundlagen und Remoting

PowerShell ist das zentrale Automatisierungs- und Verwaltungswerkzeug unter Windows Server. Es basiert auf objekten, die durch die Pipeline transportiert werden, und bietet eine umfangreiche Bibliothek von Cmdlets zur Systemverwaltung. Wichtige Grundkonzepte sind Cmdlets, Pipeline, Objekte, Funktionen, Module und Skripte. Die Sprache erlaubt das Erstellen wiederverwendbarer Bausteine (Funktionen) sowie das Importieren von Modulen, die spezifische Verwaltungsaufgaben kapseln.

Wichtige Konzepte:
- Cmdlets folgen dem Verb-Nomen-Muster, z. B. Get-Service, Install-WindowsFeature.
- Objekte statt Text: Cmdlets geben Objekte zurück, deren Eigenschaften in der Pipeline weitergegeben werden.
- Pipeline: Erlaubt das Kombinieren mehrerer Befehle in einer Flusskette, z. B. Filtern, Sortieren und Anzeigen.
- Remoting: Windows Remote Management (WinRM) ermöglicht Remote-Sitzungen und das Ausführen von Befehlen auf entfernten Computern.

Grundlegende Remoting-Kommandos:
- Prüfung der Remoting-Fähigkeit:
  ```
  Test-WSMan localhost
  ```
- Remoting aktivieren:
  ```
  Enable-PSRemoting -Force
  ```
- Eine Remote-Session öffnen:
  ```
  $session = New-PSSession -ComputerName Server01
  Enter-PSSession -Session $session
  ```
- Remote-Befehle ausführen:
  ```
  Invoke-Command -ComputerName Server01 -ScriptBlock { Get-Service w3svc }
  ```
- Sitzung beenden:
  ```
  Remove-PSSession $session
  ```
- Authentifizierung mit Anmeldedaten:
  ```
  $cred = Get-Credential
  Invoke-Command -ComputerName Server01 -Credential $cred -ScriptBlock { Get-Process }
  ```

Sicherheit und Best Practices:
- Verwenden Sie Kerberos innerhalb eines Domänennetzes; außerhalb der Domäne bevorzugen Sie HTTPS/WinRM mit Zertifikatsauthentifizierung.
- Beschränken Sie Remoting-Sitzungen auf notwendige Aufgaben (Just Enough Admin, JEA).
- Nutzen Sie PowerShell-Module statt direkter Skripte, um Abwärts- und Kompatibilitätsprobleme zu minimieren.
- Testen Sie Skripte zunächst in einer Entwicklungs- oder Testsituation, bevor Sie sie in der Produktion einsetzen.

Beispiele für einfache, wiederverwendbare Muster:
- Abfragen von Diensten auf mehreren Hosts mit Remoting:
  ```
  $servers = @("SRV01","SRV02","SRV03")
  foreach ($s in $servers) {
    Invoke-Command -ComputerName $s -ScriptBlock {
      Get-Service | Where-Object { $_.Status -eq 'Running' }
    }
  }
  ```
- Abfrage und Aggregation von System-Infos:
  ```
  Get-ComputerInfo -Property WindowsVersion, OsArchitecture
  ```

Ergänzend empfiehlt sich der Einsatz von constrained endpoints (JEA) für administrative Aufgaben, eine klare Protokollierung von Remoting-Aktivitäten und eine konsequente Versionskontrolle von Skripten.

### 3.4 Automatisierung und Skripting: Grundlagen der Automatisierung

Automatisierung bedeutet, wiederkehrende, fehleranfällige Aufgaben zu identifizieren, sie in wiederverwendbare Bausteine zu überführen und sie zuverlässig in festgelegten Abläufen auszuführen. In Windows Server 2022 ist PowerShell das zentrale Werkzeug hierfür. Die Grundprinzipien umfassen Idempotenz (ein Skript ändert den Zustand eines Systems nur, wenn nötig), robuste Fehlerbehandlung, klare Logausgaben und eine übersichtliche Struktur von Funktionen und Modulen.

Schlüsselkomponenten der Automatisierung:
- Planen von Tasks: Aufgabenplanung, regelmäßige Wartungs- oder Reinigungsjobs.
- Strukturierte Skripte: Funktionen, Parameter, Fehlerbehandlung, Logging.
- Module und Pakete: Wiederverwendbare Funktionsbibliotheken und Abhängigkeiten.
- Remote-Verwaltung: Invoke-Command, New-PSSession, PSRemoting zur gleichzeitigen Steuerung mehrerer Systeme.
- Sicherheit: Just Enough Administration (JEA) für beschränkte, kontrollierte Admin-Umgebungen.

Beispiele praktischer Anwendungsfälle:
- Mehreren Servern eine Rolle oder Feature installieren, inkl. Management-Tools:
  ```
  $servers = @("SRV01","SRV02","SRV03")
  $feature = "Web-Server"
  foreach ($s in $servers) {
    Invoke-Command -ComputerName $s -ScriptBlock {
      if ((Get-WindowsFeature -Name $using:feature).InstallState -ne 'Installed') {
        Install-WindowsFeature -Name $using:feature -IncludeManagementTools
      }
    } -ErrorAction Stop
  }
  ```
- Geplante Wartungsaufgabe mit Logging:
  ```
  $taskAction = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$PSScriptRoot\Maintenance.ps1`""
  $taskTrigger = New-ScheduledTaskTrigger -Daily -At 03:00
  Register-ScheduledTask -TaskName "Maintenance" -Action $taskAction -Trigger $taskTrigger -User "SYSTEM" -RunLevel Highest
  ```
- Beispiel-Logausgabe in Skripten:
  ```
  $logPath = "C:\Logs\Automation.log"
  try {
    # Hauptlogik
    "[$(Get-Date)] INFO: Aufgabe abgeschlossen" | Out-File -FilePath $logPath -Append
  } catch {
    "[$(Get-Date)] ERROR: $_" | Out-File -FilePath $logPath -Append
  }
  ```

Best Practices für Automatisierung:
- Planen Sie Änderungen zuerst in einer Testumgebung, verifizieren Sie Idempotenz.
- Verwenden Sie klare Namenskonventionen für Skripte, Module und Tasks.
- Verfolgen Sie Änderungen über Versionskontrolle (z. B. Git).
- Schreiben Sie umfangreiche Fehlermeldungen, um Ursachen schnell zu identifizieren.
- Nutzen Sie Module statt monolithischer Skripte, um Wartbarkeit zu erhöhen.
- Dokumentieren Sie Abhängigkeiten, Berechtigungen und Umgebungsparameter.

Hinweise zur Umsetzung:
- Beginnen Sie mit kleinen, isolierten Tasks und erweitern Sie Schritt für Schritt zu komplexeren Workflows.
- In produktiven Umgebungen sollten Sie JEA (Just Enough Administration) einsetzen, um Administratorrechte gezielt und sicher zu steuern.
- Automatisierung ist kein Selbstzweck; sie dient der Reproduzierbarkeit, Skala und der Reduzierung menschlicher Fehler.
## KAPITEL: Kernrollen und Dienste

### 4.1 Active Directory Domain Services – Grundlagen

Active Directory Domain Services (AD DS) bildet das zentrale Identitäts- und Autorisierungsmodell in Windows Server-Umgebungen. Es ermöglicht eine hierarchische Struktur aus Forests, Domains, Organizational Units (OUs) und Gruppenrichtlinien (GPOs). AD DS fungiert als mehrstufiges, verteiltes Verzeichnis, in dem Objekte wie Benutzerkonten, Computer, Drucker und Ressourcen katalogisiert sind und zentrale Authentifizierung sowie Autorisierung erfolgen. Wichtige Grundbegriffe:

- Forest: Oberste logische Einheit; umfasst eine oder mehrere Domains, die sich eine gemeinsame Konfigurations-Datenbank (Schema) teilen.
- Domain: Sicherheits- und Namensraum-Einheit; alle Objekte gehören einer Domain an.
- OU: Administrative Untergliederung innerhalb einer Domain, z. B. nach Abteilungen.
- Globaler Katalog (GC): Teilkopie des Verzeichnisses, der globale Suchvorgänge beschleunigt.
- FSMO-Rollen: Spezielle flexibel verteilte Rollen, die bestimmte zentrale Aufgaben übernehmen (z. B. Schema-, Domänen- und RID-Mublisher-Rollen).
- Gruppenrichtlinien (GPOs): Zentrale Konfigurations- und Sicherheitsregeln, die auf OU-Ebene oder Domänenebene angewendet werden.

In einer typischen Windows-Server-Umgebung dient AD DS dazu, Benutzer zu authentifizieren, Zugriffsrechte zu verteilen, Richtlinien durchzusetzen und Ressourcen zentral bereitzustellen. Für Quereinsteiger bedeutet dies: Ein Domain Controller ist der zentrale „Schlüsselbund“ für Konten und Berechtigungen; weitere DCs sorgen für Redundanz und Ausfallsicherheit.

Grundlegende Schritte bei der Inbetriebnahme eines AD DS-Teilnehmersystems:

- Planung der Struktur: Domänenname, Forest- und Domänenfunktionsebenen, OU-Struktur, GPO-Strategie.
- Installation der AD DS-Rolle auf einem Server.
- Promotion des Servers zum Domain Controller (DC) bzw. zur Domänenkontrollinstanz im bestehenden Forest.
- DNS-Integration: AD DS arbeitet eng mit DNS zusammen; eine AD- integriert DNS ist üblich und empfehlenswert.
- Grundkonfiguration: GC-Verwaltung, FSMO-Rollen, Replikations-Topologie, erste OU- und Benutzerstruktur.

Beispielhafte Befehle (als Einführung, je nach Umgebung anpassen):

```
Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
```

```
Install-ADDSForest -DomainName contoso.local -DomainNetbiosName CONTOSO -CreateDnsDelegation:$false -DatabasePath "C:\Windows\NTDS" -LogPath "C:\Windows\NTDS" -SysvolPath "C:\Windows\SYSVOL" -Force
```

```
Get-ADForest
Get-ADDomain
Get-ADDomainController -Filter *
```

Beispiel für eine OU- und Benutzeranlage (ohne vollständige Sicherheitseinstellungen):

```
New-ADOrganizationalUnit -Name "Mitarbeiter" -Path "DC=contoso,DC=local"
New-ADUser -Name "Max Mustermann" -GivenName "Max" -Surname "Mustermann" -UserPrincipalName "mmustermann@contoso.local" -AccountPassword (ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force) -Enabled $true -Path "OU=Mitarbeiter,DC=contoso,DC=local"
```

Wichtige Empfehlungen:

- Verwenden Sie eine sichere Standard-Passwortpolitik und regelmäßige Audits von Benutzerkonten.
- Planen Sie Global Catalog-Standorte sinnvoll, um Logon-Zeiten in Filialen zu optimieren.
- Aktivieren Sie sichere dynamische Updates im DNS, idealerweise AD-gekoppelte, integrierte Zonen.
- Dokumentieren Sie Domänen- und Forest-Strukturen einschließlich FSMO-Verteilungen.

### 4.2 DNS-Server: Aufbau und Grundkonfiguration

Der DNS-Dienst (Domain Name System) ist in Windows-Server-Umgebungen eng verknüpft mit AD DS. Er übersetzt Hostnamen in IP-Adressen und ermöglicht AD DS-basierte Dienste wie Kerberos-Authentifizierung, Service Locator (SRV-Einträge) und Domänen-Suche. Wichtige Konzepte:

- Zonen: Primär-, Sekundär- und AD- integrierte Zonen. AD-integrierte Zonen speichern Zoneninformationen in AD, erhöhen Sicherheit und Replikation.
- Forwarders: Weiterleitung von DNS-Anfragen an externe DNS-Server, z. B. ISP- oder Root-Server.
- Dynamic Updates: Erlauben automatisches Hinzufügen/Verändern von Datensätzen durch Clients (Dynamic DNS).
- Root-Hints: Standardorte für nicht-auflösbare Anfragen, um das Internet aufzulösen.

In einer typischen Server-Umgebung hostet der DNS-Server die Zonen der internen Domänen, ist oft gemeinsam mit AD DS installiert und konfiguriert. Best Practices:

- Verwenden Sie AD-gekoppelte Zonen, um Replikation und Sicherheit zu verbessern.
- Konfigurieren Sie sichere dynamische Updates, damit Clients nur autorisierte Änderungen vornehmen können.
- Legen Sie Forwarder fest, um Abfragen außerhalb des internen Netzwerks effizient weiterzuleiten.

Beispielhafte Befehle zur Grundkonfiguration:

```
Install-WindowsFeature -Name DNS -IncludeManagementTools
```

```
Add-DnsServerPrimaryZone -Name "contoso.local" -ReplicationScope "Domain"
```

```
Set-DnsServerForwarder -IPAddress 8.8.8.8
```

Validierung und Troubleshooting:

```
Resolve-DnsName contoso.local
nslookup contoso.local
Test-DnsServer -Name contoso.local
```

Tipps für AD-Integration:

- Stellen Sie sicher, dass die DNS-Zone mit AD DS verknüpft ist, damit AD DCs SRV-Einträge zuverlässig registrieren können.
- Überprüfen Sie regelmäßig die Replikation der DNS-Zonen zwischen Domain Controllern.
- Verwenden Sie DNSSEC kritisch, falls erhobene Sicherheitsanforderungen dies erfordern; in vielen Betrieben bleibt DNSSEC aktuell noch optional.

### 4.3 DHCP-Server: Zuweisung und Optionen

Der DHCP-Dienst vergibt automatisch IP-Adressen und zugehörige Parameter (Subnetzmaske, Standardgateway, DNS-Server, Domänenname) an Clients in einem Netzwerk. Vorteile sind zentrale Verwaltung, konsistente Netzwerkkonfiguration und einfache Adressverwaltung. Wichtige Konzepte:

- Scope: Ein definierter IP-Adressbereich innerhalb eines Subnetzes.
- Exklusionen: Bereiche innerhalb eines Scopes, die nicht automatisch vergeben werden.
- Optionen: Standardwerte wie Router (Gateway), DNS-Server, Domain Name.
- Reservierungen: Statische Zuordnung für bestimmte MAC-Adressen (z. B. Drucker, Server).
- Autorisierung: DHCP-Server muss vor der Zuweisung im AD autorisiert werden, um Missbrauch zu vermeiden.
- DHCP-Leases: Laufzeit, nach der Clients neue Adressinformationen erhalten.

In einer typischen Quereinsteiger-Umgebung wird der DHCP-Server eingesetzt, um Clients in einem Subnetz automatisch mit Adressen und zentralen Netzwerteinstellungen zu versorgen.

Beispielhafte Befehle zur Einrichtung:

```
Install-WindowsFeature -Name DHCP -IncludeManagementTools
```

```
Add-DhcpServerInDC
```

```
New-DhcpServerv4Scope -Name "Office" -StartRange 192.168.10.100 -EndRange 192.168.10.200 -SubnetMask 255.255.255.0 -LeaseDuration 01:00:00
```

```
Add-DhcpServerv4ExclusionRange -ScopeId 192.168.10.0 -StartRange 192.168.10.50 -EndRange 192.168.10.80
```

```
Set-DhcpServerv4OptionValue -DnsServer 192.168.10.1 -Router 192.168.10.1 -DomainName "contoso.local"
```

```
Add-DhcpServerv4Reservation -ScopeId 192.168.10.0 -IPAddress 192.168.10.150 -ClientId "00-11-22-33-44-55" -Name "Printer01"
```

Best Practices:

- Dokumentieren Sie Scope- und Reservierungs-Details sowie DHCP-Optionen.
- Planen Sie eine sinnvolle Subnetz- und VLAN-Struktur, um Broadcast-Domänen klein zu halten.
- Sichern Sie DHCP-Konfiguration regelmäßig (Backup der DHCP-Datenbanzen und Sichern der DHCP-Server-Config).
- Nutzen Sie ggf. DHCP-Policies oder Reservierungen für spezielle Clients.

### 4.4 Dateifreigaben, Storage Management und DFS-Grundlagen

Dateifreigaben bilden die tägliche Grundlage zur gemeinsamen Nutzung von Dateien. Windows File Server bietet SMB-basierte Freigaben, NTFS-Berechtigungen, Quota-Mechanismen und Storage-Management-Funktionen. DFS (Distributed File System) ergänzt Freigaben durch zentrale Namespace-Verwaltung und Replikation über mehrere Standorte hinweg.

Wichtige Bausteine:

- Dateifreigaben (SMB): Freigaben ermöglichen Netzwerkzugriff; NTFS-Berechtigungen steuern den Dateizugriff.
- Storage Management: Storage Spaces, Data Deduplication, File Server Resource Manager (FSRM) für Quotas und Dateiserver-Richtlinien.
- DFS Namespace (DFSN): Zentraler logischer Namespace, der mehrere Freigaben an einem konsistenten Pfad präsentiert.
- DFS Replication (DFSR): Replikation von Ordnern über mehrere Server hinweg, um Redundanz und lokale Zugriffsgeschwindigkeit zu verbessern.

Beispiele für konkrete Schritte und Befehle:

```
Install-WindowsFeature -Name FS-FileServer, FS-Data-Dedup, FS-Resource-Manager
```

```
New-SmbShare -Name "Docs" -Path "D:\Shares\Docs" -FullAccess "DOMAIN\Administrators" -ChangeAccess "DOMAIN\Users"
```

```
icacls "D:\Shares\Docs" /grant "CONTOSO\Employees:(OI)(CI)F"
```

```
Enable-DedupVolume -Volume "D:"
```

```
# File Server Resource Manager - Quotas
New-FsrmQuota -Path "D:\Shares\Docs" -SoftLimit 102400 -HardLimit 110000 -NotifyUser "admin@contoso.local" -NotificationDays 7
```

DFS-bezogen, erster Schritt ist die Installation der DFS-Rollen und das Anlegen eines Namespace:

```
Install-WindowsFeature -Name FS-DFS-Namespace, FS-DFS-Replication
```

```
New-DfsnRoot -Type DomainV2 -Name "Documents" -TargetPath "\\ServerA\Documents" -DomainName "contoso.local"
```

```
New-DfsnFolder -Path "\\contoso.local\Documents" -Name "Shared" -TargetPath "\\ServerA\Documents\Shared"
```

Replikationsgruppe (DFS Replication) einrichten:

```
New-DfsReplicationGroup -GroupName "DocsRep" -DomainName "contoso.local" -Description "Documents replication group"
Add-DfsReplicationGroupMember -GroupName "DocsRep" -FolderToSync "Shared" -ComputerName "ServerA"
Add-DfsReplicationGroupMember -GroupName "DocsRep" -FolderToSync "Shared" -ComputerName "ServerB"
```

Hinweise:

- DFS Namespace bietet einen zentralen Zugriffspfad, während DFSR die Replikation der Inhalte zwischen Servern übernimmt.
- Kombinieren Sie DFSN und DFSR sinnvoll, z. B. zentrale Freigaben, die an mehreren Standorten aktuell gehalten werden.
- Achten Sie auf Berechtigungen, Quotas und regelmäßige Backups der wichtigen Freigaben.

Dieses Kapitel bietet eine praxisnahe Orientierung zu den Kernrollen und Diensten in Windows Server 2022 für Quereinsteiger. Die Übungen unterstützen beim Verstehen von AD DS, DNS, DHCP sowie File Services und DFS-Grundlagen – zentrale Bausteine einer stabilen Serverinfrastruktur.
## KAPITEL: Virtualisierung, Speicher und Netzwerk

### 5.1 Hyper-V-Grundlagen und VM-Verwaltung

Hyper-V ist die Virtualisierungsschicht von Windows Server 2022 und bildet die Grundlage für das Erstellen, Verwalten und Verschieben von virtuellen Maschinen (VMs) auf einem physischen Server. Ziel dieses Unterkapitels ist es, die zentralen Konzepte, Begriffe und Arbeitsweisen praxisnah darzustellen, damit Quereinsteiger schnell eigenständige Hyper-V-Umgebungen aufbauen und administrieren können.

Zentrale Konzepte
- Hyper-V-Host: Der physische Server, der die Virtualisierungsdienste ausführt. Er stellt CPU-Ressourcen, Arbeitsspeicher, Speicher und Netzwerkkonnektivität für VMs bereit.
- VM: Eine isolierte Instanz mit eigenem Betriebssystem, eigener virtueller Hardware (vCPU, vRAM, virtuelle Festplatten, virtuelle Netzwerkschnittstellen).
- Generation 1 vs. Generation 2: Generation 1 nutzt BIOS-ähnliche Bootprozesse; Generation 2 verwendet UEFI, Secure Boot und unterstützen modernere Hardwaremerkmale. Viele moderne Gastbetriebssysteme profitieren von Generation 2, insbesondere bei Secure Boot.
- Virtuelle Festplatten und Speicher: VHD/VHDX-Dateien speichern Betriebssystem- und Anwendungsdaten. Dynamische Speicherzuweisung (Dynamic Memory) ermöglicht flexible RAM-Nutzung der VM.
- Integration Services: Treiber und Dienste, die die VM-Performance verbessern, z. B. Clock, KVP, Shutdown, Dynamic Memory-Integration.
- Checkpoints und Production Checkpoints: Checkpoints speichern den VM-Zustand zu einem Stichtag. Production Checkpoints nutzen VSS-gestützte Sicherungen auf Gastseite und gelten als sicherer für produktive Umgebungen.
- Live Migration und Storage Migration: Ermöglichen das Verschieben von VMs oder deren Speicher während des Betriebs, ohne Unterbrechung.

Grundlegende Schritte für eine Hyper-V-Installation und VM-Verwaltung
- Hyper-V installieren:
```
Install-WindowsFeature -Name Hyper-V -IncludeManagementTools -Restart
```
- Hyper-V-Manager nutzen oder Windows Admin Center verwenden, um Hosts, VMs und Switches grafisch zu verwalten.
- Eine VM erstellen, konfigurieren und starten:
```
New-VM -Name "DemoVM" -MemoryStartupBytes 2GB -Generation 2 -NewVHDPath "D:\HyperV\VMs\DemoVM.vhdx" -NewVHDSizeBytes 60GB -SwitchName "ExternalSwitch"
```
- VM-Einstellungen anpassen: CPU-Anzahl, dynamische Speicherzuweisung aktivieren, Integration Services aktivieren, Netzwerk-Adapter-Konfiguration mit VLAN-ID falls erforderlich.
- Sicherheitsaspekte: Shielded VMs (verfügbare Sicherheitsfunktion in Hyper-V) erfordern passende Infrastruktur (z. B. Shielded VM Keys) und sind besonders bei sensiblen Workloads sinnvoll.
- Backups und Wiederherstellung: Planen Sie regelmäßige Backups der VM-Dateien und Logs; testen Sie Wiederherstellungen regelmäßig, idealerweise außerhalb der Produktivumgebung.

Praxisbeispiele
- Einfache VM mit externem Netzwerkzugang und 4 vCPUs:
```
New-VM -Name "WebServer01" -MemoryStartupBytes 4GB -Generation 2 -NewVHDPath "D:\HyperV\VMs\WebServer01.vhdx" -NewVHDSizeBytes 100GB -SwitchName "ExternalSwitch"
Set-VM -Name "WebServer01" -ProcessorCount 4
```
- Änderung von Dynamischem Speicher auf der VM:
```
Set-VM -Name "WebServer01" -DynamicMemoryEnabled $true
```

Ausblick
Für komplexere Umgebungen ist das Verständnis von Live Migration, Failover-Clustering (für hohe Verfügbarkeit) und die Rolle von Windows Admin Center hilfreich. Zudem unterstützen moderne Windows-Server-Versionen Monitoring- und Logging-Features, die eine langfristige Stabilität sicherstellen. In weiteren Abschnitten werden konkrete Netzwerk- und Speicherstrategien sowie Replikationsmechanismen vertieft behandelt.

### 5.2 Virtuelle Netzwerke und virtuelle Switches

Virtuelle Netzwerke und virtuelle Switches bilden das Rückgrat der Netzwerkinfrastruktur einer Hyper-V-Umgebung. Sie ermöglichen die Trennung von Funktionen (Management, VM-Verkehr, Storage-Kommunikation), VLAN-Tagging, NAT-basierte Konnektivität und sichere Kommunikation zwischen VMs. In Windows Server 2022 stehen drei Hauptarten von virtuellen Switches sowie erweiterte Funktionen zur Verfügung.

Zentrale Switch-Typen
- Externer Switch: Verbindet virtuelle NICs direkt mit dem physischen Netzwerk. Ermöglicht VM-Gespräche mit dem Adressraum des physischen Netzwerks, DHCP-Servern und anderen Hosts. Ideal für produktive Server, Clients und Remote-Verwaltung.
- Interner Switch: Ermöglicht Kommunikation zwischen Hosts und VMs auf demselben Server, aber kein direkter Zugriff zum physischen Netzwerk. Praktisch für Testumgebungen, Management- oder Back-End-Kommunikation.
- Privater Switch: Erlaubt ausschließlich VM-zu-VM-Kommunikation innerhalb desselben Hyper-V-Hosts. Hohe Isolation, kein Zugriff von oder zum Host oder externen Netzwerken.

NAT-gestützte Switch-Option
- NAT-Switches ermöglichen VM-Netzwerke, die über eine NAT-Gateway-Adresse mit dem physischen Netzwerk kommunizieren. Sie eignen sich gut für isolierte Testumgebungen oder Demonstrationen ohne direkte Netzwerkkonfiguration am physischen Switch.
- Beispiel zur Erstellung eines NAT-Switches:
```
New-VMSwitch -SwitchName "NATSwitch" -SwitchType NAT -NATSubnetAddress 192.168.100.0/24
New-NetIPAddress -IPAddress 192.168.100.1 -PrefixLength 24 -InterfaceAlias "vEthernet(NATSwitch)"
```

VLAN-Tagging und Netzwerktopologien
- VLAN-IDs können pro VM-Netzwerkadapter festgelegt werden, um Netzwerkisolation zwischen VMs oder Zonen im Rechenzentrum sicherzustellen.
- Typische Anwendung: Unterschiedliche VLANs pro Abteilung oder Dienst (z. B. VLAN 10 für Web, VLAN 20 für DB).
- Beispielbefehl zur Festlegung eines VLANs:
```
Set-VMNetworkAdapter -VMName "WebServer01" -Name "Network Adapter" -VlanId 10
```

Netzwerk-Sicherheits- und Leistungsaspekte
- 802.1Q VLAN-Tagging ermöglicht klare Trennung innen und außen.
- QoS-Mechanismen können pro Switch oder VM-NIC konfiguriert werden, um wichtige Dienste wie Datenbanken oder Anwendungsfrontends zu priorisieren.
- Nutzen Sie externe Switches mit redundanten Verbindungen und Multi-NIC-Bindings, um Ausfallsicherheit zu erhöhen.

Beispiele und Merkhilfen
- Vergleichstabelle der Switch-Typen (als Codeblock)
```
| Switch-Typ | Zweck | Typische Einsatzszenarien |
| External    | Verbindung zum physischen Netzwerk | Produktive Server, Clients, Management |
| Internal    | Host-zu-VM-Kommunikation | Verwaltung, Back-End, Monitoring |
| Private     | VM-zu-VM-Kommunikation | Isolation, Testumgebungen |
```
- Beispiel für das Hinzufügen einer VM zur externen Verbindung und VLAN-Tagging:
```
New-VMSwitch -SwitchName "ExternalSwitch" -NetAdapterName "Ethernet0" -AllowManagementOS $true
Set-VMNetworkAdapter -VMName "AppServer01" -Name "Network Adapter" -VlanId 20
```

Ausblick
Eine gut geplante Netzwerktopologie mit korrekten VLAN-Zuweisungen, NAT-Switches für isolierte Umgebungen und redundanten Pfaden erhöht die Ausfallsicherheit der gesamten Hyper-V-Umgebung. In weiteren Abschnitten wird auf Storage- und Sicherungsaspekte eingegangen, die eng mit der Netzwerkinfrastruktur verknüpft sind.

### 5.3 Storage Spaces, Storage Spaces Direct und SMB-Shared-Konfiguration

Storage Spaces ermöglicht die Erstellung flexibler, robuster Speicherpools aus physischen Festplatten. Storage Spaces Direct (S2D) ergänzt diese Konzepte um eine skalierbare, softwaredefinierte Speicherarchitektur über mehrere Server hinweg. SMB-Shared-Konfiguration beschreibt die Bereitstellung von VM- und Dateifreigaben über SMB 3.x, ideal für geteilte VM-Dateien, VHDX-Dateien und Konfigurationen in hochverfügbaren Umgebungen.

Storage Spaces – Grundlagen
- Speicherpools bestehen aus physischen Festplatten, die zu einem logischen Pool zusammengeführt werden.
- Virtual Disks innerhalb des Pools bieten verschiedene Resiliency-Optionen:
  - Simple (keine Redundanz)
  - Mirror (2-Wege-Meshing: 2-Wege-Spiegelung oder 3-Wege-Spiegelung)
  - Parity (Daten- und Paritätsverteilung für effizienten Speicherplatz)
- Vorteile: Skalierbarkeit, einfache Erweiterung, bessere Fehlertoleranz im Vergleich zu traditionellem JBOD.

Storage Spaces Direct (S2D)
- S2D ist eine Hyper-Converged-Speicherlösung: Compute, Netzwerk und Storage werden gemeinsam als Cluster betrieben.
- Typische Architektur: Mindestens drei Nodes, qualifizierte Netzwerkverbindungen (NVMe/SSD für Cache, HDD für Kapazität), Shared-Nothing oder Clustered Storage.
- Vorteile: Hohe Verfügbarkeit, einfache Skalierung, integrierte Replikation über Knoten hinweg.
- Wichtige Schritte zur Aktivierung (stichwortartig):
  - Bereitstellung eines Failover-Clusters über die Knoten
  - Aktivierung von Storage Spaces Direct
  - Erstellung von Storage Pools, Virtual Disks und Volumes
- Typische Befehle (Beispiele)
```
Enable-ClusterStorageSpacesDirect
New-StoragePool -FriendlyName "Pool01" -StorageSubsystemFriendlyName "StorageSpacesSubsystem" -PhysicalDisks (Get-PhysicalDisk -CanPool $true)
New-VirtualDisk -StoragePoolFriendlyName "Pool01" -FriendlyName "VDisk01" -ResiliencySettingName Mirror -Size 1TB
New-Volume -StoragePoolFriendlyName "Pool01" -VirtualDiskFriendlyName "VDisk01" -FileSystem NTFS -Size 1TB
```

SMB-Shared-Konfiguration
- SMB-Sharing ermöglicht den Zugriff auf VM-Dateien, VHDX, Konfigurationen oder exportierte VMs über das Netzwerk. Für Hochverfügbarkeit empfiehlt sich eine Continuous Availability (CA) SMB-Freigabe, oft im Kontext eines SOFS (Scale-Out File Server) Clusters.
- Wichtige Konfigurationspunkte:
  - Freigaben erstellen und Berechtigungen vergeben
  - CA-SMB-Share aktivieren (unterstützt Unterbrechungsfreies Arbeiten)
  - SMB 3.x Funktionen wie Mehrkanal, SMB Direct (RDMA) nutzen, um Latenz zu senken und Durchsatz zu erhöhen
- Beispielfreigabe:
```
New-SmbShare -Name "VMStorage" -Path "D:\VMStorage" -FullAccess "DOMAIN\Admins" -CachingMode None
```
VM-Speicherpfade auf SMB konfigurieren
- Viele Hyper-V-Umgebungen speichern VM-Dateien (VHDX, Konfigurationen) auf SMB-Shares. Dies erleichtert Skalierung, Migration und Backup-Strategien.
- Wichtige Hinweise: Always-on-Verfügbarkeit, sorgfältige Netzwerk- und Berechtigungsplanung, Monitoring von SMB-Verbindungen.

Zwischenfazit
Storage Spaces und S2D bieten eine robuste, skalierbare Speicherinfrastruktur, die sich nahtlos in Hyper-V integriert. SMB-basierte Freigaben ergänzen diese Architektur, indem sie flexiblen, netzwerkbasierten Zugriff auf VM-Dateien ermöglichen. Für produktive Umgebungen ist eine sorgfältige Planung von Redundanz, Cache-Strategien und Netzwerkbandbreite erfolgskritisch. In der Praxis sollten Sie Tests zu Leistung, Failover-Verhalten und Backup-Strategien durchführen, bevor Sie produktive VMs darauf einsetzen.

### 5.4 Sicherung, Replikation und Grundsicherung von Hyper-V-Umgebungen

Eine solide Schutzstrategie für Hyper-V umfasst regelmäßige Backups, geprüfte Replikationsmechanismen und eine klare Notfallwiederherstellungsplanung. Ziel ist es, Verluste durch Hardwareausfall, Softwarefehler, Ransomware oder menschliche Fehler zu minimieren und eine schnelle Wiederherstellung zu ermöglichen.

Backup-Strategien
- VM- oder Gastbetriebssystem-Backups: Nutzen Sie VSS-kompatible Sicherungen, um konsistente Schnitte der VMs zu erhalten. Relevante Tools: Windows Server Backup, kommerzielle Backup-Lösungen (Veeam, DPM, Commvault) oder Hyper-V-spezifische Plugins.
- Host-Level-Backups: Erfassen Sie Hyper-V-Host-Konfigurationen, virtuelle Switches, Storage-Layouts und Failover-Cluster-Einstellungen, um im Katastrophenfall eine komplette Wiederherstellung zu ermöglichen.
- Production Checkpoints vs. normale Backups: Production Checkpoints bieten schnelle Wiederherstellungen, sollten aber nicht als alleinige Backup-Quelle dienen. Kombinieren Sie Production Checkpoints mit regelmäßigen, externen Backups.
- Testen von Backups: Führen Sie regelmäßig Wiederherstellungstests durch, idealerweise außerhalb der Produktionszeit, um die Integrität der Sicherungen und die Verfügbarkeit der Wiederherstellungspfade zu verifizieren.

Replikation und Hochverfügbarkeit
- Hyper-V-Replikation (Remote-Replikation) ermöglicht asynchrone Replikation von VMs auf einen separaten Standort. Sie dient zur DR (Disaster Recovery) und reduziert RPO/RTO.
- Grundlegende Schritte (Ansatz, nicht zwingend vollständige Kommandos):
  - Auf dem Primärhost Replikationsregeln konfigurieren und Replikationsziel (Sekundärhost) festlegen.
  - Zertifikatauthentifizierung oder Kerberos-Authentifizierung für die Sicherung der Replikation sicherstellen.
  - Wichtige VMs zur Replikation auswählen und Replikationszeitpläne festlegen.
- Typische Befehle (Beispiele):
```
Enable-VMReplication -VMName "FinanceDB" -ReplicaServer "ReplicaHost01" -AuthenticationType Kerberos -CompressionEnabled $true
```
- Failover-Strategien: Bei Ausfall des Primärstandorts kann per Software- oder manueller Failover der Replicapunkt aktiviert werden. Beachten Sie, dass Replikation regelmäßig getestet werden sollte, um im Ernstfall eine funktionierende Wiederherstellung sicherzustellen.

Sicherheitsaspekte und Governance
- Stellen Sie sicher, dass Backup- und Replikationsdaten verschlüsselt übertragen und gespeichert werden.
- Rollenbasierte Zugriffskontrollen (RBAC) und klare Auditierung helfen, unbefugte Änderungen zu verhindern.
- RPO (Recovery Point Objective) und RTO (Recovery Time Objective) definieren klare Ziele, anhand derer Ihre Backup- und Replikationsstrategie bewertet wird.

Praktische Hinweise
- Planen Sie Ressourcen für Speicher, Netzwerk und Rechenleistung entsprechend der erwarteten Backup- und Replikationslast.
- Automatisieren Sie regelmäßige Tests von Wiederherstellungen, um die tatsächliche Wiederherstellungsfähigkeit zu überprüfen.
- Dokumentieren Sie Ihre Infrastruktur, Backup-Pläne, Replikationsziele und Verantwortlichkeiten, um im Notfall effizient handeln zu können.

Beachten Sie bei der Umsetzung in Ihrer Umgebung die spezifischen Anforderungen an Compliance, Datenschutz und EU-/regionalen Vorgaben sowie die jeweiligen Lizenz- und Support-Rahmenbedingungen Ihrer Organisation.
## Kapitel: Sicherheit, Updates und Zugriffsschutz

### 6.1 Sicherheitskonzepte und Baseline-Strategien

Sicherheit in Windows Server 2022 basiert auf einem mehrstufigen Ansatz, der sich an Prinzipien der Abwehr in Tiefe (defense in depth), dem Prinzip der geringsten Privilegien und dem Zero-Trust-Gedanken orientiert. Ziel ist es, potenzielle Angriffsflächen frühzeitig zu reduzieren, Zugriffe nachvollziehbar zu machen und konsistente, überprüfbare Grundkonfigurationen bereitzustellen. Zentrale Bausteine sind Baselines, rollenbasierte Zugriffskontrollen (RBAC), Auditierung, Systemhärtung und organisatorische Prozesse zur Patch- und Änderungsverwaltung.

Wichtige Konzepte und Baseline-Strategien
- Defense-in-Depth: Mehrere Schutzschichten bündeln Schutzmechanismen auf Betriebssystem-, Anwendungs- und Netzwerkebene.
- Least Privilege: Admin-Rechte beschränken, nur notwendige Rollen zu vergeben; Einsatz von RBAC, JEA (Just Enough Administration) und kontrollierten Administrationspfaden.
- Härtung: Minimierung installierter Komponenten, Deaktivierung unnötiger Dienste, Minimierung offener Ports, standardisierte Sicherheitskonfigurationen.
- Security Baselines: Vorgefertigte Konfigurationsbausteine, z. B. Microsoft Security Compliance Toolkit (SCT) oder CIS-Benchmarks, die als Grundlage für GPOs oder lokale Richtlinien dienen.
- Auditing und Logging: Zentralisierte Protokollierung (Event Logs, Security Logs) und regelmäßige Auswertung, idealerweise mit SIEM-Integration.
- Richtlinienbasierte Steuerung: Gruppenrichtlinien (GPOs) und Administrative Templates zur konsistenten Durchsetzung von Sicherheitsmaßnahmen über Server-Gruppen hinweg.
- Standard-Checklisten: Erstellung einer dokumentierten Baseline-Checkliste, regelmäßige Validierung und Aktualisierung bei neuen Bedrohungen oder Rollenwechseln.

Um Baselines praktisch umzusetzen, können folgende Schritte helfen:
1) Bestandsaufnahme: Welche Rollen werden betrieben? Welche Dienste laufen? Welche Netzsegmente existieren?
2) Baseline auswählen: Versionsgerechte Baseline für Windows Server 2022 (z. B. Microsoft Security Baselines, CIS Benchmark).
3) Richtlinien erstellen: Eine dedizierte GPO mit den harten Konfigurationen, je OU nach Rolle verlinken.
4) Umsetzen: GPOs anwenden, Audit-Policies aktivieren, Sicherheitsoptionen konfigurieren.
5) Validierung: Konfigurationsüberprüfung, Änderungsprotokolle prüfen, regelmäßige Audits durchführen.
6) Monitoring und Wartung: Patch-Strategien, Anpassungen an geänderte Anforderungen oder Bedrohungslagen.

Beispielhafte Umsetzung (GPO-gestützt)
- Zielraum: Server OU
- GPO: Windows Server 2022 Baseline
- Wichtige Inhalte der Baseline: Kontosicherheitsrichtlinien, Auditing-Einstellungen, Minimierung der Dienste, Firewall-Grundregeln, WDAC/AppLocker-Grundsätze, Defender-Einstellungen.

Beispiel-Checkliste (als kompakte Übersicht)
```
| Bereich                  | Maßnahme                                           | Status | Hinweis                         |
|--------------------------|---------------------------------------------------|--------|---------------------------------|
| Konto- und Anmeldungen   | Kontosperrung / komplexe Passwörter                | Aktiv  | Mindestens 14 Zeichen, Komplexität  |
| Auditing                 | Globale Auditing-Policy aktivieren                    | Aktiv  | Ereignisse 4624/4625, 4648 u. a. |
| Defender Antivirus       | Echtzeitüberwachung aktiviert, Cloud-Schutz eingeschaltet | Aktiv  | Signaturen regelmäßig aktualisieren |
| Firewall                 | Standardregeln auf dem Serverprofil; unnötige Ports sperren | Aktiv  | Öffnung nur explizit benötigt     |
| Remotemanagement          | WinRM/PowerShell Remoting sichern; NLA aktivieren     | Aktiv  | Nur von genehmigten Hosts ausführen |
| Anwendungsblockierung     | WDAC oder AppLocker konfigurieren                    | Offen  | Nur geprüfte Anwendungen zulassen  |
```

Wichtige Werkzeuge und Ressourcen
- Security Compliance Toolkit (SCT) zur Verwaltung von Baselines
- Gruppenrichtlinienverwaltung und RSAT-Tools
- JEA (Just Enough Administration) zur begrenzten Remote-Verwaltung
- WDAC/AppLocker zur Software- und Script-Blockierung
- LAPS (Local Administrator Password Solution) zur Verwaltung lokaler Administrator-Passwörter

Praxisbeispiel: Grundkonfiguration per GPO
```
# Vorbereitung: RSAT-GPO-Management installieren
Install-WindowsFeature -Name RSAT-GPO-Tools

# GPO erstellen und verlinken
New-GPO -Name "Windows Server 2022 Baseline" -Comment "Härtung nach 2024-01"

# GPO mit OU verknüpfen
New-GPLink -Name "Windows Server 2022 Baseline" -Target "OU=Servers,DC=beispiel,DC=local"

# Richtlinienaktualisierung erzwingen
Invoke-GPUpdate -Target "SERVER01" -RandomDelayInMinutes 0
```

Aufbau dieser Subsektion
- Grundlagen der Sicherheitsarchitektur
- Baselines: Bedeutung, Auswahl, Umsetzung
- Praktische Umsetzung mit GPOs und Tools
- Beispiel-Checkliste und exemplarische Schritte

Die folgenden Unterkapitel vertiefen spezifische Bereiche der Sicherheits- und Verwaltungslandschaft von Windows Server 2022, von Defender-Strategien über Patch- und Update-Management bis hin zu Firewall- und Remotezugriffs-Konfigurationen.

---

### 6.2 Windows Defender for Server und Richtlinien

Windows Defender for Server umfasst die integrierte Microsoft Defender Antivirus-Lösung sowie ergänzende Sicherheitsfunktionen wie Cloud-Schutz, Verhaltensüberwachung, Erkennungslogik und Netzwerkschutz. Auf Servern bietet Defender eine robuste erste Verteidigungsebene, die sinnvoll mit Firewall-Richtlinien, App-Schutz (WDAC bzw. AppLocker) und umfangreichen Gruppenrichtlinien verknüpft wird. In größeren Umgebungen empfiehlt sich zudem die Integration von Microsoft Defender for Endpoint für erweiterte Erkennung, Threat Hunting und Endpunktschutz.

Wichtige Komponenten und Konfigurationspfade
- Defender Antivirus: Kernkomponente zum Schutz vor Malware und Ransomware. Verwaltung über Gruppenrichtlinien, Windows Security Center und Server-Admins.
- Defender Firewall mit erweiterten Sicherheitsregeln: Steuert eingehenden und ausgehenden Verkehr, lässt sich zentral über GPOs pflegen.
- WDAC/AppLocker: Blockiert unautorisierte Software und Script-Ausführungen; sinnvoll in Kombination mit Software-Whitelisting.
- Defender-Richtlinien via GPO: Konfigurationsmöglichkeiten finden sich in Computer Configuration > Administrative Templates > Windows Components > Microsoft Defender Antivirus.
- Cloud- und Submission-Einstellungen: Cloudbasierte Schutzmechanismen, automatische Schnitzeljagd von verdächtigen Signaturen (falls gewünscht).

Beispielhafte Konfigurationsschritte
1) Defender Antivirus aktivieren und Dienste sicherstellen:
```
# Sicherstellen, dass der Defender-Dienst läuft
sc start WinDefend
Set-Service -Name WinDefend -StartupType Automatic

# Echtzeit-Überwachung aktivieren
Set-MpPreference -DisableRealtimeMonitoring $false
```

2) Defender-Firewall-Regeln verwenden, um den Netzwerkzugriff zu regulieren:
```
# Beispielregel: Zulassen von Windows Admin Center-Verkehr (falls eingesetzt)
New-NetFirewallRule -DisplayName "WAC-HTTPS" -Direction Inbound -Protocol TCP -LocalPort 443 -RemoteAddress Any -Action Allow -Profile Any
```

3) Richtlinien für Defender Antivirus zentral setzen:
```
# Prüfen der aktuellen Einstellungen
Get-MpPreference

# Beispiel: Cloud-Schutz aktivieren
Set-MpPreference -CloudProtectionEnabled $true
```

4) WDAC/AppLocker als Ergänzung:
```
# Grundlagen einer WDAC-Policy (Publisher-basiert)
New-CIPolicy -Level Publisher -PolicyPath "C:\WDAC\Policies\WDAC.xml"
# Policy später in Binary umwandeln und anwenden
ConvertFrom-CIPolicy -PolicyPath "C:\WDAC\Policies\WDAC.xml" -BinaryPolicyPath "C:\WDAC\Policies\WDAC.bin"
```

Richtlinien- und Verwaltungsaspekte
- Empfohlene Praxis ist die zentrale Verwaltung von Defender-Einstellungen über Gruppenrichtlinien, um Inkonsistenzen zu vermeiden.
- Aktivieren Sie nur notwendige Funktionen und prüfen Sie regelmäßig Signaturen, Cloud-Schutz und automatische Abgleiche.
- Testen Sie neue Defender-Policyänderungen in einer isolierten Testumgebung, bevor Sie sie auf Produktion anwenden.
- Dokumentieren Sie Ausnahmen und Exclusions sorgfältig, da unbeabsichtigte Ausschlüsse Sicherheitslücken erzeugen können.

Beispielhafte Policy-Parameter (Übersicht)
```
| Komponente                  | Zu konfigurierende Parameter                   | Typische Einstellung       |
|-----------------------------|------------------------------------------------|----------------------------|
| Realzeitüberwachung         | DisableRealtimeMonitoring                      | $false (aktiv)             |
| Cloud-/Schnellschutz         | CloudProtectionEnabled, SignatureActivations    | $true, automatisiert        |
| Firewall                    | Interne Ausnahmen, Regeln für Defender-Integrationen | Konkrete Business-Notwendigkeiten |
| WDAC/AppLocker              | Policy-Wahl, Veröffentlichungsprüfung            | Publisher-basiert, Whitelisting  |
```

Best Practices
- Defender ist eine zentrale Säule, aber kein Allheilmittel. Ergänzen Sie ihn durch WDAC/AppLocker, Firewall, und RBAC.
- Halten Sie Defender-Signaturen und Cloud-Schutz stets aktuell.
- Dokumentieren Sie Ausnahmefälle gründlich und prüfen Sie sie regelmäßig.
- Verwenden Sie Testumgebungen, bevor Änderungen in der Produktionsumgebung implementiert werden.

---

### 6.3 Patch- und Update-Strategien (WSUS, Windows Update for Business)

Patch- und Update-Strategien sind entscheidend, um Systeme gegen bekannte Schwachstellen zu schützen. In Windows Server-Umgebungen kommen typischerweise zwei zentrale Ansätze zum Einsatz: WSUS (Windows Server Update Services) zur zentralen Bereitstellung und Steuerung von Updates innerhalb der Organisation, sowie Windows Update for Business (WUfB) für organisationsweite Richtlinien, Update-Deferral und automatische Bereitstellung. Die Wahl hängt von der Organisationsgröße, dem Risikoniveau, der Komplexität der Infrastruktur und dem Compliance-Kontext ab.

WSUS – zentrale Patch-Verwaltung
Ziele: Konsistente Update-Pipeline, Genehmigungen, Berichte und Minimierung von ungeplanten Neustarts. WSUS synchronisiert Updates von Microsoft Update, ermöglicht Genehmigungsworkflows pro Produkt- und Klassifikations-Ebene und bietet Status-Reports.

Typische Schritte
1) Planung und Architektur: Festlegung von Upstream- und Downstream-Servern, Speicherkapazität, Update-Klassen.
2) Installation der WSUS-Rolle: Server-Rolle installieren, Datenbank auswählen, Speicherziel anlegen.
3) Synchronisierung konfigurieren: Produkt- und Klassifikationsauswahl, Synchronisationszeitfenster.
4) Gruppenbildung und Genehmigungen: OU-basierte Gruppen (z. B. Server-Group, SQL-Server-Group) definieren.
5) Genehmigungen vergeben: Sicherheitsupdates, Kritische Updates, Sicherheits- und Qualitätsupdates je nach Reifegrad.
6) Bereinigung und Wartung: WSUS Cleanup Wizard, Datenbankwartung, Replikation prüfen.
7) Reporting: Statusberichte zum Patchstand und Compliance kontrollieren.

Beispielhafte Installations- und Erstkonfigurationsbefehle
```
# Installationsbefehle (WSUS-Komponenten)
Install-WindowsFeature -Name UpdateServices,UpdateServices-DB,UpdateServices-UI

# Erstkonfiguration des WSUS-Servers (Beispiel-PSCmdlet-Aufruf)
Invoke-WsusServerConfiguration -DatabaseServer "SQLSERVER\WSUS" -UpdateServerName "WSUS01.contoso.local" -Port 8080

# Aktivieren des Upstream-Servers
Set-WsusServer -UpstreamServerName "updates.microsoft.com" -Port 8530
```

Windows Update for Business (WUfB)
WUfB bietet eine alternativ- oder ergänzende Strategie, die Cloud-gestützt ist und sich in Microsoft Endpoint Manager (Intune) bzw. Gruppenrichtlinien bzw. Registrierungs-Schlüssel nutzen lässt. Typische Ziele sind Deferral-Optionen, Verzögerung von Funktionsupdates, verlässliche Update-Zeitfenster sowie eine vereinfachte Verwaltung in größeren Umgebungen.

Beispielhafte Gruppenrichtlinien-Prägung (Windows Update for Business)
```
# Hinweis: Die konkrete Umsetzung erfolgt über ADMX-Bundles; hier nur exemplarisch der Pfad
# Konfiguration über Gruppenrichtlinienpfad: Computer Configuration -> Administrative Templates -> Windows Components -> Windows Update

# Defer Feature Updates (Beispielwerte)
# DeferFeatureUpdatesPeriodInDays: DWORD = 365
# DeferQualityUpdatesPeriodInDays: DWORD = 30
```

Beispielhafte Registry- oder Policy-Parameter (WUfB)
```
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DeferFeatureUpdates" -PropertyType DWord -Value 1
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DeferFeatureUpdatesPeriodInDays" -PropertyType DWord -Value 365
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DeferQualityUpdates" -PropertyType DWord -Value 1
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Name "DeferQualityUpdatesPeriodInDays" -PropertyType DWord -Value 30
```

Best Practices und Hinweise
- Testphasen sind unverzichtbar: Neue Updates zuerst in einer Testgruppe evaluieren, Mitigation-Tests durchführen, Kompatibilitätsprüfungen mit Services/Rollenspezifika prüfen.
- Patch-Wartungsfenster planen: Neustarts außerhalb von Spitzenzeiten, Rückfallpläne bei fehlerhaften Updates.
- Backup und Wiederherstellung prüfen: Vor kritischen Patch- oder Update-Operationen Backups erstellen und Wiederherstellungszugänge sichern.
- Compliance-Dokumentation führen: Welche Updates wurden genehmigt, wer hat genehmigt, wann wurde installiert.

Berücksichtigen Sie, dass WSUS in größeren Rechenzentren oder Hybrid-Umgebungen oft die bevorzugte Lösung bleibt, während WUfB vor allem in Cloud-getriebenen oder gemanagten Umgebungen mit Intune sinnvoll ist.

---

### 6.4 Firewall-Konfiguration und sicherer Remotezugriff

Die Firewall ist eine zentrale Verteidigungslinie gegen unerlaubte Zugriffe. Windows Server 2022 verwendet Windows Defender Firewall mit erweiterten Sicherheitsregeln (WDF-ASF) als Standardlösung, die sowohl eingehende als auch ausgehende Verbindungen kontrolliert. Ein sicherer Remotezugriff erfordert eine strikte Absicherung von administrativen Wegen, Multi-Layer-Authentifizierung, Netzwerksegmentierung und den pragmatischen Einsatz von Jump-Hosts oder VPN-Verbindungen.

Grundprinzipien
- Standardregel: Eingehender Verkehr wird blockiert; nur explizit freigegebene Ports/Dienste werden geöffnet.
- Rollenbasierte Freigaben: Öffnen Sie Ports gezielt für bestimmte Serverrollen (z. B. SQL, Datei-Server, Remoteverwaltung).
- Remote-Management sichern: Remote-Verbindungen bevorzugt über VPN oder Jump-Host; direkte Exposition von RDP ins Internet vermeiden.
- Verschlüsselung und Authentifizierung: Nutzung von TLS/HTTPS, NLA (Network Level Authentication) für RDP, gesicherte WinRM-Verbindungen.
- Monitoring und Audit: Firewall-Logs aktiv überwachen; regelmäßig Zugriffsnachverfolgung prüfen.

Beispiele für wichtige Regeln und Konfigurationen
1) RDP-Zugriff einschränken
- Direktes RDP-Port 3389 aus dem Internet blockieren.
- Zugriff über eine genehmigte Management-Lösung oder eine VPN-Verbindung ermöglichen.

2) WinRM-Remoteverwaltung sicher konfigurieren
- WinRM-Ports 5985 (HTTP) und 5986 (HTTPS) gezielt öffnen, bevorzugt HTTPS.
- Zugriff auf WinRM-Ressourcen einschränken (z. B. IP-Whitelist von Verwaltungs-Subnets).

3) Just-In-Time-Management und Bastion-Ansatz
- Einsatz von JEA (Just Enough Administration) für administrative Aufgaben.
- Nutzung eines Jump-Servers oder Admin-Gateway-Schnittstelle.

Beispielhafte PowerShell-Konfiguration
```
# WinRM Remoting aktivieren
Enable-PSRemoting -Force

# Firewall-Regeln für WinRM (HTTP/HTTPS)
New-NetFirewallRule -Name "WinRM-HTTP" -DisplayName "WinRM over HTTP" -Protocol TCP -LocalPort 5985 -Direction Inbound -Action Allow -Profile Any
New-NetFirewallRule -Name "WinRM-HTTPS" -DisplayName "WinRM over HTTPS" -Protocol TCP -LocalPort 5986 -Direction Inbound -Action Allow -Profile Any

# RDP-Zugriff kontrollieren: Blockieren standardmäßig eingehend
New-NetFirewallRule -DisplayName "Block-RDP-Inbound" -Direction Inbound -Protocol TCP -LocalPort 3389 -Action Block -Profile Any

# RDP nur von Management-Subnetz aus zulassen (Beispiel)
New-NetFirewallRule -DisplayName "Allow-RDP-Management" -Direction Inbound -Protocol TCP -LocalPort 3389 -RemoteAddress 192.168.100.0/24 -Action Allow -Profile Any
```

Weitere Maßnahmen
- Netzwerksegmentierung: Trennung von Verwaltungsnetzen, Servernetzen und Externen, um den Angriffsraum zu verkleinern.
- VPN oder Remote-Access-Gateways: Einrichtung von VPN-Verbindungen oder Remote Desktop Gateway für RDP-Zugriff, statt direkter RDP-Öffnung.
- RJ-Management-Tools: Aktivieren Sie nur notwendige Management-Dienstleistungen (z. B. WinRM, WMI) mit starken Zugriffskontrollen.
- JEA und Sandbox-Umgebungen nutzen: Begrenzen Sie administrative Aufgaben auf minimale, auditierbare Umgebungen.
- Monitoring: Erstellen Sie regelmäßige Reports zu Firewall-Änderungen, Zugriffen und Blockierungen, integrieren Sie diese in Security-Information- und Event-Management-Systeme.

Zusammenfassung dieser Sektion
- Eine sichere Server-Administration erfordert eine gezielte Freigabenpolitik, sichere Remotezugriffe und eine konsequente Netzsegmentierung.
- PowerShell-Befehle bieten eine flexible, reproduzierbare Möglichkeit zur Steuerung der Firewall- und Remotemanagement-Richtlinien.
- JEA, Jump-Hosts, VPNs und TLS-basierte Verbindungen reduzieren das Risiko direkter Angriffe auf RDP und WinRM.
- Dokumentation, regelmäßige Audits und eine klare Patch- und Änderungsverwaltung tragen wesentlich zur nachhaltigen Sicherheit bei.
## KAPITEL: Betrieb, Wartung und Notfallvorsorge

### 7.1 Backup- und Wiederherstellungsverfahren

Eine robuste Backup- und Wiederherstellungsstrategie ist ein zentraler Bestandteil jeder IT-Betriebsführung. Ziel ist es, Datenverlust zu minimieren, Systemverfügbarkeit sicherzustellen und im Ereignisfall eine schnelle Wiederherstellung zu ermöglichen. Wichtige Konzepte sind RPO (Recovery Point Objective) und RTO (Recovery Time Objective) sowie die 3-2-1-Regel: mindestens drei Kopien der Daten, auf zwei unterschiedlichen Speichermedien, eine Kopie außer Haus.

Typische Backup-Arten
- Vollständige Backups: alle ausgewählten Daten zu einem Zeitpunkt. Schnell in der Wiederherstellung, aber speicherintensiv.
- Inkrementelle Backups: nur geänderte Blöcke seit dem letzten Backup. Schneller und weniger Speicherbedarf, aber Wiederherstellungsschritte komplexer.
- Differentielle Backups: geänderte Blöcke seit dem letzten Vollbackup. Kompromiss aus Zeitbedarf und Wiederherstellungsgeschwindigkeit.
- Bare-metal-Backups (Bare-Metal Restore): vollständige Abbildung der Systemfestplatte inklusive Betriebssystem, Treibern und Anwendungen für eine komplette Wiederherstellung.
- Systemzustands-Backups: Sicherheit wichtiger Komponenten wie Active Directory, Registrypfade, Boot-Konfiguration.

Windows-Server-Backup-Optionen und Umsetzung
- Windows Server Backup (WSB) ist das integrierte Werkzeug für lokale Backups. Es basiert auf VSS und unterstützt Systemzustand, Bare-Metal-Backups und volumenbasierte Sicherungen.
- Für größere Umgebungen oder komplexe Anforderungen kommen ergänzende Lösungen wie System Center Data Protection Manager (DPM) oder Cloud- bzw. Hybrid-Backups (z.B. Azure Backup) zum Einsatz.
- Der praktische Einsatz erfolgt über WBAdmin (Kommandozeile) oder über Console-Tools in der GUI. Typische Anforderungen sind regelmäßige Backups der vitalen Serverrollen (Domänencontroller, Hyper-V-Hosts, Dateiserver, SQL-Instanzen).

Beispielkonfigurationen und typische Befehle
- Backup-Plan aktivieren (Zielvolumen D:, zu sicherndes Laufwerk C:, alle kritischen Komponenten):
```
wbAdmin enable backup -backupTarget:D: -include:C: -allCritical -vssFull -quiet
```
- Vollbackup eines Zeitplans starten (Beispielziel D:, inkl. C: und D:):
```
wbAdmin start backup -backupTarget:D: -include:C:,D: -allCritical -vssFull -quiet
```
- Versionsstände auslesen und alte Versionen verwalten:
```
wbAdmin get versions -backupTarget:D:
```
- Systemzustand-Backup erstellen (wichtig für Domänencontroller und kritische Systeme):
```
wbAdmin start systemstatebackup -backuptarget:E: -quiet
```
- Wiederherstellung von Volumen auf einen Zielort (Beispiel):
```
wbAdmin start recovery -version:YYYYMMDDHHMM -itemType:Volume -items:C: -recoveryTarget:D:\Wiederherstellung -overwrite
```

Planung und Validierung
- Legen Sie RPO und RTO für jede kritische Komponente fest und dokumentieren Sie Backup-Zeiten.
- Testen Sie regelmäßige Wiederherstellungen in einer isolierten Testumgebung, mindestens einmal pro Quartal.
- Automatisieren Sie Benachrichtigungen über Backup-Status, fehlgeschlagene Backups und Speicherplatzbedarf.
- Bewerten Sie Offsite- und Offline-Backups (Tape oder Cloud) als Teil der 3-2-1-Strategie und dokumentieren Sie Wiederherstellungswege.

Hinweise
- Beachten Sie Speicherplatz- und Leistungswirkungen von Backups, insbesondere bei produktionsnahen Systemen.
- Verifizieren Sie Backups regelmäßig durch Integritätsprüfungen und Logs.
- Erstellen Sie klare Runbooks: wer führt welches Backup aus, wie werden Wiederherstellungen validiert, wer kommuniziert den Vorfall?

### 7.2 Monitoring, Logging und Performance-Analyse

Betriebsqualität hängt wesentlich von proaktiver Überwachung, zentralem Logging und fundierter Performance-Analyse ab. Ein klares Monitoring-Konzept ermöglicht frühzeitige Probleme zu erkennen, Kapazitätsengpässe zu vermeiden und die Verfügbarkeit zu sichern. Die Kernbestandteile sind Logs, Metriken, Dashboards und automatisierte Alarmierung.

Logging und Ereignis-Management
- System-Logbuch (System/Anwendung/Sicherheit) liefert Hinweise auf Hardwarefehler, Treiberprobleme, Sicherheitsereignisse und Anwendungsfehler.
- Windows Event Logs sollten zentralisiert gesichert, indiziert und regelmäßig auf kritische IDs geprüft werden.
- Wichtige Tools: Event Viewer (GUI), Windows Event Forwarding (WEF) für zentrale Protokollierung, Get-WinEvent bzw. Get-EventLog über PowerShell.

Performance-Monitoring und Analyse
- Performance Counter erfassen CPU-Nutzung, Speichernutzung, Netzlast, Festplatten-I/O und Speicherseitenfluss.
- Ressourcen-Mamagement mit Tools wie Resource Monitor, Task Manager und PerfMon (Performance Monitor) zur Detailanalyse von Engpässen.
- Data Collector Sets in PerfMon ermöglichen automatisierte Datensammlungen über definierte Zeiträume.

Beispielkonfigurationen und Befehle
- Letzte Systemfehler seit dem letzten Neustart abrufen:
```
Get-WinEvent -FilterHashtable @{LogName='System'; Level=2} -MaxEvents 50
```
- Neueste Anwendungsfehler in der Ereignisanzeige extrahieren:
```
Get-WinEvent -FilterHashtable @{LogName='Application'; Level=2} | Select-Object TimeCreated, ProviderName, Id, Message -First 50
```
- Systemressourcen-Injektion in Echtzeit (CPU-Auslastung) erfassen:
```
Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 2 -MaxSamples 60 | Select-Object -ExpandProperty CounterSamples
```
- Systemleistung regelmäßig protokollieren und als CSV exportieren:
```
Get-Counter '\Processor(_Total)\% Processor Time','\Memory\Available MBytes' -SampleInterval 5 -MaxSamples 120 | ForEach-Object { $_.CounterSamples } | Export-Csv -Path 'C:\Logs\performance.csv' -NoTypeInformation
```

Monitoring-Strategie
- Definieren Sie zentrale Dashboards (CPU-Auslastung, Speicherauslastung, Disk I/O, Netzwerkverkehr) und klare Alarmstufen (Warnung, kritisch).
- Implementieren Sie zentrale Log-Speicherorte, rollenbasierte Zugriffskontrollen und regelmäßige Backup der Logs.
- Planen Sie regelmäßige Review-Meetings zur Kennzahlen-Entwicklung und zur Anpassung von Schwellenwerten.

Lernpfade und Abdeckung
- Nutzen Sie Microsoft Learn-Module zu Monitoring, Logging und Performance unter Windows Server 2022.
- Ergänzend unterstützen Praxislabore mit realen Szenarien (Ausfall einer Netzwerkschnittstelle, plötzliche Speicherknappheit, plattformübergreifende Integrationen).

### 7.3 Notfallplanung, Migrationen und Rollouts

Notfallvorsorge umfasst Notfallpläne (Disaster Recovery Plans), Migrationspfade zu neuen Servern oder Plattformen und strukturierte Rollouts von Updates oder neuen Diensten. Ziel ist eine koordinierte, reproduzierbare und zeitlich definierte Reaktion auf Vorfälle sowie eine sichere, nachvollziehbare Migration von Diensten mit minimaler Betriebsunterbrechung.

Notfallplanung (DRP)
- Ziele und Geltungsbereich festlegen: Welche Systeme sind kritisch? Welche Daten müssen innerhalb eines definierten RTO wiederhergestellt werden?
- Verantwortlichkeiten und Kommunikationswege definieren: wer löst den Vorfall aus, wer informiert Stakeholder, wer führt die Wiederherstellung durch?
- Runbooks erstellen: Schritt-für-Schritt-Aktionen, Prüfpunkte, Rollback-Szenarien, Kommunikationsvorlagen.
- Offsite-Backups und Notfallstandorte sicherstellen: Replizierte Daten, Netzwerkverbindungen, Zugangskontrollen.
- regelmäße DR-Tests: Klare Testpläne, dokumentierte Ergebnisse, Lessons Learned.

Migrationen und Rollouts
- InfrastrukturbestandteileInventory: Serverrollen, Abhängigkeiten, Replikationspfade, DNS/AD-Topologie.
- Migration-Strategien: 
  - In-place Upgrades: Aktualisierung von bestehenden Servern auf Windows Server 2022, unter Berücksichtigung kompatibler Rollen und Anwendungen.
  - Migration zu neuen Servern/Hypervisoren: Kopie von Daten, Neuinstallation von Diensten, schrittweise Umschaltung.
  - Domänen- und Identitätsmigration: FSMO-Rollen-Verlagerung, DNS-Replikation, ggf. Entkoppeln alter DCs.
- Typische Schritte:
  1. Bestandsaufnahme und Kompatibilitätsprüfungen.
  2. Testmigration in einer isolierten Umgebung durchführen.
  3. Backup- und Rollback-Pläne finalisieren.
  4. Produktionsmigration schrittweise durchführen (First Primary, danach Secondary).
  5. Validierung der Services nach jeder Phase (Authentifizierung, Freigaben, DNS, Replikation).
  6. Endgültige De-Privation alter Systeme (Decommissioning) und Dokumentation.

Beispiel-Checkliste für eine Server-Migration
- Inventar: Rollen, Abhängigkeiten, Netzwerk-IPs, DNS-Einträge, Replikationspfade.
- Kompatibilität: Treiber, Anwendungen, Skripte.
- Backup-Verifizierung: Vollständiges Backup vor der Migration, Testwiederherstellung.
- Rollout-Plan: Zeitfenster, Ausweichmöglichkeiten, Kommunikationsplan.
- Validierung: Login-Funktion, Dateizugriff, Dienste laufen, Logging aktiv.
- Notfall-Rollback: Vorgehen, Grenzen der Wiederherstellung, Zeitfenster.

Hinweise zu Rollouts
- Phasenbasierte Rollouts minimieren Risiko, ermöglichen Feedback aus frühen Phasen.
- Testen Sie nach jeder Phase die Geschäftsprozesse intensiv, bevor der nächste Abschnitt migriert wird.
- Dokumentieren Sie alle Änderungen, führen Sie Audits und Freigaben nach.

### 7.4 Best Practices, Troubleshooting und Lernpfade

Best Practices
- Patch- und Update-Management systematisch umsetzen (WSUS, Windows Update for Business, Configuration Manager) und regelmäßige Testumgebungen nutzen.
- Sicherheitsbaselines anwenden (privilege-minimization, MFA, Just-In-Time-Administration).
- Zentralisierte Überwachung und Logging etablieren; Logs regelmäßig korrelieren und auswerten.
- Backups regelmäßig verifizieren und Test-Wiederherstellungen durchführen.
- Hohe Verfügbarkeit sicherstellen: Redundante Server, Failover-Clustering, Netzwerkausfallsicherheit, Replikation.
- Klare Dokumentation aller Architekturentscheidungen, Runbooks und Verantwortlichkeiten.
- Ressourcenplanung und Kapazitätsmonitoring fortwährend betreiben.
- Change-Management-Prozesse etablieren; klare Freigaben, Rückverfolgbarkeit.

Troubleshooting-Ansatz
- Replizierte, klare Schritte: Reproduzieren des Problems, Isolieren der Fehlerquelle, Ermitteln der Ursache (Logs, Metriken, Ereignisse), Abhilfe, Validierung der Lösung, Dokumentation des Vorgangs.
- Typische Hindernisse: veraltete Treiber, inkompatible Updates, Konfigurationsfehler, Zugriffskonflikte.
- Nutzung von Befehlen und Tools:
```
Get-WinEvent -FilterHashtable @{LogName='System'; Level=2} -MaxEvents 100
```
```
Get-Counter '\Network Interface(*)\Bytes Total/sec' -SampleInterval 1 -MaxSamples 30
```
```
Get-ADDomainController -Filter * | Select-Object Name, Forest, OSVersion
```
- Fehlerspezifische Logs: Ereignis-ID, ProviderName, Message; oft liefert eine Umkehrlogik (Was hat zuletzt geändert?) Hinweise.
- Testumgebungen nutzen: reproduzieren Sie Probleme in einer isolierten Umgebung, bevor Änderungen in der Produktion erfolgen.

Lernpfade und Weiterbildung
- Offizielle Lernpfade von Microsoft Learn zu Windows Server 2022: Administration, Sicherheit, Hochverfügbarkeit, Migration.
- Praxisorientierte Labs zu Virtualisierung (Hyper-V), Failover Clustering, Storage Spaces Direct, |Dateiserver-Management|.
- Regelmäßige Teilnahme an Webinaren, Dokumentation von Lessons Learned und Erstellung eigener Whitepapers für das Team.
- Zertifizierungen: Basis- und Fortgeschrittenen-Module zu Windows Server 2022, Failover-Clustering und Hybrid-Umgebungen unterstützen die langfristige Kompetenzentwicklung.

Hinweis
- Kombinieren Sie theoretische Konzepte mit praktischen Übungen in einer Laborumgebung; dokumentieren Sie alle Schritte und halten Sie Wiederherstellungsprozesse auf dem neuesten Stand, um im Ernstfall schnell reagieren zu können.
