

# 50 Linux Shell Kommandos für IT-Experten: Ein strukturiertes Lehrbuch in 8 Kapiteln

## Inhaltsverzeichnis

**1. Grundlagen der Shell und Dateisystemnavigation**
  - 1.1 Dateisystemnavigation und Grundbefehle (Beispiele: ls, cd)
  - 1.2 Datei- und Verzeichnisoperationen (Beispiele: touch, cp)
  - 1.3 Verzeichnisse & Meta-Informationen (Beispiele: mkdir, stat)

**2. Textverarbeitung, Anzeigen und Mustererkennung**
  - 2.1 Ausgabe und Anzeige von Text (Beispiele: cat, less)
  - 2.2 Textbearbeitung (Beispiele: sed, awk)
  - 2.3 Filtern, Sortieren & Duplikate (Beispiele: grep, sort)

**3. Prozess- und Systemverwaltung**
  - 3.1 Prozesse und Jobs (Beispiele: ps, top)
  - 3.2 Fortgeschrittene Prozessverwaltung (Beispiele: pkill, pgrep)
  - 3.3 Systemdienste & Startprozesse (Beispiele: systemctl, reboot)

**4. Netzwerk- und Log-Kommandos**
  - 4.1 Text- und Mustererkennung in Dateien (Beispiele: grep, rg)
  - 4.2 Logs & Monitoring (Beispiele: tail -f, journalctl)
  - 4.3 Pipelines & Weiterleitung (Beispiele: cut, xargs, tr)

**5. Netzwerkzugriff, Fernwartung und Datentransfer**
  - 5.1 Sichere Fernwartung & Dateitransfer (Beispiele: ssh, scp)
  - 5.2 Netzwerkdiagnose (Beispiele: ping, nslookup)
  - 5.3 Portüberwachung (Beispiele: netstat, ss)

**6. Systemressourcen, Dateisysteme und Fehlersuche**
  - 6.1 Systemressourcen-Überblick (Beispiele: top, free)
  - 6.2 Dateisystem-Überwachung (Beispiele: df, lsblk)
  - 6.3 Diagnosedaten (Beispiele: journalctl, dmesg)

**7. Berechtigungen, Sicherheit und Verschlüsselung**
  - 7.1 Berechtigungen & Ownership (Beispiele: chmod, chown)
  - 7.2 Sicherheit & Privilegien (Beispiele: sudo, passwd)
  - 7.3 Verschlüsselung & SSH-Keys (Beispiele: gpg, ssh-keygen)

**8. Scripting, Automatisierung und Produktivität**
  - 8.1 Scripting-Grundlagen (Beispiele: bash, printf)
  - 8.2 Automatisierung & Planung (Beispiele: cron, at)
  - 8.3 Produktivität & Debugging (Beispiele: alias, history, trap)


---

## Kapitel 1: Grundlagen der Shell und Dateisystemnavigation

### 1.1 Dateisystemnavigation und Grundbefehle

Die Shell operiert mit einem hierarchischen Dateisystem, das in einen Stammordner, den Wurzelpfad, zu dem alle anderen Dateien und Verzeichnisse gehören. Der aktuell angezeigte Arbeitsordner wird durch den Pfad dargestellt, und jeder Pfad kann entweder absolut sein (beginnt mit /) oder relativ zum aktuellen Verzeichnis (kein führendes /). Wichtige Konzepte sind daher der absolute Pfad, der relative Pfad, sowie die Symbole . (aktuelles Verzeichnis) und .. (Elternverzeichnis). Verständnis dieser Konzepte erleichtert das Navigieren erheblich.

Das Kommando pwd gibt den aktuellen Arbeitsordner aus. cd dient zum Wechseln des Arbeitsverzeichnisses. Mit cd kann man zu einem absoluten Pfad, einem relativen Pfad oder einem Home-Verzeichnis wechseln, z. B. cd ~ oder cd $HOME. Der Befehl ls stellt den Inhalt eines Verzeichnisses dar. Ohne Optionen zeigt er Dateinamen in einer weniger detaillierten Form an; mit Optionen erhält man mehr Informationen über Berechtigungen, Eigentümer, Größe und Zeitstempel. Zusätzlich können Verzeichnisse mit ls -l detailliert gelistet werden, und versteckte Dateien (Dateien, deren Name mit einem Punkt beginnt) werden mit ls -a sichtbar.

Wichtige Optionen und Verhaltensweisen sind:
- Absoluter vs. relativer Pfad
- Das Home-Verzeichnis mit ~ oder $HOME
- Die Darstellung von Verzeichnissen mittels ls -F oder ls -d

Beispiele:
```
pwd
```
```
cd /var/log
```
```
cd ..
```
```
cd ~
```
```
ls -la
```
```
ls -l /etc
```
```
echo $PWD
```

Hinweis: Um Pfade mit Leerzeichen korrekt zu verwenden, sind Anführungszeichen oder Escape-Zeichen erforderlich, z. B. cd "Mein Ordner" oder cd Mein\ Ordner.

Tabelle: Häufig genutzte ls-Optionen (Monospace)
```
| Option | Bedeutung                                              |
|--------|--------------------------------------------------------|
| -l     | Langformatige Anzeige mit Berechtigungen, Eigentümer, Größe, Datum |
| -a     | Alle Dateien anzeigen, einschließlich versteckter      |
| -h     | Menschlich lesbare Dateigröße (z. B. 1.2K, 3.4M)     |
| -d     | Verzeichnis selbst statt dessen Inhalt anzeigen (ls -ld Verzeichnis) |
| -F     | Typinformationen hinzufügen (z. B. / für Verzeichnisse) |
```

Praktische Lektion:
- Nutzen Sie pwd, um Ihre aktuelle Position zu verifizieren.
- Verwenden Sie cd mit relativen Pfaden, um effizient im aktuellen Verzeichnisbaum zu arbeiten.
- Kombinieren Sie ls-Optionen, um sowohl Überblick als auch Details zu erhalten.

### 1.2 Datei- und Verzeichnisoperationen

Dateien und Verzeichnisse zu erstellen, zu kopieren, umzubenennen und zu löschen, bildet die zentrale Routine der täglichen Arbeit. Die Befehle touch, cp, mv und rm decken diese Grundoperationen ab. Touch erzeugt neue leere Dateien oder aktualisiert Zeitstempel bereits existierender Dateien. cp kopiert Dateien oder Verzeichnisse; mit der Option -r bzw. -R lassen sich auch Verzeichnisse rekursiv kopieren. mv verschiebt oder benennt Dateien um; rm entfernt Dateien oder Verzeichnisse. Beim Umgang mit rm ist Vorsicht geboten, insbesondere mit rekursiven und forcerten Varianten wie rm -rf.

Wichtige Hinweise:
- cp -a bewahrt Attribute (Zeitstempel, Berechtigungen, Eigentümer) beim Kopieren.
- cp -r kopiert Verzeichnisse inklusive deren Inhalt.
- mv kann auch Verzeichnisse verschieben, nicht nur Dateien.
- rm entfernt Dateien dauerhaft; Gelöschtes kann nicht ohne Spezialwerkzeug wiederhergestellt werden.
- Verwenden Sie rm -i, um eine Bestätigung pro Datei zu erhalten, besonders bei größeren Mengen.

Beispiele:
```
touch protokoll.log
cp protokoll.log backup.log
mkdir projekt
cp -a projekt projekt_backup
mv alte_datei.txt neues_datei.txt
rm -f veraltete_datei.txt
```
Beispiele mit Verzeichnissen:
```
cp -r quelle ziel
mv quellordner zielordner
```
Sicherheitstipps:
- Vor dem Löschen eine kurze Prüfung durchführen, z. B. ls datei* oder ls -l gefundenes.
- Wenn Sie mehrere Dateien löschen müssen, listen Sie sie explizit auf oder verwenden Muster (mit Vorsicht).
- Verwenden Sie -i oder -I mit rm, um unbeabsichtigtes Löschen zu vermeiden.

Erweiterte Hinweise:
- Mit einer Kombination aus rm und -r/-f lassen sich ganze Verzeichnisse einschließlich Inhalt entfernen. Seien Sie hier besonders vorsichtig.
- Die Optionen -p (Preserve) oder -u (Update) sind in bestimmten Kopier-/Verschiebe-Setups nutzbar, je nach Kontext und Tooling.

### 1.3 Verzeichnisse & Meta-Informationen

Verzeichnisse haben Meta-Informationen wie Berechtigungen, Eigentümer, Erstellungs- und Änderungszeiten, Dateigröße (bei Dateien) sowie Inodes. Um diese Informationen abzurufen, dienen Befehle wie ls -ld Verzeichnis, stat Datei oder stat Verzeichnis. Der Befehl mkdir dient zum Erzeugen neuer Verzeichnisse.

Wichtige Inhalte:
- Dateiberechtigungen (lesen, schreiben, ausführen): r, w, x
- Eigentümer und Gruppe (User, Group)
- Inode-Nummer und Dateisystem-Attribute
- Zeitstempel (Erstellt/Letzte Änderung/Letzter Zugriff)

Beispiele:
```
mkdir projekt
ls -ld projekt
stat projekt
stat datei.txt
```
Beispiele für detaillierte Meta-Informationen mittels stat:
```
stat -c "%A %h %U %G %n" datei.txt
```

Vergleich mit ls -l:
```
ls -l datei.txt
```

Zusatzinformationen:
- chmod verändert Berechtigungen; chown verändert Eigentümer; chgrp verändert die Gruppe.
- Verzeichnisse zeigen mit ls -ld nur die Metainformation des Verzeichnisses, nicht dessen Inhalte.

Tabelle: Wichtige Meta-Informationen und Berechtigungen (Monospace)
```
| Feld        | Bedeutung                                      |
|-------------|------------------------------------------------|
| %A          | Berechtigungen (z. B. drwxr-xr-x)              |
| %h          | Anzahl der Verweise (Linkanzahl)               |
| %U          | Eigentümer                                   |
| %G          | Gruppe                                         |
| %n          | Dateiname                                       |
```

Tabelle: Typische Berechtigungen in oktaler Form
```
| Oktal | Berechtigungen   |
|-------|------------------|
| 7     | rwx              |
| 6     | rw-              |
| 5     | r-x              |
| 4     | r--              |
| 0     | ---              |
```

Zusammenfassung:
- Verzeichnisse und deren Metainformationen zu verstehen, erleichtert die Verwaltung von Berechtigungen, Eigentümerschaften und Zugriffen.
- Nutzen Sie mkdir, ls -ld und stat, um die Struktur und die Eigenschaften von Verzeichnissen zuverlässig zu prüfen.
- Kombinieren Sie diese Informationen mit chmod/chown, um Sicherheits- und Zugriffskontexte angemessen zu steuern.
## KAPITEL: Textverarbeitung, Anzeigen und Mustererkennung

### 2.1 Ausgabe und Anzeige von Text

Die Ausgabe von Text ist eine der grundlegendsten Aktivitäten in der Shell. Sie umfasst einfache Dateiausgabe, das komfortable Durchblättern längerer Inhalte sowie das gezielte Auffinden von Textabschnitten. Die wichtigsten Werkzeuge sind hierbei cat und less, ergänzt durch verwandte Befehle wie head, tail oder more. Die Wahl des Werkzeugs hängt von der Situation ab: Schnelle, unformatierte Anzeige großer Dateien mit cat versus interaktives Durchblättern, Suchen und Scrollen mit less.

Wichtige Konzepte:
- Standardausgabe ( stdout ) als primärer Ort der Textausgabe.
- Paging und Interaktion: less bietet Navigationsfunktionen, Suchen und Stay-in-View-Modus.
- Line-Nummern und Sichtbarkeit von Nichtdruckzeichen: cat kann Inhalte detailliert ausgeben, während -n oder -A zusätzliche Informationen bietet.

Typische Muster:
- Einfache Dateiausgabe:
- Anzeige mit Zeilennummern:
- Interaktive Suche in Dateien:
- Kombinierte Nutzung von cat und less für schnelle Überprüfungen:

Beispiele:
```
cat datei.txt
```

```
cat -n datei.txt
```

```
less datei.txt
```

```
less +/Suchbegriff datei.txt
```

```
head -n 20 datei.txt
```

```
tail -n 50 datei.txt
```

```
tail -f logfile.log
```

Eine sinnvolle Referenz für häufig genutzte Optionen finden Sie in der folgenden Tabelle:

```
| Befehl | Zweck | Typische Optionen |
|--------|------|-------------------|
| cat    | Ausgabe von Dateien | -n, -A, -E, -T |
| less   | Interaktives Anzeigen | +/pattern, -N, -S, -F |
```

In der Praxis ersetzen Sie gelegentlich cat durch head oder tail, wenn nur eine Teilausgabe benötigt wird. Für große Logdateien ist less vorzuziehen, da es Navigation und Suche effizient unterstützt, ohne den gesamten Inhalt sofort in den Bildschirm zu laden. Achten Sie darauf, Dateien mit sensiblen Inhalten nicht versehentlich in freier Sicht zu belassen und nutzen Sie regelmäßigPaging-Tools, um die Arbeitsumgebung übersichtlich zu halten.

### 2.2 Textbearbeitung

Die Textbearbeitung in der Kommandozeile erfolgt primär durch sed und awk. Sed ist der Stream Editor: Es transformiert Textströme zeilenweise, ohne Dateien dauerhaft zu verändern (außer bei -i). Awk bietet eine Programmiermöglichkeit auf der Verarbeitungsebene der Zeilen, Spalten und Felder. Zusammen ermöglichen diese Werkzeuge mächtige, skriptbasierte Texttransformationen, die sich ideal für Logdateien, Konfigurationsdateien oder maschinengenerierte Ausgaben eignen.

Wichtige Konzepte:
- Sed: Musterbasierte Umwandlungen, Ersetzung, Zeilen- oder Bereichsmanipulation, In-Place-Änderungen (-i).
- Awk: Felder, Muster-Operationen, Ausgaben in Feldern, Aggregationen und Berichte.
- Einsatz von Regulären Ausdrücken (Regex) zur Mustererkennung und Transformation.

Typische Muster:
- Substitutionen in sed:
- Zeilenbereichsoperationen in sed:
- In-Place-Änderungen mit sed -i:
- Feldbasierte Verarbeitung mit awk:
- Summen, Mittelwerte oder Zeilenindizes mit awk:

Beispiele:
```
# Ersetzung in jeder Zeile (erstes Vorkommen pro Zeile)
sed 's/alt/neu/' datei.txt
```

```
# Ersetzung aller Vorkommen pro Zeile
sed 's/alt/neu/g' datei.txt
```

```
# Zeilen 2 bis 4 löschen
sed '2,4d' datei.txt
```

```
# In-Place-Ersetzung in der Datei
sed -i 's/alt/neu/g' datei.txt
```

```
# Nur der Text der ersten Spalte ausgeben (awk)
awk '{print $1}' datei.txt
```

```
# Gesamtsumme der ersten Spalte (numerische Werte) berechnen
awk '{sum += $1} END {print "Summe=", sum}' zahlen.txt
```

```
# Feldtrennung anpassen (Beispieldatei passwd)
awk -F: '{print $1, $3}' /etc/passwd
```

Sed nutzt man typischerweise für einfache, zeilenbasierte Transformationen, während Awk sich durch strukturiertere Berichte auszeichnet, insbesondere wenn Felder clevere Operationen benötigen. Kombinierte Pipelines erlauben komplexe Workflows, z. B. Filterung, Transformation und Ausgabe in einem Durchlauf.

Eine kompakte Referenz zu häufigen Optionen finden Sie hier:

```
| Befehl | Zweck | Typische Optionen |
|--------|------|-------------------|
| sed    | Streams bearbeiten | -i, s/regex/replacement/, -n, p |
| awk    | Feldbasierte Verarbeitung | -F, '{...}', '{print}' |
```

Praxisempfehlungen:
- Verwenden Sie sed -n, um kontrolliert zu drucken, wenn Sie nur bestimmte Zeilen benötigen.
- Nutzen Sie awk, um strukturierte Textdaten schnell in Berichte zu überführen.
- Führen Sie umfangreiche Änderungen zunächst ohne -i in einer Kopie durch, bevor Sie dauerhaft ändern.

### 2.3 Filtern, Sortieren & Duplikate

Filtern, Sortieren und das Erkennen von Duplikaten gehören zu den fundamentalen Operationen der Textanalyse. Grep dient dem gezielten Auffinden von Textmustern, sort ordnet Zeilen wahlweise numerisch oder alphabetisch, und uniq extrahiert oder zählt Duplikate. In der Praxis werden diese Werkzeuge oft gemeinsam in Pipelines eingesetzt, um Rohdaten in aussagekräftige Ergebnisse zu verwandeln.

Wichtige Konzepte:
- grep: Musterbasiertes Filtern von Zeilen in Dateien; Regex-Unterstützung; Optionen für Fallunterscheidung, Zeilennummern, rekursive Suche.
- sort: Sortiert Textzeilen; unterstützt numerische Sortierung, Felder, Umkehrung und Duplikatbereinigung.
- uniq: Entfernt oder zählt aufeinander folgende Duplikate; häufig in Kombination mit sort verwendet.
- Pipeline-Prinzip: Weiterleitung von Ausgaben über | an folgende Befehle, um schrittweise Ergebnisse zu erzeugen.

Typische Muster:
- Suche nach Mustern in einer einzelnen Datei:
- Case-insensitive Suche in mehreren Dateien:
- Sortieren von Suchergebnissen:
- Zählen oder Auswählen duplizierter Zeilen:

Beispiele:
```
grep -i "error" logfile.log
```

```
grep -n "TODO" *.log
```

```
grep -r -i "TODO" .
```

```
grep -r "pattern" . | sort
```

```
grep -r "pattern" . | sort | uniq
```

```
grep -r -i "pattern" . | sort | uniq -c | sort -nr
```

```
grep -r --exclude-dir=".git" -i "deprecated" . | wc -l
```

Weitere nützliche Hinweise:
- Verwenden Sie grep -r -H, um Dateinamen bei vielen Dateien zu erhalten.
- sort -n sortiert numerisch, -r kehrt die Reihenfolge um, -k setzt den Sortierschlüssel.
- uniq entfernt nur aufeinander folgende Duplikate; deshalb wird oft sort davor benötigt.
- Für fortgeschrittene Regex-Anforderungen können Sie grep -E (Extended Regular Expressions) verwenden.

Referenztabelle:

```
| Befehl | Zweck | Typische Optionen |
|--------|------|-------------------|
| grep   | Filtern nach Mustern | -i, -n, -r, -E, -o, -v |
| sort   | Sortieren von Zeilen | -n, -r, -k, -t |
| uniq   | Duplikate entferen / zählen | -c, -d, -u, -f |
```

Praxisempfehlungen:
- Kombinieren Sie grep mit sort und uniq, um Muster zu zählen oder häufige Vorkommen zu identifizieren.
- Verwenden Sie -i für fallunabhängige Suchen, wenn die Groß-/Kleinschreibung keine Rolle spielt.
- Nutzen Sie -r für Verzeichnisse, die rekursiv durchsucht werden sollen; schließen Sie ggf. bestimmte Verzeichnisse aus.
- Wenn Sie viele Ergebnisse aus einer Vielzahl von Dateien benötigen, nutzen Sie -H oder lassen Sie grep die Dateinamen standardmäßig ausgeben.

Hinweis: Achten Sie darauf, Muster sicher zu definieren, insbesondere in produktiven Umgebungen, um Fehlinterpretationen oder Performance-Probleme zu vermeiden.
## Kapitel 3: Prozess- und Systemverwaltung

### 3.1 Prozesse und Jobs

Prozesse sind laufende Instanzen von Programmen, die vom Betriebssystem verwaltet werden. Jeder Prozess besitzt eine eindeutige Prozess-ID (PID), eine Eltern-Prozess-ID (PPID) und einen Status, der Aufschluss über seine Ausführung gibt (R = runnable, S = sleeping, D = ununterbrochen im Kernel, Z = zombie/defekt, T = gestoppt etc.). Die Verwaltung von Prozessen dient der Überwachung, Optimierung der Ressourcenverteilung und sicherem Beenden ungewünschter Aufgaben.

Wichtige Werkzeuge zur Prozessuntersuchung sind ps und top. ps liefert statische Momentaufnahmen der Prozessliste, top aktualisiert Prozesse in Echtzeit und ermöglicht direkte Interaktionen wie das Beenden oder Priorisieren einzelner Prozesse.

Wichtige Befehle und typische Verwendungen:
- Prozessliste umfassend anzeigen
```
ps -ef
```
```
ps aux
```
- Detaillierte Spalten und Sortierung, z. B. nach CPU-Auslastung
```
ps -eo pid,ppid,user,stat,pcpu,pmem,cmd --sort=-pcpu | head -n 10
```
- Schnappschuss der aktuellen CPU-Last mit Top (Batch-Modus)
```
top -b -n 1
```
- Schnelleinsicht in Prozesse eines bestimmten Benutzers
```
ps -u <benutzername>
```

Tabellarisch typische ps-Ausgaben (Auszug):
```
USER       PID  PPID  UID   STATA  %CPU %MEM     VSZ  RSS   TTY     START   TIME COMMAND
root         1     0   0      S     0.0  0.1   123456  7892 ?       10:00   0:02 /sbin/init
www-data  2345   1   33     S     0.4  1.2   501234 20432 ?       10:01   0:30 /usr/sbin/apache2 -k start
user      5678  2345 1000    R     2.1  0.9  1024000 15600 pts/0   10:02   0:25 /usr/bin/python3 script.py
```

Shell-Jobs stehen im Kontext der aktuellen Sitzung und ermöglichen das parallele Ausführen, Anhalten oder Fortsetzen von Aufgaben:
- Beispiel: Einen Task in den Hintergrund senden
```
sleep 60 &
```
- Anzeigen der Hintergrundaufgaben
```
jobs
```
- Ein- bzw. Fortsetzen eines Jobs in den Vordergrund
```
fg %1
```
- Prozesslauf im Hintergrund festhalten (noch länger laufen lassen beim Abmelden)
```
nohup sleep 1200 &
```
- Freigeben eines Jobs aus der Shell (Disown)
```
disown %1
```

Fortgeschrittene Konzepte wie Zombie-Prozesse (defekte Kindprozesse, die noch im Parent-Prozess registriert sind) zeigen, dass das Abmelden oder die ordnungsgemäße Beendigung von Prozessen wichtig ist. Praktisch bedeutet dies, dass regelmäßige Überwachung, korrektes Beenden und Verhindern von Endlosschleifen zu einer stabilen Systemleistung beitragen. In der Praxis kombinieren Administratoren ps/top mit Logging, Alarmierung und gezieltem Kill-Signal, um Ressourcenreste zu vermeiden und das System zuverlässig zu betreiben.

### 3.2 Fortgeschrittene Prozessverwaltung

Zwar liefern ps und top den Status laufender Prozesse, doch oft sind gezielte Aktionen nötig, um bestimmte Prozesse zu finden oder zu beenden. Hier kommen pkill und pgrep ins Spiel. pgrep ermittelt Prozesse anhand von Mustern (z. B. Namen, Benutzern, Startzeit) und gibt deren PIDs zurück. pkill sendet Signale an eine oder mehrere passende Prozesse, um sie gezielt zu beenden, anzuhalten oder neu zu starten.

Wichtige Optionen und typische Anwendungsfälle:
- PIDs nach Namen oder Muster finden
```
pgrep firefox
pgrep -l -a nginx
```
- Prozesse eines bestimmten Benutzers identifizieren
```
pgrep -u root -a
```
- Prozesse nach Muster stoppen (sanft, Standard-Signal TERM)
```
pkill -f mydaemon
```
- Mit einem expliziten Signal arbeiten (z. B. SIGTERM, SIGKILL)
```
pkill -TERM -f mydaemon
pkill -9 -f mydaemon
```
- Sicherheit durch Vorprüfung: Zuerst prüfen, welche Prozesse betroffen wären
```
pgrep -l -f "python3 myserver.py"
```

Beispiele zur Praxis:
```
pgrep -u www-data -a | head -n 5
pkill -f -TERM "node server.js"
```
Commitment zur besten Vorgehensweise ist es, zuerst ein sanftes Signal zu verwenden und nur bei fehlender Reaktion auf harte Signale zu wechseln. Die Kombination aus pgrep (zur Suche) und pkill (zur Ausführung) ermöglicht eine granulare Prozessverwaltung, ohne dass der Administrator manuell nach PIDs suchen muss. Zusätzlich kann man mit ps -eo pid,ppid,cmd --sort=-pid gezielt den Befehlsverlauf prüfen, bevor man eine Aktion ausführt.

Wichtige Signale in der Übersicht (Auswahl):
- TERM (sanft anhalten, sauber beenden)
- INT (Interrupt, vergleichbar mit Strg-C)
- KILL (unwiderstehlich, sofort beendet)
- STOP/CONT (Pause bzw. Fortsetzung)

Anwendungsbeispiele:
```
pgrep -u nginx -a
pkill -TERM -f nginx
```

Hinweis: Beim Arbeiten mit pkill/pgrep immer sorgfältig testen (z. B. mit einer begrenzten Abfrage) und sicherstellen, dass nur die gewünschten Prozesse betroffen sind. In produktiven Umgebungen ergänzen Administratoren oft Protokollierung (z. B. journald) und Statusprüfungen, bevor Systeme beeinträchtigt werden.

### 3.3 Systemdienste & Startprozesse

Systemdienste werden in vielen Linux-Distributionen von systemd verwaltet. Systemd steuert Start, Stop, Neustart, Abhängigkeiten, automatische Starts beim Boot und das Logging über Journal. Die Befehle rund um systemctl ermöglichen eine zentrale Steuerung von Diensten, Runlevels/Targets, Konfigurationen und Logs.

Zentrale Systemctl-Befehle:
- Status eines Dienstes prüfen
```
systemctl status sshd
```
- Dienst starten, stoppen oder neu laden
```
systemctl start nginx
systemctl stop nginx
systemctl reload nginx      # nur bei Änderungen der Konfiguration
systemctl restart nginx
```
- Diensten registrieren/entregistrieren ( enable/disable ) und sofort aktivieren
```
systemctl enable nginx
systemctl disable nginx
systemctl enable --now nginx  # aktivieren und sofort starten
```
- Dienstzustand und Unit-Dateien anzeigen
```
systemctl is-enabled nginx
systemctl list-units --type=service --state=running
systemctl cat nginx
```
- Eigene Unit-Datei erstellen bzw. bearbeiten
```
systemctl edit nginx
```
- Daemon neu laden nach Änderungen an Unit-Dateien
```
systemctl daemon-reload
```
- Logs eines Dienstes durchsuchen
```
journalctl -u nginx.service --since "24 hours ago"
```

Schnellübersicht zu Systemvorgängen:
- Runlevels entsprechen Targets in systemd (z. B. multi-user.target, graphical.target). Isolieren eines Targets ermöglicht das Booten in einen spezifischen Modus.
- Überprüfen, ob ein Dienst beim Boot automatisch gestartet wird:
```
systemctl is-enabled nginx
```
- Liste aller System-Unit-Dateien:
```
systemctl list-unit-files --type=service
```

Beispiel eines einfachen Service-Units (unit-Datei-index):
```
[Unit]
Description=Beispiel-Dienst

[Service]
ExecStart=/usr/bin/mydaemon
Restart=always
User=nobody
Group=nogroup

[Install]
WantedBy=multi-user.target
```

Wichtige Hinweise:
- Die meisten systemctl-Befehle benötigen Root-Rechte (sudo).
- Nach Änderungen an Unit-Dateien ist ein Daemon-Reload erforderlich, damit systemd die Änderungen übernimmt.
- Logs geben Aufschluss über Startprobleme oder Konfigurationsfehler; daher ist journald oft die erste Anlaufstelle bei Fehlern.

Zusammenfassend bietet dieses Kapitel eine strukturierte Grundlage zur Überwachung von Prozessen, gezielten Prozessverwaltungsmethoden und der effektiven Steuerung von Systemdiensten mit systemctl. Das Verständnis dieser Konzepte erleichtert die Stabilität, Sicherheit und Performance von Linux-Servern in der Praxis.
## Kapitel: Netzwerk- und Log-Kommandos

### 4.1 Text- und Mustererkennung in Dateien (Beispiele: grep, rg)

Die Text- und Mustererkennung in Dateien ist eine Kernkompetenz jedes IT-Experten. Die Werkzeuge grep und rg ermöglichen das schnelle Auffinden von Zeichenketten, Mustern und regulären Ausdrücken in großen Datenmengen. Grep basiert auf POSIX-Regex und bietet Varianten für feste Zeichenfolgen oder erweiterte Regex-Syntax. Ripgrep (rg) ist moderner aufgebaut, nutzt Rust-Regex, unterstützt aber auch PCRE-ähnliche Muster über die Option --pcre2. Der Hauptunterschied liegt in der Geschwindigkeit, den Standardoptionen und der Handhabung größerer Codebasen (inklusive Git-Repositorys).

Wichtige Konzepte
- Muster: Reguläre Ausdrücke zur Beschreibung komplexer Suchmuster (z. B. Wortgrenzen, Klassen, Wiederholungen).
- Groß-/Kleinschreibung: Optionen wie -i bei grep oder die Smart-Case-Funktion in rg beeinflussen die Groß-/Kleinschreibung.
- Rekursive Suche: Suchpfade durch Dateienstrukturen erweitern (z. B. grep -R, rg mit Pfadangaben).
- Ausschluss von Dateien/Ordnern: Muster/Globfilter, um z. B. node_modules oder versteckte Verzeichnisse auszuschließen.
- Performance: rg ist in vielen Fällen deutlich schneller, besonders in großen Codebasen; rg unterstützt versteckte Dateien und Ignorierlisten standardmäßig mit passenden Optionen.

Grobe Bedienung und Beispiele
- In Dateien nach einfachem Muster suchen:
```
grep -R "Error" /var/log
```

- Mit Zeilenangaben und Dateinamen:
```
grep -Rni "timeout" /etc
```

- Regex mit erweiterten Funktionen (Beispiel: Wortgrenze, optionale Wiederholungen):
```
grep -E "\berror(s|ings)?\b" /var/log/syslog
```

- Schnelle, moderne Suche mit rg (einschluss von Hidden-Dateien und -Ordnern, Muster in Dateien):
```
rg -n --hidden --glob "!node_modules/**" "Failed to start" .
```

- PCRE-ähnliche Muster in rg aktivieren:
```
rg --pcre2 -n "\b[A-Za-z]+ing\b" .
```

- Kombinierte Suche mit Ausschlüssen:
```
rg -n --glob "!**/node_modules/**" -i "TODO|FIXME" .
```

Empfohlene Optionen (Auszug)
```
| Option              | Bedeutung                                    | Beispiel                                  |
|---------------------|----------------------------------------------|-------------------------------------------|
| -i                  | Groß-/Kleinschreibung ignorieren              | grep -i "error" datei.log                 |
| -n                  | Zeilennummern ausgeben                          | grep -n "pattern" datei.txt                |
| -R oder -r         | Rekursiv suchen                                 | grep -R "TODO" .                           |
| --color=auto        | Hervorhebung der Treffer                          | grep --color=auto "warning" *.log           |
| --glob              | Glob-Muster hinzufügen/ausblenden               | rg --glob "!node_modules/**" "TODO" .      |
| --pcre2             | PCRE2-Syntax aktivieren (rg)                    | rg --pcre2 -n "\b\d{4}-\d{2}-\d{2}\b" .   |
```

Hinweise
- Beachten Sie, dass bei großen Repositories die Nutzung von --glob/--glob-include und --glob-exclude hilft, unnötige Verzeichnisse auszuschließen.
- Für strukturiertes Durchsuchen von Logdateien lohnt sich oft eine Kombination aus rg grep, gepaart mit weiteren Tools wie awk oder sed, um Felder oder Zeilen sauber zu extrahieren.

### 4.2 Logs & Monitoring (Beispiele: tail -f, journalctl)

In der IT-Administration ist das zeitnahe Erkennen von Problemen in Logs zentral. tail -f ermöglicht das fortlaufende Verfolgen von Änderungen an Textdateien. Systemd-basierte Systeme verwenden journalctl, um das zentrale Journal zugänglich zu machen. Beide Ansätze unterstützen Filterung nach Zeit, Priorität, Units und Mustererkennung.

Grundlegende Konzepte
- Follow-Modus: Änderungen in Echtzeit beobachten.
- Filterung nach Quelle: Dateien (logdateien) oder Journal-Units; Prioritätsebenen wie err, warning, info.
- Zeitlich gefilterte Abfragen: Since, Until, specific Zeiträume.
- Ausgabeformate: Klartext, JSON, kurze Übersichten.

Wichtige Befehle und Anwendungen
- Verfolgen einer Logdatei in Echtzeit:
```
tail -f /var/log/syslog
```

- Historische Logausgabe mit Pagination und Filterung:
```
tail -n 200 -F /var/log/auth.log
```

- Systemd-Journal: Follow-Modus und Unit-Filter:
```
journalctl -f -u ssh.service
```

- Alle Meldungen eines Units ab einem Zeitpunkt:
```
journalctl -u nginx.service --since "2025-08-01 12:00:00" --until "2025-08-01 13:00:00"
```

- Prioritätsebene filtern (Fehler und höher):
```
journalctl -p err
```

- Kombinierte Musterersicht (Piping mit grep):
```
journalctl -u apache2.service -p info | grep -i "GET /"
```

Weitere nützliche Hinweise
- Ansichten im Journal können in verschiedene Formate exportiert werden, z. B. JSON (-o json) oder normalisiert (-o short-precise).
- Die Optionen -b (Boot) beschränken die Abfrage auf den aktuellen Boot-Zyklus; kombiniert mit --since lässt sich der Zeitraum präzise eingrenzen.
- Logger-Dienste wie rsyslog forwarden Meldungen aus Anwendungen an das zentrale Journal. Nutzen Sie Journalctl, um systemweite Diagnosen zu erstellen.

Sicherheits- und Performance-Hinweise
- Verwenden Sie Filterung, um nur relevante Meldungen zu ziehen (z. B. nach Unit, Zeitraum oder Priorität), um Datenmengen zu reduzieren.
- Beim Arbeiten mit sensiblen Logs ist Vorsicht geboten: Entfernen oder redigieren Sie ggf. sensible Informationen bevor Sie Logs weitergeben oder veröffentlichen.
- Für Heavy-Load-Hosts empfiehlt sich das Rotationsmanagement (logrotate) und das Festlegen klarer Archivierungsregeln, um Speicherplatzprobleme zu vermeiden.

### 4.3 Pipelines & Weiterleitung (Beispiele: cut, xargs, tr)

Pipelines, Weiterleitungen und Texttransformationen ermöglichen es, enorme Mengen an Textdaten effizient zu verarbeiten. Die drei erwähnten Befehle — cut, xargs und tr — decken zentrale Anwendungsfälle ab: Extraktion von Feldern, Aufbau von Befehlszeilen, Transformation von Zeichenfolgen. Durch geschickte Verknüpfung dieser Werkzeuge entstehen leistungsfähige Lösungswege ohne komplexe Skripte.

Kernkonzepte
- cut: Extrahiert Spalten oder Zeichenbereiche aus Textzeilen anhand eines Delimiters.
- xargs: Baut aus Standard-Eingabe neue Befehlszeilen, indem es Eingaben in Argumentlisten verwandelt.
- tr: Transformiert oder filtert Zeichen auf Zeichenebene (z. B. Zeichenersetzung, Entfernen von Zeichen, Zeilenumbrüche) und arbeitet Byte-/Character-basiert.

Typische Anwendungen mit Beispielen
- Felder aus einer CSV-Datei extrahieren:
```
cut -d',' -f1,3 daten.csv
```

- Ganze Zeilen in einzelne Tokens zerlegen:
```
echo "alpha beta gamma" | tr ' ' '\n'
```

- Groß-/Kleinschreibung umwandeln:
```
tr 'a-z' 'A-Z' < datei.txt > datei_gross.txt
```

- Windows-Zeilenumbrüche entfernen:
```
tr -d '\r' < quelltext.txt > unix_text.txt
```

- Häufige Muster aus einer Liste extrahieren und weiterverarbeiten:
```
grep -R "ERROR" /var/log | cut -d: -f1,2 | sort | uniq -c | sort -nr
```

- Mit xargs eine Serie von Dateien sicher verarbeiten:
```
find /var/log -name "*.log" -print0 | xargs -0 -I {} gzip "{}"
```

- Kombination von Pipelines zur Erzeugung sauberer Listen:
```
grep -R "TODO" . | cut -d: -f1 | sort | uniq
```

Sinnvolle Muster und Best Practices
- Nutzen Sie cut, wenn die Daten in klar abgegrenzten Feldern vorliegen (z. B. CSV, TSV). Vermeiden Sie komplexe Parsing-Aufgaben nur mit cut; oft ergänzen sich cut und awk/sed.
- xargs verbessert die Stabilität gegenüber langen Listen; verwenden Sie -0 bzw. -print0 bei Nullterminierung, wenn Dateinamen Leerzeichen enthalten können.
- tr operiert auf Zeichenebene; verwenden Sie es, um Zeichensätze zu normalisieren oder Umbrüche zu entfernen. Für komplexere Um formungen sollten Sie zusätzlich sed oder awk einsetzen.
- Kombinieren Sie Befehle schrittweise: zuerst extrahieren, dann sortieren, dann filtern. Dadurch bleiben Skripte robust, nachvollziehbar und leichter zu debuggen.

Beispiel-Workflows (zusammengeführt)
- Zwischenprodukte in eine sortierte Liste überführen:
```
grep -R "ERROR" /var/log | cut -d: -f1 | sort | uniq -c | sort -nr > fehlerliste.txt
```

- Verzeichnisinhalte in eine flache Token-Liste verwandeln:
```
ls -1A | tr '\n' '\0' | xargs -0 -I {} ls -ld "{}"
```

Hinweis zur Robustheit
- Verwenden Sie stets Nullterminierung (print0 bzw. -0) bei Dateinamenlisten, um Fehler durch Leerzeichen oder Sonderzeichen zu vermeiden.
- Testen Sie Pipeline-Teile einzeln, bevor Sie sie zu komplexen Workflows zusammenführen. Dies erleichtert Debugging und Wartung.
## Netzwerkzugriff, Fernwartung und Datentransfer

### 5.1 Sichere Fernwartung & Dateitransfer

Sichere Fernwartung und der Datenaustausch über das Netzwerk gehören zu den zentralen Aufgaben eines IT-Experten. Fundamentalis­ch sind Vertraulichkeit, Integrität und Authentizität der Verbindung. Das dominante Protokoll dafür ist SSH (Secure Shell). Es bietet verschlüsselte Verbindungen, starke Authentifizierung und flexible Funktionen wie Port-Forwarding, SFTP/SCP-Dateitransfer sowie Remote-Kommandos. In produktiven Umgebungen sollten standardmäßig Schlüssel-basierte Authentifizierung und kein Passwort-Login genutzt werden. Die Schlüssel sollten mit moderner Länge und Algorithmen (z. B. Ed25519) erzeugt werden und sicher verwaltet werden.

Wichtige Konzepte
- Schlüsselbasierte Authentifizierung: Verwendet öffentliche/ private Schlüsselpaare statt Passwörter.
- SSH-Agent: Speichert Schlüssel temporär, um Passworteingaben zu vermeiden.
- Config-Dateien: Benutzerkonfiguration in ~/.ssh/config erleichtert Verbindungen.
- Port-Forwarding: Lokale, ferne und dynamische Weiterleitungen ermöglichen sichere Zugriffe auf entfernte Dienste.
- Dateitransfer: SCP, SFTP oder rsync über SSH bieten sichere Übertragung.

Typische Befehle und Anwendungsfälle
- Anmeldung auf einem entfernten System:
```
ssh user@host
```
- SSH mit privatem Schlüssel und spezieller Portnummer:
```
ssh -i ~/.ssh/id_ed25519 -p 2222 user@host
```
- Lokale Portweiterleitung (z. B. Zugriff auf eine entfernte Webanwendung über den lokalen Rechner):
```
ssh -L 8080:localhost:80 user@host
```
- Remote-Portweiterleitung (z. B. Zugriff auf ein internes System aus der Ferne):
```
ssh -R 2222:localhost:22 user@host
```
- Dynamische Portweiterleitung (SOCKS-Proxy):
```
ssh -D 1080 user@host
```
- Dateitransfer per SCP:
```
scp file.txt user@host:/remote/path/
```
- Rekursiver Dateitransfer:
```
scp -r /local/dir user@host:/remote/dir
```
- Sicherer Dateitransfer mit rsync über SSH:
```
rsync -avz -e "ssh -p 2222" /local/dir/ user@host:/remote/dir/
```
- SFTP-Übertragung in interaktiver Sitzung:
```
sftp user@host
```
- SSH-Konfigurationsbeispiel ( ~/.ssh/config ):
```
Host myserver
  HostName host.example.org
  User alice
  Port 2222
  IdentityFile ~/.ssh/id_ed25519
  ServerAliveInterval 60
```
- Sicherheitshinweise: Deaktivieren Sie Passwort-Login, konfigurieren Sie SSHD so, dass Root-Login nicht erlaubt ist, und begrenzen Sie Zugriffe über Firewalls. Beispiel-SSHD-Konfiguration:
```
PasswordAuthentication no
PermitRootLogin prohibit-password
PubkeyAuthentication yes
ChallengeResponseAuthentication no
```

Vorteile und Best Practices
- Von Anfang an auf Sicherheit setzen: Schlüsselbasierte Authentifizierung, starke Passphrasen, regelmäßig Schlüsselrotation.
- Nutzen Sie SSH-Config-Dateien, um komplexe Verbindungen übersichtlich zu halten.
- Nutzen Sie Port-Forwarding nur, wenn notwendig, und dokumentieren Sie die Zugriffswege.
- Führen Sie regelmäßige Audits durch, überwachen Sie SSH-Logdateien (z. B. /var/log/auth.log) und setzen Sie innere Firewalls sinnvoll ein.

Beispiel-Workflow
- Ein Entwickler verbindet sich täglich mit einem Build-Server, überlegt eine sichere Remote-Entwicklung, transferiert Scripts per SFTP und nutzt SSH-Portweiterleitungen, um eine Webanwendung lokal zu testen, bevor sie deployed wird. Die Schritte erfolgen in klarer Abfolge: Schlüssel generieren, Schlüssel verteilen, SSH-Verbindung testen, Port-Forwarding konfigurieren, Dateien übertragen, Verbindung beenden.

```
# Schlüsselgenerierung (falls noch nicht vorhanden)
ssh-keygen -t ed25519 -a 100 -C "benutzer@example.com"

# Schlüssel dem Server hinzufügen
ssh-copy-id -i ~/.ssh/id_ed25519.pub user@host

# Verbindung testen
ssh user@host
```

### 5.2 Netzwerkdiagnose

Netzwerkdiagnose dient der Fehlersuche bei Erreichbarkeit, Namensauflösung und Pfaden durch das Netzwerk. Zu den häufig genutzten Werkzeugen gehören Ping zur Erreichbarkeitsprüfung, Nslookup (und Dig als Alternative) zur DNS-Überprüfung sowie ergänzende Tools, die helfen, Pakete, Latenz und Route-Verläufe zu bewerten. Ein solides Verständnis dieser Werkzeuge erlaubt es, Probleme schnell zu isolieren und geeignete Gegenmaßnahmen zu definieren.

Ping
- Zweck: Ermittelt, ob ein Zielhost erreichbar ist, und misst Round-Trip-Zeit und Paketverlust.
- Typische Optionen:
  - -c n: Anzahl der Pakete
  - -i seconds: Intervall zwischen den Paketen
  - -W timeout: Wartezeit pro Paket
  - -4 / -6: IPv4 bzw. IPv6 verwenden
- Beispiele:
```
ping -c 4 example.com
ping -c 10 -i 0.5 example.com
ping -4 2001:db8::1
```

DNS-Abfragen mit Nslookup
- Zweck: Auflösung von Hostnamen in IP-Adressen und Prüfung der DNS-Server-Reaktionen.
- Optionen:
  - nslookup hostname
  - nslookup hostname server: Port
  - nslookup -type=MX domain: MX-Einträge prüfen
  - Interaktive Nutzung:
```
nslookup
> set q=MX
> example.com
```
- Beispiele:
```
nslookup example.com
nslookup example.com 8.8.8.8
nslookup -type=A example.com
```

Hinweise zur Fehlersuche
- Ist der Name auflö­sbar? Wenn ja, welche IP wird geliefert? Wenn nicht, prüfen Sie DNS-Server, lokale Resolver-Einstellungen und Netzwerkkonfiguration.
- Ist das Ziel erreichbar? Prüfen Sie Routing, Firewall, NAT und ICMP-Blockaden.
- Wie ist die Latenz? Hohe Latenz oder Paketverlust deuten auf Netzwerkstau, schlechte Leitung oder Zwischenrouting.
- Beachten Sie IPv4/IPv6-Dual-Stack-Situationen, wenn Systeme unterschiedliche Adressfamilien bevorzugen.

Verschiedene Werkzeuge ergänzen sich. Oft ist es sinnvoll, Ping zuerst zu verwenden, dann DNS-Auflösung zu prüfen und anschließend weiterführende Tools wie traceroute oder mtr (nicht ausdrücklich in diesem Kapitel enthalten) heranzuziehen, um Pfade und Engpässe zu erkennen.

Beispiel-Übungen
- Prüfen Sie die Erreichbarkeit eines Servers hinter einer Firewall.
- Überprüfen Sie die DNS-Auflösung eines internen Hostnamens gegenüber dem internen DNS-Server sowie dem öffentlichen DNS-Server.
- Analysieren Sie, ob ein Dienst zuverlässig erreichbar ist und wie lange Pakete benötigen, um ihr Ziel zu erreichen.

```
# DNS-Auflösung mit Google DNS prüfen
nslookup www.example.com 8.8.8.8
# DNS-Auflösung interaktiv testen
nslookup
> server 8.8.8.8
> www.example.com
```

### 5.3 Portüberwachung

Die Portüberwachung dient der Beobachtung offener, geschlossener oder verdächtiger Verbindungen auf einem System. Netstat und ss sind zwei zentrale Tools dafür. Netstat ist historisch verbreitet, während ss eine modernere, schnellere Alternative darstellt und häufig als Standardwerkzeug für die Linux-Administration genutzt wird. Beide Werkzeuge können in Root- oder Sudo-Rechten ausgeführt werden, um detaillierte Informationen über Prozesse, PIDs und Verbindungen zu erhalten.

Wichtige Konzepte
- Listening Ports: Zeigt Dienste an, die auf eingehende Verbindungen warten.
- Established Connections: Zeigt aktive Verbindungen zu entfernten Hosts.
- Protokolle: TCP, UDP, Unix-Sockets; Anzeige von PIDs ermöglicht Nachverfolgung des Verantwortlichen.
- Filteroptionen: Spezifika (state), Protokolle (tcp/udp), lokale/entfernte Adressen, PIDs.

Hauptbefehle
- netstat (älter, aber noch verbreitet):
```
sudo netstat -tulnp
```
- ss (empfohlen, schneller und flexibel):
```
sudo ss -tulnp
```
- Übersichtliche Statusabfragen:
```
sudo ss -s
```
- Anzeigen aller Verbindungen inklusive Status:
```
sudo ss -a
```
- Filtern von Listening-Sockets:
```
sudo ss -tulnp | grep LISTEN
```
- Laufende Verbindungen in Echtzeit aktualisieren:
```
watch -n 1 "ss -tulnp"
```

Vergleich netstat vs. ss
- ss ist in Linux-Umgebungen moderner, schneller und liefert mehr Optionen in einer kompakteren Form.
- netstat ist portabel und in älteren Skripten weiterhin verbreitet; es kann deprecated sein, daher empfiehlt sich der Umstieg auf ss.
- Beide Tools benötigen in der Regel Root-Rechte, um Prozessinformationen (PID) anzuzeigen.

Beispiele und sinnvolle Einsatzszenarien
- Prüfung, ob ein Webdienst auf Port 80 oder 443 lauscht:
```
sudo ss -tulnp | grep -E 'LISTEN.*:(80|443)'
```
- Ermittlung offener UDP-Ports, z. B. für DNS oder DHCP:
```
sudo ss -u -l
```
- Untersuchung einer verdächtigen Verbindung zu einem Remote-Host:
```
sudo ss -tuanp | grep 203.0.113.12
```

Sicherheit und Betrieb
- Nutzen Sie regelmäßig aktualisierte Tools aus dem Paketmanager Ihrer Distribution.
- Vermeiden Sie unnötiges Auslesen sensibler Prozessdaten in Mehrbenutzer-Umgebungen; verwenden Sie sudo mit restriktiven Rechten.
- In produktiven Systemen sollten Logging- und Monitoring-Lkrtnitätsmechanismen vorhanden sein, um Anomalien zeitnah zu erkennen.

Beispiel-Übung
- Überprüfen Sie, welche Dienste auf dem Server aktuell Verbindungen akzeptieren, und identifizieren Sie potenziell unautorisierte oder unerwartete Verbindungen. Kombinieren Sie dazu ss-, pid-Informationen und lokale Adressprüfungen.

```
sudo ss -tulnp
```
## Kapitel 6: Systemressourcen, Dateisysteme und Fehlersuche

### 6.1 Systemressourcen-Überblick

Die Überwachung von Systemressourcen gehört zu den grundlegenden Fertigkeiten eines IT-Experten. Sie dient der Früherkennung von Engpässen, der Vermeidung von Leistungsabfällen und der frühzeitigen Identifikation von Fehlfunktionen. Relevante Ressourcen sind CPU, Arbeitsspeicher (RAM), Festplattenspeicher, Buffer/Cache sowie der Kontext der laufenden Prozesse. Ein schneller Blick auf die Ressourcennutzung ermöglicht es, zwischen einfachen Lastspitzen und echten Problemen zu unterscheiden.

Wichtige Metriken im Überblick:
- CPU: Gesamtauslastung, Leerlaufzeit, Last pro Kern, Spitzenlasten.
- RAM und Swap: Gesamtspeicher, genutzter Speicher, freier Speicher, Buffers/Cache, Swap-Nutzung.
- Disk I/O: Durchsatz (Read/Write), IOPS, Wartezeiten.
- Prozesse: Anzahl laufender Prozesse, Spitzenverbraucher (Prozesse mit hohem CPU-/Speicherbedarf).
- Systembelastung: Load Average, Zeit seit dem letzten Boot.

Um schnell Kennzahlen zu bekommen, eignen sich die folgenden Befehle:

```
top
```

```
top
```

```
free -h
```

```
uptime
```

```
ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%cpu | head -n 5
```

Grenzen und Hinweise zu den Befehlen:
- top zeigt eine fortlaufende, interaktive Ansicht. Für Berichte oder Dokumentation eignet sich der Batch-Modus:
```
top -b -n 1
```
- free -h liefert eine menschenlesbare Darstellung von RAM- und Swap-Nutzung; der Parameter -h steht für „human-readable“.
- uptime fasst die Anzahl der Benutzer, die Last und die Systemzeit zusammen.
- ps bietet eine Momentaufnahme der Prozesslast; größere Analysen sollten regelmäßig in Intervallen erfolgen.

Für eine strukturierte Analyse können Sie eine kurze Tabellenskalierung verwenden, um Schnellwerte zu dokumentieren. Beispiel:

```
| Metrik              | Befehlsausgabe (Beispiel) | Interpretation                           |
|---------------------|----------------------------|------------------------------------------|
| CPU-Auslastung      | 23.4%                      | Durchschnittliche CPU-Nutzung              |
| RAM-Verbrauch      | 6.3G/16G                   | Genutzter vs. Gesamt RAM                   |
| Swap-Verbrauch     | 1.2G/4G                    | Genutzter Swap, ggf. Handlungsbedarf       |
| Load Average       | 0.54, 0.67, 0.72             | 1-, 5-, 15-Minuten-Durchschnitt               |
```

Interpretation und Handlungsleitfaden:
- Eine hohe Load Average bei geringem CPU-Verbrauch kann auf I/O- oder Sleep-Warten hindeuten.
- Steigender RAM-Verbrauch mit wenig freiem Speicher und erhöhte Swap-Nutzung deuten auf möglichen Speichermangel hin; hier kann eine Optimierung der RAM-Nutzung oder ein größerer Speicherbedarf nötig sein.
- Disk-I/O-Spitzen in Kombination mit hohen Wartezeiten erfordern eine Prüfung der Festplattenleistung, möglicher Engpässe durch Fragmentierung, Shadow-Copies oder Backups.

Zusammenfassend ermöglicht dieser Abschnitt eine fundierte, schnelle Einschätzung der Systembelastung. Die hier gezeigten Befehle liefern Kerninformationen, die Sie regelmäßig automatisiert oder manuell prüfen können, um einen stabilen Systembetrieb sicherzustellen.

### 6.2 Dateisystem-Überwachung

Die Überwachung des Dateisystems konzentriert sich auf die Verfügbarkeit und Auslastung von Speicherplätzen sowie auf die Struktur der zugrunde liegenden Blockgeräte. Drei Kernbereiche stehen im Fokus: die Belegung einzelner Dateisysteme, die Verfügbarkeit von Inodes sowie die physische Organisation der Speichermedien. Durch gezielte Abfragen lassen sich Engpässe früh erkennen und Kapazitäten rechtzeitig planen.

Der Befehl df dient der globalen Übersicht der Dateisystemauslastung. Der Einsatz mit der menschlich lesbaren Anzeige (-h) ist besonders hilfreich, da Größenangaben automatisch skaliert werden. Ergänzend zeigen lsblk und lsblk -f die physische Struktur und die Mountpoints der Speichermedien sowie das zugrundeliegende Dateisystem.

Beispiele:
```
df -h
```

```
Filesystem      Size  Used Avail Use% Mounted on
/dev/sda1        50G   20G   28G  42% /
```

```
df -ih
```

```
Filesystem     Inodes IUsed IFree IUse% Mounted on
/dev/sda1        327680  42000 285680   13% /
```

lsblk ermöglicht eine baumartige Darstellung der Blockgeräte. Mit Optionen wie -f werden Dateisysteme, Typen und Mountpoints angezeigt, während -o eine spezifische Spaltenausgabe bestimmt.

Beispiele:
```
lsblk
```

```
NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
sda      8:0    0  100G 0 disk
├─sda1   8:1    0   50G 0 part /
└─sda2   8:2    0   50G 0 part /home
```

```
lsblk -f
```

```
NAME   FSTYPE LABEL UUID                                 MOUNTPOINT
sda
├─sda1 ext4   root  1111-2222-3333-4444-555555555555 /
└─sda2 ext4   data  6666-7777-8888-9999-aaaaaaaaaaaa /home
```

Weitere Hinweise:
- Achten Sie auf Partitionen mit wenig freiem Speicherplatz, insbesondere wenn diese als Wurzel- oder `/var`-Partition dienen.
- Die Option -i von df zeigt Inodes an; ein voller Inode-Satz kann dazu führen, dass Dateien nicht mehr erstellt werden können, obwohl noch freier Speicher vorhanden ist.
- In großen Umgebungen ermöglichen regelmäßige Checks mit Skripten die frühzeitige E-Mail-Benachrichtigung bei Schwellenwerten.

Empfohlene Vorgehensweisen:
- Erstellen Sie monatliche oder wöchentliche Berichte über Speicherbelegung, Inodes und Mountpoints.
- Planen Sie Kapazitätserweiterungen basierend auf historischen Trends (Monitoringdaten sammeln, z. B. mit Prometheus oder anderen Tools).

### 6.3 Diagnosedaten

Diagnosedaten sind die Grundlage jeder Fehleranalyse. In vielen Linux-Systemen liefern journald und der Kernel-Puffer über dmesg zentrale Informationen zu Systemereignissen, Warnungen und Fehlfunktionen. Die richtige Nutzung dieser Werkzeuge erleichtert es, Ursachen für Performanceprobleme, Abstürze oder Fehlverhalten zu identifizieren.

Zentrale Befehle:
```
journalctl -xe
```

```
journalctl -u <einheit> --since "24h"
```

```
journalctl --disk-usage
```

```
dmesg -T
```

```
dmesg -w | head -n 100
```

```
dmesg | tail -n 50
```

Erklärung der Befehle:
- journalctl -xe zeigt erweiterte Fehlermeldungen und Kontext bei Fehlern oder unvorhergesehenen Ereignissen. Die Option -x ergänzt Standardmeldungen um Hinweise und Erläuterungen.
- journalctl -u <unit> filtert Logs für eine bestimmte Systemd-Einheit (z. B. nginx.service). --since erlaubt die zeitliche Begrenzung, was die Fehlersuche vs. vergangene Vorfälle fokussiert.
- journalctl --disk-usage liefert eine statistische Angabe über die Größe der Journaldaten, hilfreich für Archivierungs- und Speicherplanungen.
- dmesg erfasst Kernel-Meldungen. Mit -T werden Zeitstempel in menschlich lesbares Datum übersetzt. -w ermöglicht das Echtzeit-Beobachten neuer Meldungen, vergleichbar mit einem Log-Stream.
- Kombinationen wie grep oder weitere Filter (z. B. journalctl | grep -i error) fokussieren spezielle Meldungen, etwa Fehler, Warnungen oder Kernel-Events.

Beispielhafte Arbeitsabläufe:
- Fehlersuche nach einem Service-Ausfall:
```
journalctl -xe
```

```
journalctl -u apache2 --since "1 hour ago"
```

- Kernel-Probleme nach einem Treiberwechsel:
```
dmesg -T | grep -i -E "error|warn|fail|fault"
```

- Speicher- oder IO-Fehler in Logs dokumentieren:
```
journalctl --priority=err
```

Wichtige Hinweise:
- Stellen Sie sicher, dass Journaldaten ausreichend persistieren (Festplattenplatz und Rotation). In containerisierten Umgebungen oder Cloud-Instanzen reicht oft eine zentrale Logging-Lösung.
- Verwenden Sie Referenz-Events (Boot-Meldungen, Treiberänderungen, neue Geräte) als Orientierungspunkte, um Logs zu korrelieren.
- Bei persistierenden Problemen lohnt der Blick in Kernel-Logs (dmesg) in Verbindung mit Systemd-Journald-Meldern, um ein konsistentes Ursachenbild zu erzeugen.

Dieses Kapitel vermittelt solide Grundlagen zur Erfassung, Interpretation und Dokumentation von Diagnosedaten. Durch die vorgestellten Befehle erhalten IT-Experten eine effektive Basis, um Ursachen von Fehlverhalten zuverlässig zu identifizieren und gezielt Gegenmaßnahmen einzuleiten.
## Berechtigungen, Sicherheit und Verschlüsselung

### 7.1 Berechtigungen & Ownership

Berechtigungen und Ownership bilden die grundlegende Sicherheitsbarriere eines Linux-Systems. Sie definieren, wer auf welche Dateien oder Verzeichnisse lesen, schreiben oder ausführen darf. Gleichzeitig bestimmen sie, wem der Zugriff auf eine Ressource wesentlich gehört (Owner) und welcher Gruppe dieser Zugriff zugeordnet ist (Group). Die Darstellung von Berechtigungen erfolgt in drei Klassen: User (Eigentümer), Group (Gruppe) und Others (alle übrigen Benutzer). Jede Klasse kann drei Ressourcenrechte besitzen: Lesen (r), Schreiben (w) und Ausführen (x). Die Gesamtdarstellung ergibt sich aus den drei Dreierblöcken, z. B. drwxr-xr--. Zusätzlich gibt es Spezialrechte wie Setuid, Setgid und Sticky Bit, die das Verhalten von Programmen oder das Zugriffverhalten in Verzeichnissen modifizieren.

Die typischen Befehle zur Verwaltung von Berechtigungen und Ownership sind chmod, chown und chgrp. Während chmod die Rechte modifiziert, ändern chown den Eigentümer einer Datei oder eines Verzeichnisses und chgrp die Gruppenzugehörigkeit. Die hier gezeigten Beispiele verdeutlichen den praktischen Einsatz:

Beispiele zur Ownership
```
sudo chown alice datei.txt
sudo chown alice:entwickler datei.txt
sudo chown :entwickler verzeichnis
sudo chown -R alice:entwickler verzeichnis
```

Beispiele zu Berechtigungen
```
chmod 644 datei.txt       # rw-r--r--
chmod 755 skript.sh        # rwxr-xr-x
chmod u+x skript.sh        # Eigentümer darf ausführen
chmod go-rw kickoff.log     # Gruppe und Andere: keine Lese-/Schreibrechte
chmod -R 750 /var/www       # Rekursiv: Eigentümer volle Rechte, Gruppe lesen/ausführen, Andere keinen Zugriff
chmod u+s /usr/bin/setuid-binary   # Setuid (Specialberechtigung)
chmod g+s verzeichnis              # Setgid (Specialberechtigung)
chmod +t verzeichnis                 # Sticky Bit
```

Sonderrechte und ihr Einfluss
```
# Setuid (Programm läuft mit Eignerrechten)
chmod u+s /pfad/zum/binary

# Setgid (Dateien vererben Gruppenrechten)
chmod g+s /pfad/zum/verzeichnis

# Sticky Bit (nur Eigentümer/Root kann Dateien löschen)
chmod +t /pfad/zum/verzeichnis
```

Wichtige Hinweise zur Praxis
- Die Standardberechtigungen hängen von der Umask ab. Die Umask definiert, welche Rechte beim Erstellen neuer Dateien automatisch entfernt werden.
- Verwende rekursive Operationen mit Bedacht, besonders bei sensiblen Verzeichnissen (z. B. /var/www, /etc).
- Prüfe regelmäßig die Berechtigungen mit ls -l und wer auf Dateien zugreifen kann (z. B. mit stat oder namei).

Beispiele zur Kontrolle
```
ls -l /pfad/zur/datei
stat -c '%A %U %G %n' datei.txt
id
```

Tabelle: Grundberechtigungen und Octalwerte
```
| Berechtigungskombi | Octalwert | Bedeutung              |
|---------------------|-----------|------------------------|
| rwx                 | 7         | Lesen, Schreiben, Ausführen |
| rw-                 | 6         | Lesen, Schreiben          |
| r-x                 | 5         | Lesen, Ausführen          |
| r--                 | 4         | Nur Lesen                 |
| -wx                 | 3         | Schreiben, Ausführen      |
| -w-                 | 2         | Nur Schreiben            |
| --x                 | 1         | Nur Ausführen            |
| ---                 | 0         | Keine Rechte             |
```

Mit diesen Mechanismen lässt sich Ownership und Berechtigungen granular steuern, um den Zugriff auf sensible Ressourcen zu beschränken und gleichzeitig funktionale Anforderungen zu unterstützen. Routinierte Audits, klare Namenskonventionen und dokumentierte Rollenkonzepte helfen, Fehler zu vermeiden und Sicherheitslücken zu reduzieren.

### 7.2 Sicherheit & Privilegien

Sicherheit und Privilegien in Linux betreffen die verantwortungsbewusste Vergabe von Berechtigungen, den verantwortungsvollen Umgang mit Superuser-Rechten sowie Mechanismen, mit denen sich Missbrauch oder Fehleralimitationen minimieren lassen. Zentral ist hierbei das Prinzip der geringsten Privilegien: Anwendungen und Benutzer erhalten nur jene Rechte, die sie tatsächlich benötigen, um ihre Aufgaben zu erfüllen.

Ein Kernbestandteil ist die Nutzung von sudo statt direkter Root-Anmeldung. sudo erlaubt es, temporäre Administratorrechte für genau definierte Befehle zu gewähren und Aktivitäten nachvollziehbar zu protokollieren. Die Konfiguration erfolgt über die Datei /etc/sudoers (idealerweise über den Editor visudo, der Syntaxfehler verhindert). Typische Szenarien umfassen:

- Allgemeine Administratorrechte für einen Benutzer:
```
bob ALL=(ALL) ALL
```

- Beschränkung auf bestimmte Befehle:
```
bob ALL=(ALL) /usr/bin/systemctl, /usr/bin/journalctl
```

- Passwortlose Ausführung bestimmter Befehle:
```
bob ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart apache2
```

- Gruppenbasiertes Vorgehen (Empfehlung: administrative Privilegien über eine dedizierte Gruppe):
```
%admin ALL=(ALL) ALL
```

Verwaltungsaspekte
```
sudo -l -U bob        # Welche Befehle darf Bob ausführen?
sudo visudo          # Sichere Bearbeitung der sudoers-Datei
```

Weitere sicherheitsrelevante Befehle
```
id                    # Zeigt Benutzer- und Gruppen-IDs an
passwd                # Ändert das eigene Passwort
passwd root           # Setzt das Root-Passwort (falls erlaubt; oft deaktiviert)
sudo -k               # Fordert sofort erneute Authentifizierung
```

Passwortrichtlinien und Identitätsmanagement
- Verwende starke Passwörter oder bevorzugt Passphrasen; kombiniere dies mit Zwei-Faktor-Authentifizierung, wo möglich.
- Setze Passwortalterung, Sperr- und Lockout-Mechanismen, z. B. über PAM und chage (z. B. chage -M 90 benutzer).
- Lockiere per Default das Root-Konto oder deaktiviere direkte Root-Login über SSH (z. B. in /etc/ssh/sshd_config: PermitRootLogin no).

Sudoers-Sicherheitstiefe
```
# Benutzerberechtigungen im sudoers-Datei-Beispiel
# Benutzer bob darf alle Befehle ausführen
bob ALL=(ALL:ALL) ALL

# Gruppe www-data darf bestimmte Befehle ohne Password ausführen
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart apache2
```

Hinweise zur Praxis
- Dokumentiere Privilegienvergabe transparent, damit Auditierbarkeit gewährleistet bleibt.
- Beschränke privilegierte Operationen auf notwendige Umgebungen (z. B. Produktionssysteme vs. Testumgebungen).
- Nutze Audit-Logs, um Missbrauch zu erkennen und Revisionszwecken zu ermöglichen.
- Überprüfe regelmäßig die Mitglieder in privilegierten Gruppen (z. B. sudo-Gruppe) und entferne ungenutzte Accounts.

Tabelle: Wichtige sudoers-Direktiven (Beispiele)
```
| Direktive        | Bedeutung                            | Beispiel                                  |
|------------------|--------------------------------------|-------------------------------------------|
| ALL              | Alle Hosts                            | user ALL=(ALL) ALL                        |
| NOPASSWD         | Kein Passwort erforderlich            | user ALL=(ALL) NOPASSWD: /bin/systemctl   |
| PASSWD           | Passwort ist erforderlich              | user ALL=(ALL) ALL                         |
| Defaults timeout | Timeout für Passwortabfrage              | Defaults timestamp_timeout=30               |
```

In der Praxis unterstützen diese Strukturen eine sichere, nachvollziehbare Verwaltung von Privilegien. Das sorgfältige Abwägen, wer wann welche Befehle ausführen darf, reduziert die Angriffsfläche und erleichtert Compliance-Anforderungen.

### 7.3 Verschlüsselung & SSH-Keys

Verschlüsselung und Schlüsselmanagement sichern Daten sowohl im Ruhezustand als auch während der Übertragung. In modernen Linux-Setups kommen zwei zentrale Werkzeuge zum Einsatz: GnuPG (GPG) für dateibasierte Verschlüsselung und Signaturen sowie SSH-Schlüsselpaare für die Authentifizierung bei entfernten Systemen. Zusätzlich wird die Sicherheit von Verbindungen durch korrekte Schlüsselverwaltung, Passphrasen und gute Praktiken gestärkt.

GPG bietet Funktionen zum Verschlüsseln, Entschlüsseln und Signieren von Dateien sowie zum Verwalten von Schlüsseln. Typische Arbeitsabläufe umfassen das Erzeugen eines Schlüsselpaares, das Verwalten von öffentlichen Schlüsseln, das Ver- bzw. Entschlüsseln von Dateien und das Signieren, um Integrität und Herkunft zu belegen.

Beispielhafte GPG-Befehle
```
# Schlüsselgenerierung (Interaktiver Dialog)
gpg --full-generate-key

# Verfügbare Schlüssel anzeigen
gpg --list-keys
gpg --list-secret-keys --keyid-format LONG

# Öffentlichen Schlüssel exportieren
gpg --armor --export deine-email@example.com > pubkey.asc

# Öffentlichen Schlüssel importieren
gpg --import fremder_pubkey.asc

# Datei verschlüsseln (Empfänger identifizieren)
gpg -e -r empfaenger@example.com datei.txt

# Datei entschlüsseln
gpg -d datei.txt.gpg

# Signieren einer Datei
gpg --sign datei.txt
```

SSH-Schlüsselpaare unterstützen eine starke, passwortgeschützte Authentifizierung für den Zugriff auf Remote-Systeme. Der Standardpfad ist im Home-Verzeichnis unter ~/.ssh abgelegt. Ein einheitliches Vorgehen umfasst das Generieren eines Schlüsselpaares, das Hinzufügen des privaten Schlüssels zum SSH-Agenten (falls genutzt) und das Bereitstellen des öffentlichen Schlüssels auf dem Zielsystem.

Beispielhafte SSH-Befehle
```
# Schlüsselpaar generieren (Ed25519 ist modern und sicher)
ssh-keygen -t ed25519 -C "user@host"

# Schlüssel zum SSH-Agenten hinzufügen
ssh-add ~/.ssh/id_ed25519

# Öffentlichen Schlüssel auf Remote-System übertragen
# (empfohlen) mit ssh-copy-id
ssh-copy-id benutzer@remote-host

# Alternative direkte Übertragung
cat ~/.ssh/id_ed25519.pub | ssh benutzer@remote-host 'cat >> ~/.ssh/authorized_keys'

# SSH-Verbindung unter Verwendung eines bestimmten Schlüssels
ssh -i ~/.ssh/id_ed25519 benutzer@remote-host

# SSH-Konfigurationsdatei (Vereinfachung späterer Verbindungen)
cat > ~/.ssh/config << 'CONFIG'
Host server1
  HostName server1.example.com
  User bob
  IdentityFile ~/.ssh/id_ed25519
CONFIG
```

Schutz der privaten Schlüssel
- Private Schlüssel müssen geschützt werden (Dateiberechtigungen 600).
- Verwende eine starke Passphrase, um den Schlüssel zusätzlich zu schützen.
- Lagere Schlüssel sicher, idealerweise auf separaten Geräten oder in einer Hardware-Sicherheitslösung (falls verfügbar).

Sicherheitsempfehlungen und Best Practices
- Verwende Ed25519-Schlüssel, wann immer möglich; RSA 4096 bleibt eine Alternative, ist aber langsamer.
- Vermeide das direkte Speichern von Schlüsseln in gemeinsam genutzten Verzeichnissen.
- Prüfe regelmäßig die Berechtigungen von Schlüsseldateien (chmod 600).
- Nutze SSH-Agenten sinnvoll, aber deaktivere unnötige, persistente Sessions in unsicheren Umgebungen.
- Rotiere Schlüsselperiodisch und halte On- und Off-Board-Prozesse sauber (z. B. Verwaiste Schlüssel bereinigen).

Zusammenfassend ermöglichen Verschlüsselung und Schlüsselmanagement eine robuste Sicherheitsschicht für Daten und Verbindungen. Durch bewusste Konfiguration von GPG und SSH, ergänzt durch gute Passwörter, Passphrasen und regelmäßige Audits, lässt sich das Risiko von Abhörung, Manipulation oder unbefugtem Zugriff deutlich verringern.
## Kapitel 8: Scripting, Automatisierung und Produktivität

### 8.1 Scripting-Grundlagen

Scripting bezeichnet das Schreiben von kurzen bis mittellangen Programmen, die eine Folge von Befehlen automatisiert ausführen. Im Linux-Kontext werden Skripte überwiegend mit der Bash interpretiert, können aber auch andere Shells wie z. B. zsh oder dash verwenden. Der zentrale Gedanke besteht darin, wiederkehrende Aufgaben zu kapseln, Parameter zu verarbeiten, Fehler abzufangen und Ergebnisse zu protokollieren. Ein Skript ist in der Regel eine Textdatei, die eine Abfolge von Befehlen enthält, oft mit einer ersten Zeile, dem sogenannten Shebang, der dem System mitteilt, welche Shell das Skript interpretieren soll.

Wichtige Konzepte für robuste Skripte:
- Shebang und Ausführungsrechte: Ohne Shebang weiß das System nicht, welche Shell das Skript ausführen soll, und ohne Ausführungsrecht kann die Datei nicht direkt gestartet werden.
- Variablen und Parameterersetzung: Variablen speichern Werte, Parameter ermöglichen dem Skript, Eingaben zu verarbeiten.
- Zitate: Unterschiedliche Zitatarten (Einzelzitate, Doppelzitate, Backslashes) beeinflussen die Interpretation von Special Characters.
- Fehlerbehandlung: Mit Optionen wie set -euo pipefail erhöht sich die Zuverlässigkeit von Skripten.
- Funktionen und Lokale Variablen: Gruppenlogik kapseln und Seiteneffekte minimieren.
- Logging und Debugging: An bestimmten Stellen Ausgaben protokollieren und mithilfe von set -x Befehle schrittweise nachverfolgen.

Beispiele:

- Minimaler Einstieg: Hello-Welt mit optionale Namensübergabe
```
#!/bin/bash
name=${1:-Welt}
printf "Hallo, %s!\n" "$name"
```

- printf sinnvoll einsetzen
```
printf "Datei: %-20s Größe: %8d bytes\n" "$1" "$2"
```

- Robustes Grundgerüst mit defensiver Programmierung
```
#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

cleanup() {
  echo "Aufräumen..."
}
trap cleanup EXIT

for arg in "$@"; do
  if [[ -f "$arg" ]]; then
    echo "Verarbeite: $arg"
  else
    echo "Fehler: Datei nicht gefunden - $arg" >&2
    exit 1
  fi
done
```

- Funktionsbeispiel mit Lokalen Variablen
```
#!/bin/bash
greet() {
  local name="${1:-Freund}"
  printf "Hallo, %s!\n" "$name"
}
greet "Anna"
```

Wichtige Hinweise zu Best Practices:
- Verwenden Sie set -euo pipefail, um unbeabsichtigte Fehler früh zu erkennen.
- Verwenden Sie lokale Variablen innerhalb Funktionen, um Seiteneffekte zu reduzieren.
- Dokumentieren Sie Ihr Skript durch klare Kommentare am Anfang und anschließende In-Skript-Erklärungen.
- Prüfen Sie die Eingaben sorgfältig, insbesondere Pfade oder Dateinamen, um Sicherheitsrisiken zu minimieren.

In einer typischen Lernumgebung ist es sinnvoll, mit einfachen Beispielen zu beginnen und schrittweise zu komplexeren Strukturen überzugehen. Die Fähigkeit, einfache Skripte zu lesen, zu modifizieren und zu erweitern, legt das Fundament für spätere Automatisierungsprojekte und eine produktive Arbeitsweise mit der Shell.

Tabellarische Übersicht (grundlegende Konzepte)
```
+-------------------+--------------------------------------------------+
| Konzept           | Bedeutung                                        |
+-------------------+--------------------------------------------------+
| Shebang           | Legt die auszuführende Shell fest                  |
| Ausführungsrechte | chmod +x Skriptdatei                               |
| Variablen         | Speicherung von Werten                              |
| Parameter         | Eingaben an das Skript übergeben                    |
| Quotes            | Steuerung der Interpretationslogik                    |
| set -euo pipefail  | Fehlerbehandlung und Robustheit                   |
| trap              | Aufräumarbeiten oder Signale abfangen               |
| Funktion          | Wiederverwendbare Logik kapseln                     |
+-------------------+--------------------------------------------------+
```

### 8.2 Automatisierung & Planung

Automatisierung dient dazu, zeitgesteuerte oder ereignisgesteuerte Aufgaben ohne menschliches Zutun auszuführen. In vielen Linux-Umgebungen sind Cron und das At-System die klassischen Werkzeuge für wiederkehrende Aufgaben. Cron plant regelmäßig wiederkehrende Jobs anhand eines festen Plans, während At Aufgaben zu einem bestimmten Zeitpunkt ausführt. Damit lassen sich Backups, Berichte, Reinigungsaufgaben oder Wartungsarbeiten zuverlässig orchestrieren. Wichtig sind klare Logging-Mechanismen, Fehlerbenachrichtigungen und ein Blick auf die Sicherheits- und Berechtigungsaspekte der Skripte.

Grundwissen Cron:
- Crontab-Dateiformat: Minute, Stunde, Tag des Monats, Monat, Wochentag, Befehl.
- Beispiele regeln die Ausführung zu festgelegten Zeiten.
- Protokollierung der Ausgabe erfolgt meist über Redirect in Logdateien.
- Umsetzungsbeispiele:

```
# Alle Tage um 02:30 Uhr Backups durchführen
30 2 * * * /usr/local/bin/backup.sh >> /var/log/backup.log 2>&1
```

- Cron-Kommandos:
```
crontab -e        # Öffnet die Crontab-Datei zur Bearbeitung
crontab -l        # Listet alle cron-Jobs des Nutzers auf
```

Beispiele für Cron-Aufgaben:
```
# Wöchentlicher Report
0 8 * * 1 /usr/local/bin/daily_report.sh >> /var/log/daily_report.log 2>&1

# Monatliches Bereinigen alter Logdateien
0 3 1 * * /usr/local/bin/cleanup_logs.sh
```

Beispiele für At:
```
# Einmalige Ausführung heute um 21:45
echo "/usr/local/bin/solar_cleanup.sh" | at 21:45

# In 2 Stunden ausführen
echo "/usr/local/bin/maintenance.sh" | at now + 2 hours
```

Organisatorische Hinweise für Planung:
- Umgebungsvariablen in Cron-Jobs sorgfältig festlegen, da Cron eine minimalistische Umgebung nutzt.
- Pfade zu Skripten absolut angeben oder in PATH-Veränderungen sicherstellen.
- Standardausgaben und Fehler in Logdateien umleiten, um spätere Analysen zu ermöglichen.
- Fehlerfälle abfangen und gegebenenfalls Benachrichtigungen per Mail oder Logging etablieren.

Tabellarische Darstellung: Chronologie und Typen von Planungstools
```
+----------------+-------------------+--------------------------------------------+
| Tool           | Typ               | Typische Anwendungsfälle                   |
+----------------+-------------------+--------------------------------------------+
| cron           | Zeitplanung       | Tägliche, wöchentliche Wiederholungen        |
| at             | Einmalige Planung | Einmalige Aufgaben, z. B. Berichte          |
| systemd-timer  | Systemdienst      | Feineinstellungen, Abhängigkeiten, Logging  |
| Ansible/CI     | Orchestrierung    | Infrastrukturautomatisierung, Deployments     |
+----------------+-------------------+--------------------------------------------+
```

Hinweise zur Praxis:
- Cron ist weit verbreitet und gut dokumentiert, eignet sich jedoch am besten für wiederkehrende Aufgaben, die in einer stabilen Umgebung laufen.
- At ist ideal für spontane, einstufige Ausführungen, jedoch teils veraltet – moderne Systeme setzen stärker auf systemd-timer.
- Für komplexe Abhängigkeiten oder verteilte Systeme empfiehlt sich der Einsatz von Orchestrierungstools, die über das hier behandelte Spektrum hinausgehen.

### 8.3 Produktivität & Debugging

Produktivität in der Shell bedeutet, wiederkehrende Aufgaben zu verkürzen, Befehle schneller zu schreiben und Fehler frühzeitig zu erkennen. Wichtige Hilfsmittel sind Aliases, die History-Funktionen der Shell, und Mechanismen wie Trap, die beim Umgang mit Signalen und Fehlerzuständen helfen. Dazu gehört auch ein bewusster Einsatz von Debugging-Optionen wie set -x, mit denen die Ausführung schrittweise sichtbar wird.

Aliases verbessern die Schnelligkeit der Arbeit und helfen, Tippfehler zu reduzieren:
- Typische Beispiele:
```
alias ll='ls -la'
alias gs='git status'
```
- Persistieren in Bash-Startdateien:
```
echo "alias ll='ls -la'" >> ~/.bashrc
```

Die History-Funktion unterstützt die Nachverfolgung vorheriger Eingaben und erleichtert die Wiederverwendung von Befehlen:
```
history                 # Zeigt eine Liste der ausgeführten Befehle
history | grep 'ls'     # Sucht nach Befehlen, die 'ls' enthalten
```
- History-Erweiterungen ermöglichen die Wiederholung von Befehlen anhand von Mustern:
```
!!        # letzter Befehl
!$        # letzter Hinweis (letztes Argument des vorherigen Befehls)
!gs       # letzter Befehl, der mit 'gs' beginnt
```

Trap-Funktionalität ermöglicht sicheres Aufräumen oder spezifizierte Reaktionen auf Signale:
```
#!/bin/bash
trap 'echo "Skript beendet"; exit 1' INT TERM
trap 'echo "EXIT empfangen"; exit 0' EXIT

while true; do
  sleep 1
done
```

Debugging-Strategien:
- Aktivieren der Befehlsverfolgung während der Entwicklung:
```
set -x
# oder
PS4='+ ${BASH_SOURCE}:${LINENO}:${FUNCNAME[0]}: '
set -x
```
- Fehlerverhalten kontrollieren mit:
```
set -euo pipefail
```
- Ausgabe sauber halten und unerwartete Umgebungsvariablen schützen durch sorgfältiges Setzen von IFS und Variablen-Scoping.

Praktische Anwendungen im Arbeitsalltag:
- Ein kleines Skript, das bei Fehlern automatisch den aktuellen Verzeichniszustand protokolliert und später wiederhergestellt werden kann.
- Die Kombination aus Alias, History und Trap erlaubt schnelle Korrekturen und robuste Skripte, die sich in Montageprozessen gut in bestehende Workflows integrieren lassen.

Zusammenfassend ermöglichen Scripting, Automatisierung und Produktivität eine effiziente, reproduzierbare Arbeitsweise unter Linux. Durch das Verstehen grundlegender Konzepte, das sichere Planen von Aufgaben und das gezielte Debugging lassen sich repetitive Tätigkeiten minimieren und die Zuverlässigkeit der Systemarbeit deutlich erhöhen.
