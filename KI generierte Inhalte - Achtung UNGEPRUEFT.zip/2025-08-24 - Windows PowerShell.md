
# Windows PowerShell vom Anfänger bis zum Profi mit Praxisbeispielen

## Inhaltsverzeichnis

**1. Einstieg in Windows PowerShell**
  - 1.1 Was ist PowerShell? Grundlagen und Konzepte
  - 1.2 Erste Schritte: Installation, Startoptionen, ISE vs VS Code (Praxisbeispiel)
  - 1.3 Sicherheitsaspekte: Execution Policy und Signierung von Skripten (Praxisbeispiel)

**2. Grundlegende Befehle und Pipeline**
  - 2.1 Cmdlets, Parameter und die Pipeline-Grundlagen
  - 2.2 Hilfe, Entdeckung von Cmdlets und Arbeiten mit Objekten
  - 2.3 Praxisbeispiel: Objekte filtern, auswählen und formatieren

**3. Arbeiten mit Objekten, Eigenschaften und Methoden**
  - 3.1 Zugriff auf Eigenschaften und Methoden von Objekten
  - 3.2 Objektmanipulation: Transformieren und kombinieren von Objekten
  - 3.3 PSCustomObject erstellen und Typkonvertierungen (Praxisbeispiel)

**4. Dateien, Formate und Datenaustausch**
  - 4.1 Lesen und Schreiben von Textdateien
  - 4.2 Import/Export von CSV- und JSON-Daten
  - 4.3 Praxisbeispiel: Logdateien analysieren und aggregieren

**5. Funktionen, Skripte und Module**
  - 5.1 Funktionen, Parameter und Blocks
  - 5.2 Skripte, Parameter-Sets und Fehlerbehandlung
  - 5.3 Module erstellen und verwenden (Praxisbeispiel)

**6. Automatisierung und Aufgabenplanung**
  - 6.1 Geplante Aufgaben und Scheduling mit Task Scheduler
  - 6.2 Remoting, Hintergrundjobs und Runspaces
  - 6.3 Praxisbeispiel: Routine-Backup-Check automatisieren

**7. Debugging, Fehlerbehandlung und Logging**
  - 7.1 Fehlerbehandlung mit Try/Catch/Finally
  - 7.2 Debugging-Tools, Breakpoints und Diagnostik
  - 7.3 Logging und Auditing (Praxisbeispiel)

**8. Sicherheit, Best Practices und Testing**
  - 8.1 Execution Policy, Signieren und sichere Skript-Verwaltung
  - 8.2 Sicheres Remoting, WinRM und Just Enough Administration
  - 8.3 Pester-Tests und Qualitätskriterien (Praxisbeispiel)

**9. Fortgeschrittene Themen und Profi-Muster**
  - 9.1 Observability und fortgeschrittene Debugging-Techniken
  - 9.2 Desired State Configuration (DSC) Grundlagen
  - 9.3 Praxisprojekt: End-to-End Verwaltungs-Skriptpaket (Praxisbeispiel)


---

## KAPITEL: Einstieg in Windows PowerShell

### 1.1 Was ist PowerShell? Grundlagen und Konzepte

PowerShell ist ein plattformübergreifendes Automatisierungs- und Konfigurations-Framework von Microsoft, das auf der .NET-Laufzeit basiert. Im Kern handelt es sich um eine objektorientierte Shell, die Befehle (Cmdlets) sowie Skripte ausführt und dabei Daten als Objekte statt als rein Text verarbeitet. Dieser Objektstrom durchläuft eine Pipeline, wird von Cmdlets weiterverarbeitet und in der Regel als Objekte an nachfolgende Cmdlets übergeben. Dadurch lassen sich komplexe Abläufe robust, testbar und gut skalierbar beschreiben.

Zentrale Konzepte:
- Cmdlets: kleine, vorgestaltete Befehle mit klarer Namenskonvention (Verben-Nomen), z. B. Get-Process, Set-Location, Remove-Item.
- Pipeline: Objekte statt Text fließen von einem Cmdlet zum nächsten. Dies ermöglicht feine Selektion, Sortierung, Filterung und Transformation direkt in der Befehlsreihe.
- Objekte und Typen: Jeder Schritt der Pipeline arbeitet mit Objekten, deren Eigenschaften genutzt werden können, z. B. Dateien mit Name, Length, LastWriteTime.
- Provider und PSDrive: Zugriff auf verschiedene Datenquellen (Dateisystem, Registry, Zertifikatspeicher) als Dateisystempfade.
- Module und Help-System: Funktionen lassen sich modular erweitern; Hilfe lässt sich über Get-Help abrufen.
- Remoting und Sicherheit: Befehle können remote auf anderen Windows- oder Linux-Rechnern ausgeführt werden. Dabei spielen Policies, Authentifizierung und Signaturen eine Rolle.
- Skripte und Profile: Persistente Funktionen, Variablen und Konfigurationen lassen sich über Profile laden.

Typische Vorteile sind Stabilität durch Objekte statt Text, einfache Automatisierung komplexer Aufgaben, gute Testbarkeit und eine konsistente Benennungskonvention (Verb-Nomen). Beispiele zeigen oft Trends wie Datenabfragen, Systemüberwachung oder Konfigurationsmanagement.

Praxisnahe Beispiele:
- Objekte statt Text verarbeiten:
```
Get-Process | Sort-Object CPU -Descending | Select-Object -First 5
```
- Verzeichnisse rekursiv auflisten und sortieren:
```
Get-ChildItem -Path C:\Windows -Directory | Sort-Object Name
```
- Hilfe zu einem Cmdlet:
```
Get-Help Get-Process -Full
```

Wichtige Grundprinzipien:
- Konsistente Namensgebung (Verb-Nomen) erleichtert das Auffinden von Befehlen.
- Fehlerbehandlung erfolgt oft über Try-Catch-Blöcke oder die Pipelinenavigation mit ErrorAction.
- Skripte können mit Profilen automatisch beim Start geladen werden, um Funktionen und Aliases bereitzustellen.

Durch diese Konzepte wird PowerShell zu einer leistungsfähigen Plattform für Administration, Automatisierung und Orchestrierung in Windows-Umgebungen – und darüber hinaus.

### 1.2 Erste Schritte: Installation, Startoptionen, ISE vs VS Code (Praxisbeispiel)

PowerShell existiert in zwei Hauptformen: Windows PowerShell (fester Bestandteil vieler Windows-Versionen bis 5.1) und PowerShell 7.x (auch als pwsh bekannt), die auf .NET Core basiert und plattformübergreifend läuft. Die Installation von PowerShell 7 ist heute der empfohlene Weg für neue Automation-Projekte, während Windows PowerShell 5.1 oft noch Kompatibilität zu vorhandenen Skripten bietet.

Schritte zur Überprüfung und Installation:
- Vorhandene Version prüfen:
```
$PSVersionTable
```
- Falls PowerShell 7 nicht installiert ist, kann es über verschiedene Wege installiert werden:
```
winget install --id Microsoft.PowerShell --source winget
```
Alternativ kann der Download über die offizielle Website erfolgen (MSI-Installer).

Startoptionen und Arbeitsumgebung:
- Start über die traditionelle Shell (Windows PowerShell 5.x):
```
powershell
```
- Start über PowerShell 7 (pwsh):
```
pwsh
```
- Typische Arbeitsumgebung unter Windows Terminal:
Öffne Windows Terminal und füge eine neue Registerkarte für pwsh hinzu, oder wähle dort direkt pwsh als Standardprofil.

ISE vs VS Code (Praxisbeispiel):
- ISE (Integrated Scripting Environment) war lange Zeit eine einfache IDE für PowerShell, wird aber offiziell nicht mehr weiterentwickelt. Viele Funktionen fehlen im Vergleich zu modernen Editor-Umgebungen.
- Visual Studio Code (VS Code) mit dem PowerShell-Extension-Paket bietet folgende Vorteile:
  - IntelliSense, Syntax-Highlighting, bessere Fehlersuche
  - Integrierter Debugger für Skripte
  - Leichte Anpassbarkeit von Tastenkürzeln, Snippets und Profilen
  - Einfache Integration in Git und andere Entwickler-Workflows

Praxisbeispiel – Installation und erstes Setup:
- PowerShell 7 installieren (Beispiel über Winget):
```
winget install --id Microsoft.PowerShell --source winget
```
- VS Code installieren (falls noch nicht vorhanden) und PowerShell-Extension hinzufügen.
- Öffne in VS Code eine neue Datei mit der Endung .ps1. Schreibe ein kleines Beispielskript:
```
Write-Host "Willkommen in PowerShell 7"
Get-Process | Select-Object -First 3
```
- Script ausführen via Run Selection oder F5, mit dem integrierten Terminal, das pwsh verwendet.
- Optional: Profil anlegen, um Funktionen automatisch zu laden:
```
$PROFILE
```
- Beispiel-Profil-Inhalt:
```
function Show-TopCPULoad {
  Get-Process | Sort-Object CPU -Descending | Select-Object -First 5
}
```

Hinweise:
- ISE ist in aktuellen PowerShell-Versionen weniger relevant; VS Code mit PowerShell-Erweiterung ist der Standard für neue Projekte.
- Die Wahl zwischen Windows PowerShell und PowerShell 7 hängt von Abhängigkeiten, Modulen und Kompatibilität ab. Für neue Automatisierung empfiehlt sich PowerShell 7 wegen Leistung, Cross-Platform-Unterstützung und modernem Ökosystem.

Zusammengefasst bietet diese Kombination aus pwsh, Windows Terminal und VS Code eine moderne, stabile Entwicklungsumgebung für PowerShell von Anfänger bis Profi.

### 1.3 Sicherheitsaspekte: Execution Policy und Signierung von Skripten (Praxisbeispiel)

Sicherheitsaspekte sind zentral für die Arbeit mit PowerShell, insbesondere weil Skripte mächtig sind und unbeabsichtigte oder schädliche Aktionen verursachen können. Die Execution Policy bestimmt, welche Skripte in einer Umgebung überhaupt ausgeführt werden dürfen. Sie verhindert standardmäßig das versehentliche Ausführen unbekannter Skripte und Tools.

Grundlegende Policy-Arten (Kurzüberblick):
- Restricted: Standardmäßig keine Skriptausführung (nur interaktive Befehle möglich).
- RemoteSigned: Lokale Skripte müssen signiert sein, entfernte Skripte müssen signiert oder aus einer sicheren Quelle stammen.
- AllSigned: Alle Skripte müssen signiert sein, inklusive lokaler Skripte.
- Bypass: Ignoriert die Policy temporär; typischerweise für Testumgebungen.
- Undefined: Policy wurde nicht festgelegt, verhält sich wie die Policy der Machine.

Praxisbeispiel – Prüfung der aktuellen Policy:
```
Get-ExecutionPolicy -List
```
Praxisbeispiel – Policy ändern (empfohlen: RemoteSigned für den Alltagsgebrauch):
- Administratorrechte erforderlich, wenn Scope auf LocalMachine gesetzt wird:
```
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```
- Für eine vorübergehende Änderung in dieser Sitzung (ohne Persistenz):
```
Set-ExecutionPolicy Bypass -Scope Process
```

Praxisbeispiel – Skriptblocker testen:
- Erstelle eine Test-Datei TestScript.ps1 mit einfachem Inhalt:
```
Write-Host "Skript wird ausgeführt"
```
- Versuch der Ausführung (sollte je nach Policy blockiert sein):
```
.\TestScript.ps1
```

Signierung von Skripten (Praxisbeispiel):
- Signieren erleichtert die Ausführung unter AllSigned/RemoteSigned, insbesondere in Organisationen.
- Erzeuge ein Code-Signing-Zertifikat im Benutzerschlüsselbund:
```
$cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject "PowerShellCodeSigning" -CertStoreLocation Cert:\CurrentUser\My
```
- Signiere ein Skript:
```
$path = ".\TestScript.ps1"
Set-AuthenticodeSignature -FilePath $path -Certificate $cert
```
- Prüfe die Signatur:
```
Get-AuthenticodeSignature -FilePath $path
```

Best Practices:
- Verwende RemoteSigned oder AllSigned in Produktivumgebungen; signierte Skripte reduzieren das Risiko von Script-Injection.
- Verwalte Zertifikate zentral (z. B. über Gruppenrichtlinien oder zentrale Zertifikatverwaltung) und lagere private Schlüssel sicher.
- Für temporäre Experimente nutze Process- oder CurrentUser-Scopes, um Systemweite Auswirkungen zu vermeiden.
- Dokumentiere Policy-Änderungen und schule Teammitglieder hinsichtlich sicheren Skriptverhaltens.

Zusammenfassung:
PowerShell-Sicherheit basiert auf bewusst gesetzten Execution Policies und der Signierung von Skripten. In Praxisumgebungen ist RemoteSigned eine sinnvolle Default-Einstellung, während AllSigned strengeres Verhalten erzwingt. Die Signierung von Skripten erhöht die Vertrauenswürdigkeit, insbesondere in Multi-User- oder Unternehmensumgebungen. Praktische Übungen mit Testskripten, Policy-Tests und Signaturprüfungen helfen dabei, sicherheitsbewusst zu arbeiten, ohne die Produktivität unnötig zu beeinträchtigen.
## KAPITEL: Grundlegende Befehle und Pipeline

### 2.1 Cmdlets, Parameter und die Pipeline-Grundlagen

PowerShell-Cmdlets sind kompakte, eindeutig benannte Befehle, die als Grundbausteine jeder Skript- oder Interaktionsarbeit dienen. Sie folgen dem Prinzip Verb-Nomen (z. B. Get-Process, Set-Location) und sind in der .NET-Laufzeitumgebung implementiert. Cmdlets liefern Objekte, nicht einfache Textzeilen, und diese Objekte tragen Eigenschaften und Methoden, die in weiteren Cmdlets genutzt oder formatiert werden können. Dadurch entsteht eine leistungsfähige, typensichere Pipeline, in der Daten von einer Stage zur nächsten weitergegeben werden.

Wichtige Eigenschaften von Cmdlets:
- Klarer Namenskonventionsstil: Verb-Noun, oft mit optionalen Parametern.
- Das Pipeline-Verhalten: Die meisten Cmdlets akzeptieren Eingaben aus der Pipeline und geben Objekte weiter.
- Parameterbindung: Parameter können positionell oder mit Namen angegeben werden; manche Parameter sind mandatory, andere optional.

Typische Entdeckungs- und Hilfsmittel:
- Get-Command – Hilfe und Entdeckung neuer Cmdlets
- Get-Help – detaillierte Dokumentation zu einem Cmdlet
- Get-Alias – Abkürzungen/Alternativnamen
- Show-Command – grafische Hilfestellung zur Parameterwahl

Beispiele:
```
Get-Process
```

```
Get-Process | Where-Object { $_.CPU -gt 100 } | Sort-Object CPU -Descending | Select-Object -First 5 -Property Name, CPU
```

```
Get-Command -Verb Get -Noun *
```

```
Get-Help Get-Process -Full
```

Wichtige Konzepte:
- Pipeline-Grundlagen: Objekte, nicht Text, werden zwischen Cmdlets übergeben. Das bedeutet, dass jedes Element im Pipeline-Objekt ist und Zugriff auf Eigenschaften wie Name, CPU, Length etc. hat.
- ByValue vs ByPropertyName Pipelineinput: Manche Cmdlets akzeptieren Pipeline-Eingaben „by value“ (das Objekt selbst wird übergeben) oder „by property name“ (Werte aus bestimmten Eigenschaften werden zugewiesen). Zum Beispiel können Sie Objekte durch Piping in Where-Object filtern, ohne zuvor Properties manuell extrahieren zu müssen.
- Trickkisten für Anfänger: Nutzen Sie oft Get-Member, um die verfügbaren Eigenschaften eines Objekts kennenzulernen:
```
Get-Process | Get-Member -MemberType Properties
```

- Leistungs- und Stilangaben: Verwenden Sie Pipeline-Chains bewusst, um Lesbarkeit zu sichern. Verketten Sie nur dann weitere Schritte, wenn die Zwischenergebnisse sinnvoll weiterverarbeitet werden können.

Beispielhafte Struktur einer kurzen Pipeline, die Prozesse mit hohem CPU-Verbrauch sortiert und die wichtigsten Felder anzeigt:
```
Get-Process | Where-Object { $_.CPU -gt 100 } | Sort-Object CPU -Descending | Select-Object -First 10 -Property Name, Id, CPU
```

Zusammenfassung:
- Cmdlets sind die Bausteine der Shell.
- Die Pipeline transportiert Objekte, nicht rohen Text.
- Lernen Sie typische Cmdlets (Get-Command, Get-Help, Get-Member, Select-Object, Where-Object, Sort-Object, ForEach-Object), um komplexe Aufgaben schrittweise zu lösen.
- Nutzen Sie das Erkennen der Objektstruktur, um effektive Filter- und Formatierungsschritte zu entwickeln.

### 2.2 Hilfe, Entdeckung von Cmdlets und Arbeiten mit Objekten

Die effektive Nutzung von PowerShell beginnt mit guter Hilfe- und Entdeckungsarbeit. Get-Help, Get-Command und verwandte Befehle liefern Ihnen tiefe Einblicke in Funktionsumfang, Parameter und Anwendungsbeispiele. Dabei gilt: PowerShell arbeitet mit Objekten; das Verständnis der Objektstruktur ist der Schlüssel zum erfolgreichen Filtern, Transformieren und Anzeigen von Ergebnissen.

Wichtige Hilfebefehle:
- Get-Help: Bietet detaillierte Beschreibungen, Beispiele, Parameterinformationen.
- Get-Command: Sucht Cmdlets, Funktionen, Aliases nach Kriterien wie Verb, Noun, Modul oder Name.
- Get-Member: Zeigt die Eigenschaften (Properties) und Methoden der Objekte, die von einem Cmdlet ausgegeben werden.
- Update-Help: Aktualisiert die eingebauten Hilfedateien, insbesondere bei neuen Cmdlets oder Sprachen.

Beispiele:
```
Get-Help Get-Process -Full
```

```
Get-Command -Noun Service
```

```
Get-Command -Verb Get -Noun Service
```

```
Get-Service | Get-Member
```

```
Get-Service | Where-Object { $_.Status -eq 'Running' } | Select-Object -Property Status, Name
```

Hinweise zur Hilfe-Nutzung:
- -Full, -Examples, -Online ermöglichen unterschiedlich tiefe Einblicke. Wählen Sie je nach Kontext den passenden Modus.
- Up-to-Date-Hilfe: Führen Sie gelegentlich Update-Help aus, insbesondere wenn Sie online verfügbare neue Cmdlets nutzen:
```
Update-Help
```

Arbeiten mit Objekten:
- Jedes Objekt besitzt Eigenschaften, z. B. Name, Status, CPU, LastWriteTime. Verwenden Sie Get-Member, um die verfügbaren Properties aufzudecken.
- Script-Blöcke und die Variable $_: In Where-Object oder ForEach-Object greifen Sie in Skriptblöcken typischerweise mit $_ auf das aktuelle Pipeline-Objekt zu:
```
Get-Process | ForEach-Object { $_.Name + " (" + $_.Id + ")" }
```

Formatierung vs. Datenlogik:
- Seien Sie vorsichtig mit Formatierung cmdlets wie Format-Table oder Format-List in längeren Pipelines. Sie erzeugen formatierte Ausgaben, die nicht mehr weiter als Objekte weitergegeben werden. Am Ende einer Pipeline ist Formatierung akzeptabel, aber bei weiteren Verarbeitung oft hinderlich.
- Spezielle Ausgabe an Dateien oder in Tabellenform kann mit Export-Csv oder Out-File erfolgen:
```
Get-Service | Select-Object -Property Name, Status | Export-Csv -Path "services.csv" -NoTypeInformation
```

Praxis-Tipp:
- Kombinieren Sie Entdeckungsbefehle wie Get-Command mit konkreten Aufgabenfeldern, z. B. Serviceverwaltung, Prozessanalyse oder Log-Überwachung, um gezielt die passenden Cmdlets zu finden.
- Merken Sie sich häufige Property-Namen wie Name, Status, Id, CPU, LastWriteTime, Length – diese helfen beim schnellen Filtering und Sorting.

Objekte arbeiten statt Textverarbeitung zu lernen, öffnet die Tür zu robusten Skripten, die über einfache Befehle hinausgehen und auch komplexe Automatisierungen ermöglichen.

### 2.3 Praxisbeispiel: Objekte filtern, auswählen und formatieren

In diesem Praxisbeispiel werden Sie eine typische Aufgabe lösen: Eine übersichtliche Liste von Dateien in einem Verzeichnis erstellen, die innerhalb der letzten sieben Tage geändert wurden, und dann die relevanten Spalten in einer gut lesbaren Tabelle präsentieren. Die Pipeline verknüpft Filtern, Sortieren und die projektspezifische Auswahl von Eigenschaften.

Beispiel 1: Dateien der letzten 7 Tage in C:\Temp
```
Get-ChildItem -Path C:\Temp -File -Recurse |
Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
Sort-Object LastWriteTime -Descending |
Select-Object -Property FullName, Length, LastWriteTime -First 20
```

Beispiel 2: Ereignisprotokolle nach Fehlern der letzten 50 Einträge tabellarisch darstellen
```
Get-EventLog -LogName Application -Newest 50 |
Where-Object { $_.EntryType -eq 'Error' } |
Format-Table -Property TimeGenerated, Source, Message -AutoSize
```

Beispiel 3: Prozesse mit hohem Ressourcenverbrauch gezielt analysieren
```
Get-Process |
  Where-Object { $_.CPU -gt 100 } |
  Sort-Object CPU -Descending |
  Select-Object -First 10 -Property Name, Id, CPU
```

Erläuterungen zu den Beispielen:
- Get-ChildItem erzeugt Objekte der Typen FileInfo bzw. DirectoryInfo; diese besitzen Eigenschaften wie FullName, Length, LastWriteTime.
- Where-Object filtert anhand eines Skriptblocks; $_ referenziert das aktuelle Pipeline-Objekt.
- Sort-Object arrangiert Elemente nach einem oder mehreren Kriterien; -Descending invertiert die Sortierung.
- Select-Object beschränkt die Ausgabe auf relevante Eigenschaften und erlaubt auch Projektion (neue Objekte mit ausgewählten Feldern).
- Format-Table sorgt für eine übersichtliche tabellarische Darstellung; in einer weiterführenden Pipeline sollten Sie das vermeiden, wenn Sie das Ergebnis weiter verarbeiten möchten.

Diese Praxisbeispiele zeigen, wie Cmdlets, Parameter und Pipeline-Grundlagen zusammenwirken: Filtern, Projektionen wählen, Ergebnisse sinnvoll formatieren, und dabei die Objektnatur der Pipeline nutzen, um robuste und wiederverwendbare Skripte zu erstellen.
## Arbeiten mit Objekten, Eigenschaften und Methoden

### 3.1 Zugriff auf Eigenschaften und Methoden von Objekten

In PowerShell sind fast alle Werte Objekte. Jedes Objekt besitzt Eigenschaften (Data) und oft auch Methoden (Funktionen), die auf dem Objekt operieren. Ein grundlegendes Verständnis von Zugriff, Weiterverarbeitung und Ausgabe dieser Komponenten ist essenziell, um PowerShell effizient zu nutzen.

Zugriff auf Eigenschaften erfolgt in der Regel über die Punktnotation:
```
$obj = [pscustomobject]@{ Name = 'Alice'; Alter = 30; Stadt = 'Berlin' }

$obj.Name    # 'Alice'
$obj.Alter   # 30
$obj.Stadt   # 'Berlin'
```
Eigenschaften können auch in Pipelines extrahiert werden, z. B. mit Select-Object oder Where-Object, um nur relevante Felder zu erhalten:
```
$obj | Select-Object Name, Stadt
```

Viele Objekte verfügen zusätzlich über Methoden. Methoden sind Funktionen, die an das Objekt gebunden sind und dessen Zustand verändern oder berechnen. Ein häufiges Muster ist der Aufruf von Methoden auf String- oder Datumsobjekten:
```
$date = Get-Date
$date.ToString('yyyy-MM-dd')        # z. B. '2025-08-24'

$txt = 'PowerShell'
$txt.ToUpper()                       # 'POWERSHELL'
```
Hinweis: Nicht jedes Objekt besitzt sinnvolle oder zugängliche Methoden. In der Praxis wird man häufig Methoden von Werteobjekten (Strings, Zahlen, DateTime) verwenden, während komplexere Objekte oft Eigenschaften zur Repräsentation ihres Zustands bereitstellen.

Schneller Einstieg in Typen und ihre Members liefert der Befehl:
```
$obj | Get-Member
```
Dieser Befehl listet alle verfügbaren Eigenschaften und Methoden des Objekts auf. Die Ausgabe hilft zu entscheiden, welche Felder man extrahiert oder wie man das Objekt transformieren kann.

Hybride Zugriffe, z. B. verschachtelte Objekte oder Listen, werden durch mehrstufige Pfade realisiert:
```
$nested = [pscustomobject]@{ User = [pscustomobject]@{ Name = 'Alice'; Kontakt = [pscustomobject]@{ Email = 'alice@example.com' } } }

$nested.User.Name             # 'Alice'
$nested.User.Kontakt.Email    # 'alice@example.com'
```

Um robust mit Nullwerten umzugehen, kann man $null-sichere Zugriffe nutzen (PowerShell 7+ unterstützt den ??-Operator als Null-Coalescing-Operator):
```
$wert = $obj.UnbekannteEigenschaft ?? 'Standardwert'
```

Zusammengefasst: Eigenschaften liefern den Zustand eines Objekts, Methoden ermöglichen Operationen darauf. Der gezielte Zugriff mit Dot-Notation, kombiniert mit Get-Member sowie mit kalkulierten Eigenschaften in Pipelines, ermöglicht flexible Abfragen und Transformationen.

Beispiele in der Praxis:
```
# Eigenschaftslesen und kalkulierte Anzeige
Get-Date | Select-Object -Property Year, Month, Day, @{Name='DateISO'; Expression={$_.ToString('yyyy-MM-dd')}}

# Methodenaufruf auf einem Objekt
$datum = Get-Date
$datum.AddDays(7).ToString('yyyy-MM-dd')
```

| Eigenschaft | Typ | Beispiel |
| - | - | - |
| Name | string | 'Alice' |
| Alter | int | 30 |
| Stadt | string | 'Berlin' |

### 3.2 Objektmanipulation: Transformieren und kombinieren von Objekten

Objekte lassen sich transformieren, neu strukturieren und sinnvoll kombinieren. Dadurch entstehen neue Objekte, die besser zu den Anforderungen einer bestimmten Aufgabe passen. In diesem Abschnitt werden typische Muster vorgestellt: Transformation von Eigenschaften, Erstellung neuer Objekte aus vorhandenen Daten und das Zusammenführen von Objekten aus mehreren Quellen.

Transformation von Objekten erfolgt oft durch ForEach-Object oder durch Select-Object mit kalkulierten Eigenschaften. Beispiel: Aus einer einfachen Liste von Zahlen eine Liste von Objekten mit Originalwert und Quadrat bilden.
```
$numbers = 1..5
$transformed = $numbers | ForEach-Object {
  [pscustomobject]@{ Original=$_; Quadrat=$_*$_ }
}
```
Ausgabe:
```
Original Quadrat
-------- -------
1        1
2        4
3        9
4       16
5       25
```

Kalkulierte Eigenschaften ermöglichen das Umformen von Daten, ohne neue Objekte explizit zu bauen:
```
Get-Process -Name powershell -ErrorAction SilentlyContinue | Select-Object Id, ProcessName, @{
  Name='CPU(MS)'; Expression={ [math]::Round($_.CPU, 2) }
}
```
Kombinieren von Objekten aus unterschiedlichen Quellen erfolgt oft über eine explizite Zusammenführung in ein neues PSCustomObject:
```
$user = [pscustomobject]@{ Id = 1; Name = 'Alice'; Dept = 'Finance' }
$contact = [pscustomobject]@{ Id = 1; Email = 'alice@example.com' }

$merged = [pscustomobject]@{
  Id = $user.Id
  Name = $user.Name
  Dept = $user.Dept
  Email = $contact.Email
}
```
Eine häufige Praxis ist das Joinsieren von Sammlungen anhand eines Schlüssels. In PowerShell realisiert man dies meist durch verschachtelte Schleifen oder durch eine Hash-Tabelle zur Indexierung:
```
$users = @(
  [pscustomobject]@{ Id=1; Name='Alice' },
  [pscustomobject]@{ Id=2; Name='Bob' }
)
$emails = @(
  [pscustomobject]@{ Id=1; Email='alice@example.com' },
  [pscustomobject]@{ Id=2; Email='bob@example.com' }
)

$joined = foreach ($u in $users) {
  $e = $emails | Where-Object { $_.Id -eq $u.Id }
  [pscustomobject]@{
    Id = $u.Id
    Name = $u.Name
    Email = $e.Email
  }
}
```
Eine weitere nützliche Technik sind Sammel- bzw. Listen-Transformationen, z. B. das Umbenennen von Eigenschaften oder das Hinzufügen neuer Felder:
```
$proc = Get-Process -Name powershell -ErrorAction SilentlyContinue
$proc | Select-Object @{
  Name='ProcessId'; Expression={$_.Id}
}, @{
  Name='ProcessName'; Expression={$_.ProcessName}
}, @{
  Name='MemoryMB'; Expression={ [math]::Round($_.WS / 1MB, 2) }
}
```

Zusammengefasst: Transformieren bedeutet, vorhandene Objekte in eine neue Form zu überführen. Kombinieren bedeutet, Informationen aus mehreren Objekten zu einem kohärenten neuen Objekt zusammenzufassen. Durch kalkulierte Eigenschaften, ForEach-Objekt und sinnvolle Zusammenführung entstehen maßgeschneiderte Datensätze für Berichte, Diagnosen oder weitere Automatisierungsschritte.

### 3.3 PSCustomObject erstellen und Typkonvertierungen (Praxisbeispiel)

Das PSCustomObject ist der zentrale Baustein für maßgeschneiderte Objekte in PowerShell. Es ermöglicht eine klare, strukturierte Darstellung von Daten, insbesondere wenn Sie Daten aus unterschiedlichen Quellen zusammenführen oder verarbeiten möchten. In diesem Praxisbeispiel zeigen wir die Erstellung eines PSCustomObject, anschließend Typkonvertierungen der Felder sowie eine sinnvolle Nutzung in Typ-übergreifenden Kontexten.

1) Erstellung eines PSCustomObject mit klaren Typen
```
$person = [pscustomobject]@{
  Vorname = 'Anja'
  Nachname = 'Meyer'
  Alter = 28
  Aktiv = $true
}
```
2) Typkonvertierung der Eigenschaften
```
$personTyped = [pscustomobject]@{
  Vorname = [string]$person.Vorname
  Nachname = [string]$person.Nachname
  Alter = [int]$person.Alter
  Aktiv = [bool]$person.Aktiv
}
```
Hinweis: Oft stammen Eingaben aus CSV/JSON-Dateien, bei denen Zahlen oder Booleans als Strings vorliegen. Durch explizite Typkonvertierung sichern Sie konsistente Typen im weiteren Verlauf.

3) Nutzung der konvertierten Objekte (Beispiele)
```
$personTyped | ConvertTo-Json -Depth 2
```
Dies erzeugt eine strukturierte JSON-D Darstellung, ideal für Logs oder API-Integrationen.

4) Konvertierung in eine Klasse (Fortgeschritten)
PowerShell unterstützt Klassen (seit PS 5). Oft ist es sinnvoll, strukturierte Objekte in Instanzen einer Klasse zu überführen, um Verhalten (Methoden) zu kapseln.

```
class Person {
  [string]$Vorname
  [string]$Nachname
  [int]$Alter
  [bool]$Aktiv

  Person([string]$vorname, [string]$nachname, [int]$alter, [bool]$aktiv) {
    $this.Vorname = $vorname
    $this.Nachname = $nachname
    $this.Alter = $alter
    $this.Aktiv = $aktiv
  }

  [string]GetFullName() {
    "$($this.Vorname) $($this.Nachname)"
  }
}

$typedInstance = [Person]::new($personTyped.Vorname, $personTyped.Nachname, $personTyped.Alter, $personTyped.Aktiv)
$typedInstance.GetFullName()   # z. B. "Anja Meyer"
```

5) Praktische Anwendungsfälle
- Importierte CSV-Daten in strukturierte Objekte überführen, anschließend Typen korrigieren, um Konsistenz für Berichte sicherzustellen.
- Objekte in JSON oder XML exportieren, um sie mit anderen Systemen auszutauschen.
- Datenkonsistenz vor der Weiterverarbeitung sicherstellen, z. B. Datum/Uhrzeit, numerische Werte und Boolesche Flags in korrekten Typen speichern.

Wichtig ist, dass PSCustomObject nicht nur als Datenträger dient, sondern als Brückenkopf zwischen Rohdaten und sauber strukturierten, typisierten Objekten, die weiterführende Verarbeitungsschritte zuverlässig unterstützen. Die beschriebenen Muster helfen, PowerShell-Skripte robust, verständlich und leichter wartbar zu gestalten.
## KAPITEL: Dateien, Formate und Datenaustausch

### 4.1 Lesen und Schreiben von Textdateien

Das Arbeiten mit Textdateien gehört zu den häufigsten Aufgaben in PowerShell. Der grundlegende Zugriff erfolgt über Get-Content zum Einlesen sowie Set-Content, Out-File oder Add-Content zum Schreiben. Wichtige Aspekte sind Encoding, Zeilenstruktur und Fehlerbehandlung.

Wichtige Befehle und Konzepte:
- Lesen zeilenweise:
  - Get-Content -Path "Pfad\Datei.txt"
  - Dabei werden standardmäßig Zeile für Zeile Objekte erzeugt.
- Lesen als einen einzigen Textblock:
  - Get-Content -Path "Pfad\Datei.txt" -Raw
  - Alternativ: Get-Content -Path "Pfad\Datei.txt" | Out-String
- Encoding:
  - -Encoding UTF8, -Encoding ASCII, -Encoding Unicode, -Encoding UTF8BOM
  - Wichtiger Hinweis: UTF-8 mit BOM kann BOM am Anfang der Datei erzeugen; viele Parser bevorzugen UTF-8 ohne BOM.
- Schreiben:
  - Set-Content -Path "Pfad\Datei.txt" -Value $Inhalt -Encoding UTF8
  - Out-File -FilePath "Pfad\Datei.txt" -InputObject $Inhalt -Encoding UTF8
- Anhängen:
  - Add-Content -Path "Pfad\Datei.txt" -Value "Neue Zeile"
- Fehlerbehandlung und Robustheit:
  - Test-Path -Path "Pfad\Datei.txt" prüft Existenz.
  - Try/Catch um IO-Fehler abzufangen.
- Verarbeitung in der Pipeline:
  - Get-Content "Datei.txt" | ForEach-Object { $_.Trim() }

Anwendungsbeispiele:
- Lese eine Logdatei zeilenweise, filtere relevante Zeilen und schreibe die Ergebnisse in eine neue Datei:
  ```
  $pfad = "C:\Logs\application.log"
  Get-Content -Path $pfad |
    Where-Object { $_ -match "ERROR" } |
    Set-Content -Path "C:\Logs\errors.log" -Encoding UTF8
  ```
- Zwingend notwendige Fehlerabfrage vor dem Lesen:
  ```
  $pfad = "C:\Data\input.txt"
  if (Test-Path $pfad) {
    $content = Get-Content -Path $pfad -Encoding UTF8
  } else {
    Write-Error "Datei nicht gefunden: $pfad"
  }
  ```
- Arbeiten mit großen Dateien:
  - Standardlesen Zeile für Zeile vermeidet hohen Speicherverbrauch.
  - Für sehr große Dateien kann -ReadCount angepasst werden, um Performance zu optimieren, oder eine Streaming-Alternative mit einem StreamReader genutzt werden:
  ```
  $pfad = "C:\Data\große_datei.txt"
  $reader = [IO.File]::OpenText($pfad)
  try {
    while (($line = $reader.ReadLine()) -ne $null) {
      # Zeile verarbeiten
    }
  } finally {
    $reader.Close()
  }
  ```
- Speichern eines transformierten Dateiinhalts:
  ```
  $pfad = "C:\Data\input.txt"
  $ausgabe = Get-Content -Path $pfad | ForEach-Object { $_.ToUpper() }
  $ausgabe | Set-Content -Path "C:\Data\output.txt" -Encoding UTF8
  ```

Zusammenfassung:
- Get-Content liest Dateien flexibel zeilenweise oder als einen Block.
- Set-Content, Out-File und Add-Content ermöglichen Schreiben und Anhängen unter Berücksichtigung des Encodings.
- Fehlerbehandlung und robuste Pfadprüfungen erhöhen die Zuverlässigkeit von Skripten im Alltag.

### 4.2 Import/Export von CSV- und JSON-Daten

CSV- und JSON-Datenformate sind in der Praxis Standard für den Datenaustausch. PowerShell bietet native Cmdlets für beide Formate: Import-Csv/Export-Csv sowie ConvertFrom-Json/ConvertTo-Json. Der Vorteil liegt in der automatischen Umwandlung in Objekte, die sich anschließend bequem weiterverarbeiten lassen.

CSV
- Import-Csv erzeugt aus jeder Zeile ein PSObject mit Eigenschaften aus der Kopfzeile.
- -Delimiter zum Beispiel Semikolon, wenn CSV-Dateien anders getrennt sind.
- -Encoding UTF8 oder andere Encodings.
- -NoTypeInformation beim Export, um unnötige Typinformationen zu vermeiden.
Beispiele:
```
$csvPath = "C:\Data\personen.csv"
$personen = Import-Csv -Path $csvPath
# Auswahl und Transformation
$adulten = $personen | Where-Object { [int]$_.Alter -ge 18 } | Select-Object Name, Alter, Email
# Export
$adulten | Export-Csv -Path "C:\Data\personen_adulti.csv" -NoTypeInformation -Encoding UTF8
```

JSON
- ConvertFrom-Json liest JSON-Text und wandelt ihn in Objekte um.
- ConvertTo-Json konvertiert Objekte in JSON-Text; Depth steuert die Verschachtelung.
Beispiele:
```
$jsonPath = "C:\Data\bestellungen.json"
$jsonText = Get-Content -Path $jsonPath -Raw
$bestellungen = ConvertFrom-Json -InputObject $jsonText

# Verarbeitung
$hoheKosten = $bestellungen | Where-Object { $_.Total -gt 1000 }

# Exportieren
$hoheKosten | ConvertTo-Json -Depth 4 | Set-Content -Path "C:\Data\hoheKosten.json" -Encoding UTF8
```

Datenqualität und Fehlerbehandlung:
- Validieren Sie Importdaten vor der weiteren Verarbeitung (prüfen Sie Felder, Typen, fehlende Werte).
- Verwenden Sie Try/Catch-Blöcke um IO-Fehler abzufangen.
- Beachten Sie Encoding-BOMs, insbesondere beim Austausch mit externen Systemen.

Tipps:
- -Delimiter kann auch zwingend notwendig sein, z. B. Import-Csv -Delimiter ';'.
- -NoTypeInformation verhindert zusätzliches Typ-Header in CSV-Dateien.
- JSON-Ein- und Ausgabe ist ideal für verschachtelte Strukturen; verwenden Sie -Depth, um Verschachtelung abzubilden.

### 4.3 Praxisbeispiel: Logdateien analysieren und aggregieren

Ziel dieses Praxisbeispiels ist es, eine Logdatei systematisch zu analysieren, zu aggregieren und Ergebnisse attraktiv zu präsentieren. Wir verwenden ein typisches Logformat mit Zeitstempel, Levels und Meldung:
- Format-Beispielzeilen:
  ```
  [2024-07-21 14:23:12] INFO - User 42 logged in
  [2024-07-21 14:25:03] ERROR - Failed to connect to database
  [2024-07-21 14:25:04] WARN - Slow response detected
  ```

Vorgehen:
1) Einlesen der Logzeilen und Parsen der Felder Timestamp, Level und Message.
2) Aggregation pro Stunde (YYYY-MM-DD HH) und Zählen der Gesamtzeilen sowie der Level-Verteilungen.
3) Ausgabe der Ergebnisse in Konsole und optional Export als CSV/JSON.

Relevante Code-Beispiele:
```
$logPath = "C:\Logs\application.log"

# Schritt 1: Zeilen parsen
$logEntries = Get-Content -Path $logPath -Encoding UTF8 |
  ForEach-Object {
    if ($_ -match '^\[(?<ts>[^\]]+)\]\s+(?<level>\w+)\s*-\s*(?<msg>.*)$') {
      [PSCustomObject]@{
        Timestamp = [datetime]::ParseExact($Matches['ts'], 'yyyy-MM-dd HH:mm:ss', $null)
        Level     = $Matches['level']
        Message   = $Matches['msg']
      }
    }
    else { $null }
  } | Where-Object { $_ }

# Schritt 2: Aggregation pro Stunde und Level
$aggregation = $logEntries | Group-Object -Property { $_.Timestamp.ToString('yyyy-MM-dd HH') } | ForEach-Object {
  $hour = $_.Name
  $group = $_.Group
  $levelCounts = $group | Group-Object -Property Level | ForEach-Object {
    [PSCustomObject]@{ Level = $_.Name; Count = $_.Count }
  }
  [PSCustomObject]@{
    Hour   = $hour
    Total  = $_.Count
    Levels = $levelCounts
  }
}

# Schritt 3: Ausgabe und Export
$aggregation | Format-Table -Property Hour, Total
$aggregation | Export-Csv -Path "C:\Logs\log_summary.csv" -NoTypeInformation -Encoding UTF8

# Optional: zusätzliche Kennzahlen
$totalLines = $logEntries.Count
$errorLines = ($logEntries | Where-Object { $_.Level -eq "ERROR" }).Count
$errorRate  = if ($totalLines -eq 0) { 0 } else { [double]$errorLines / $totalLines }

"Total lines: $totalLines"
"Error lines: $errorLines"
"Error rate: {0:P2}" -f $errorRate
```

Hinweise zur Praxis:
- Anpassungen des Formats (z. B. andere Datum-/Uhrzeit-Formate) erfordern eine Anpassung der Regex und der ParseExact-Anweisung.
- Für sehr große Logdateien empfiehlt sich ein Streaming-Ansatz oder das Splitten der Datei in Teile, um Speicherverbrauch zu kontrollieren.
- Die exportierten Aggregationen können als Vorlagen für Dashboards dienen oder per Planer regelmäßig aktualisiert werden.

Zusammenfassung:
- Die Analyse von Logdateien wird durch saubere Parsing-Schritte, robuste Aggregationen und klare Ausgaben praktikabel.
- Durch Exportoptionen in CSV/JSON lassen sich Erkenntnisse weiterverarbeiten oder in Berichten visualisieren.
- Das vorgestellte Muster lässt sich auf andere Logformate adaptieren und dient als solides Grundgerüst für fortgeschrittene Log-Analysen.
## KAPITEL: Funktionen, Skripte und Module

### 5.1 Funktionen, Parameter und Blocks

Funktionen sind das zentrale Baustein in PowerShell, um wiederverwendbare Logik zu kapseln. Sie ermöglichen strukturierte, testbare und gut wartbare Skripte. Eine Funktion kann einfache Aktionen ausführen, Parameter entgegennehmen, Werte zurückgeben oder in den Output pipen. Wichtige Konzepte sind: Parameterdeklaration, Validierung, Parameter-Sets, CmdletBinding-Attribute und Block-Strukturen wie Begin/Process/End.

- Funktionen definieren
  - Mit dem Keywort function und einem Namen deklarieren Sie eine neue Funktion.
  - Optional kann eine Funktion das CmdletBinding-Attribut tragen, damit sie sich wie ein Cmdlet verhält (Was-wenn-, Confirm-Parameter, Pipeline-Unterstützung, gemeinsame Parameter).

- Parameter und Validierung
  - Parameter werden in einem Param()-Block oder in der Inline-Param()-Syntax definiert.
  - Parameterattribute steuern Verhalten wie Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName, ParameterSetName, ValidateNotNullOrEmpty, ValidateRange, ValidatePattern, etc.
  - Parameter-Sets ermöglichen alternative Aufrufarten derselben Funktion. Nur ein Parameterset muss beim Aufruf erfüllt sein.

- Blocks: Begin/Process/End
  - Advanced Functions verwenden oft Begin, Process, End Blöcke und ermöglichen so eine Pipeline-Verarbeitung.
  - Begin führt Initialisierung aus, Process wird pro Pipeline-Einheit aufgerufen, End führt Aufräumarbeiten durch.

- Beispiel: Advanced Function mit Parameter und Blocks
```
function Get-Greeting {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Name,

        [Parameter(ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Message = "Hallo"
    )

    begin {
        Write-Verbose "Vorbereitung..."
    }

    process {
        "$Message, $Name!"
    }

    end {
        Write-Verbose "Bereitgestellt von Get-Greeting"
    }
}
```

- Funktionsauftrag, Rückgabe und Fehlersicherheit
  - PowerShell gibt Objekte zurück; verwenden Sie Write-Output oder geben Sie Objekte direkt zurück.
  - Verwenden Sie Write-Error oder Throw für Fehler. Throw erzeugt einen terminating Fehler, Write-Error erzeugt standardmäßig einen nicht-terminierenden Fehler.
  - Nutzen Sie Try/Catch/Finally, um Ausnahmebehandlung sauber zu gestalten.
  - Nutzen Sie Schalter wie -WhatIf oder -Confirm, wenn Sie CmdletBinding verwenden.

- Praktische Hinweise
  - Halten Sie Funktionen klein und fokussiert; eine Funktion sollte eine klare Aufgabe haben.
  - Dokumentieren Sie Parameter (mit Comment-Based Help oder externen Dokumentationen).
  - Testen Sie Funktionen, idealerweise mit Pester, um Validierungen, Produktrückgaben und Fehlerpfade abzudecken.

Beispiel für eine kleine Hilfsfunktion mit Parameter-Sets und Validierung:
```
function Convert-Input {
    [CmdletBinding(DefaultParameterSetName="Text")]
    Param(
        [Parameter(ParameterSetName="Text", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Text,

        [Parameter(ParameterSetName="Number", Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$Number
    )

    process {
        switch ($PSCmdlet.ParameterSetName) {
            "Text"   { return $Text.ToUpper() }
            "Number" { return $Number * 2 }
        }
    }
}
```

Zusammenfassung
- Funktionen schützen Logik vor Duplizierung und fördern Wiederverwendbarkeit.
- Parameter-Sets ermöglichen flexible API-Designs.
- Begin/Process/End erleichtern Pipeline-Verarbeitung.
- Fehlerbehandlung mit Try/Catch/Finally erhöht Stabilität.

Wenn Sie sich weiter vertiefen möchten, probieren Sie eine Funktion aus, die über mehrere Parameter-Sets unterschiedliche Rückgaben erzeugt (z. B. Text- oder Zahlenformat), und testen Sie mit Pipeline-Eingaben.

---

### 5.2 Skripte, Parameter-Sets und Fehlerbehandlung

Skripte (.ps1-Dateien) sind eine lose Sammlung von Funktionen, Logik und Ablaufsteuerung, die eigenständig oder als Bestandteil größerer Werkzeuge genutzt werden. Der Aufbau ähnelt dem einer Funktion, umfasst jedoch typischerweise Parameter, Hauptlogik, Fehlerbehandlung und oft eine klare Start- und Endphase.

- Parameter und Param-Block
  - Ein Skript kann Parameter in einem Param()-Block definieren. Dadurch lässt sich das Skript wie ein Cmdlet verwenden.
  - ParameterSets ermöglichen alternative Aufrufmuster. Jeder Parameter gehört zu einem bestimmten Set; PowerShell prüft, ob ein gültiges Set erfüllt ist.

- Fehlerbehandlung
  - Try/Catch/Finally erlaubt das Abfangen von Ausnahmen, Logging von Fehlern und nachhaltige Bereinigungen.
  - Throw erzeugt einen terminating Fehler; Write-Error erzeugt einen nichtterminierenden Fehler.
  - Trap ist eine ältere Methode, wird heute weniger genutzt, da Try/Catch die robuste Lösung darstellt.
  - -ErrorAction, $ErrorActionPreference und $PSNativeCommandError geben Feinsteuerung über Fehlerpfade.

- Beispiel: Skript mit Parametern, Parameter-Sets und Fehlerbehandlung
```
param(
    [Parameter(Mandatory=$true, ParameterSetName="Get")]
    [string]$Path,

    [Parameter(Mandatory=$true, ParameterSetName="Inspect")]
    [string]$PathToInspect,

    [Parameter()]
    [ValidateSet("Detail","Summary")]
    [string]$Output = "Detail"
)

begin {
    $startTime = Get-Date
    Write-Verbose "Skript gestartet: $startTime"
}
process {
    try {
        if (-not (Test-Path $Path)) {
            throw "Pfad nicht gefunden: $Path"
        }

        if ($PSCmdlet.ParameterSetName -eq "Get") {
            Get-ChildItem -Path $Path | Select-Object Name, Length
        } elseif ($PSCmdlet.ParameterSetName -eq "Inspect") {
            $info = Get-ChildItem -Path $PathToInspect -Recurse -ErrorAction Stop
            if ($Output -eq "Detail") {
                $info | Format-List
            } else {
                $info.Count
            }
        }
    } catch {
        Write-Error "Fehler beim Zugriff: $_"
        # ggf. weitere Fehlerbehandlung, Logging
    }
}
end {
    $endTime = Get-Date
    Write-Verbose "Skript beendet: $endTime (Dauer: $($endTime-$startTime))"
}
```

- Praktische Tipps
  - Verwenden Sie Param( ) mit ParameterSets, um klare, eindeutige Aufrufpfade zu definieren.
  - Nutzen Sie -WhatIf/-Confirm wenn es um potenziell destruktive Operationen geht.
  - Loggen Sie Fehler systematisch (Datum, Pfad, Ausnahme) und geben Sie nützliche Meldungen aus.

- Fehlertypen und -pfade
  - Nichtterminierende Fehler ermöglichen dem Aufrufer, Entscheidungen zu treffen, während der Skriptablauf fortfährt.
  - Terminierende Fehler stoppen den Skriptlauf sofort und springen in den Catch-Block.

Tabellarische Übersicht zu Parameter-Sets (Beispiel):
```
| ParameterSetName | Verwendungszweck                 | Beispielparameter        |
|------------------|-----------------------------------|--------------------------|
| Get              | Dateien aus Verzeichnis holen     | -Path                   |
| Inspect          | Verzeichnisinhalt detailliert prüfen| -PathToInspect        |
```

Fortsetzung der robusten Fehlerbehandlung: Verwenden Sie imobilisierte Fehlerpfade, definieren Sie sinnvolle Fehlermeldungen und stellen Sie sicher, dass alle Ressourcen freigegeben werden (Dateien schließen, Handles freigeben).

---

### 5.3 Module erstellen und verwenden (Praxisbeispiel)

Module sind der zentrale Mechanismus, um Funktionen, Cmdlets, Skripte und Ressourcen zu paketieren und wiederverwendbar zu machen. Ein Modul bündelt Code in eine einzelne Export-Assembly oder eine psd1-basierte Manifestdatei, die bestimmte Funktionen exportiert und Abhängigkeiten verwaltet.

- Struktur eines einfachen Moduls
  - Ordner: 
    - InventoryTools
      - InventoryTools.psm1
      - InventoryTools.psd1 (optional)
  - Das psd1-Manifest kann Funktionen zum Export, Abhängigkeiten, Version etc. deklarieren.

- Praktisches Beispiel: Ein kleines Inventar-Toolset
  - Ziel: Ein Modul, das zwei Funktionen bereitstellt: Get-FolderSize (Größe eines Ordners) und Get-RecentFiles (neueste Dateien in einem Verzeichnis).

- Datei-Inhalte
```
# InventoryTools.psm1
function Get-FolderSize {
    [CmdletBinding()]
    param([string]$Path)

    if (-not (Test-Path $Path)) { throw "Pfad nicht gefunden: $Path" }
    $size = (Get-ChildItem -Path $Path -Recurse -File | Measure-Object -Property Length -Sum).Sum
    [pscustomobject]@{
        Path       = (Resolve-Path $Path).Path
        SizeBytes  = $size
        SizeMB     = [math]::Round($size / 1MB, 2)
    }
}

function Get-RecentFiles {
    [CmdletBinding()]
    param(
        [string]$Path,
        [int]$Count = 5
    )

    if (-not (Test-Path $Path)) { throw "Pfad nicht gefunden: $Path" }
    Get-ChildItem -Path $Path -File | Sort-Object LastWriteTime -Descending | Select-Object -First $Count
}

Export-ModuleMember -Function Get-FolderSize, Get-RecentFiles
```

- Manifest-Datei (Beispiel)
```
# InventoryTools.psd1
@{
  ModuleVersion = '1.0.0'
  RootModule = 'InventoryTools.psm1'
  FunctionsToExport = @('Get-FolderSize','Get-RecentFiles')
}
```

- Nutzung des Moduls
  - Manuelles Laden des Moduls:
```
Import-Module -Name ".\InventoryTools\InventoryTools.psm1"
Get-FolderSize -Path "C:\Temp"
Get-RecentFiles -Path "C:\Temp" -Count 10
```

  - Mit Manifest-Datei:
```
Import-Module -Name ".\InventoryTools\InventoryTools.psd1"
Get-FolderSize -Path "C:\Temp"
```

  - Überprüfen der exportierten Funktionen:
```
Get-Command -Module InventoryTools
```

- Vorteile des Modulsystems
  - Gesteigerte Wiederverwendbarkeit, klare API, Versionsverwaltung und einfache Verteilung.
  - Module können Abhängigkeiten deklarieren, Parametermodelle kapseln und die Wiederholung von Boilerplate-Code reduzieren.
  - Für die Produktivität empfiehlt sich die Nutzung eines Modul-Manifests, insbesondere beim Veröffentlichen oder Verteilen.

- Weiterführende Hinweise
  - Verwenden Sie Tests (Pester), um die Funktionen Ihres Moduls abzudecken.
  - Strukturieren Sie Module thematisch (Netzwerk, Dateioperationen, Logging, etc.).
  - Dokumentieren Sie Export-Funktionen in der psd1 oder über Hilfe-Kommentare innerhalb der psd1/psm1.

Dieses Kapitel zeigt, wie Funktionen, Skripte und Module zusammenwirken, um robuste, wiederverwendbare Automatisierungslösungen zu gestalten. Beginnen Sie mit einfachen Funktionen, erweitern Sie diese zu Skripten mit klaren Parameter-Sets und verpacken Sie schließlich Ihre Logik in Modulen, die Sie in verschiedenen Projekten wiederverwenden können.
## KAPITEL: Automatisierung und Aufgabenplanung

### 6.1 Geplante Aufgaben und Scheduling mit Task Scheduler

Die Geplante Aufgaben-Funktion von Windows ermöglicht es, PowerShell-Skripte oder andere Programme automatisiert zu bestimmten Zeiten oder Intervallen auszuführen. Sie adressiert zentrale Anforderungen der Automatisierung im täglichen Betrieb: regelmäßige Wartung, Datensicherung, Berichte oder Monitoring-Aufgaben. Im Gegensatz zu ad-hoc-Ausführungen per PowerShell-Konsole ermöglicht Task Scheduler eine robuste, wiederholbare und abgesicherte Ausführung mit Protokollierung, Benachrichtigung und geeigneter Benutzerberechtigungen.

Wichtige Begriffe und Konzepte:
- Trigger: Zeitpunkte oder Ereignisse, zu denen eine Aufgabe gestartet wird (z. B. täglich um 02:00, beim Anmelden eines Benutzers, beim Start des Systems).
- Aktion: Was die Aufgabe tatsächlich ausführt (Ausführung von PowerShell, Ausführung einer exe, Batch-Datei).
- Bedingungen: Zusätzliche Einschränkungen (Nur wenn Stromversorgung vorhanden, RunLevel, Netzverfügbarkeit).
- Laufwerk- und Benutzer-Kontext: Aufgaben können unter SYSTEM, einem bestimmten Benutzer oder mit höchsten Rechten laufen.
- Monitoring: Aufgabenstatus, Fehlercodes, Protokolle und Benachrichtigungen.

Vorgehen zur Einrichtung einer geplanten Aufgabe
- Planen Sie im Vorfeld Zweck, Häufigkeit, Eingaben und erwartete Ergebnisse der Aufgabe.
- Wählen Sie geeignete Trigger und definieren Sie die passende Aktion.
- Legen Sie Sicherheitsparameter fest (RunLevel, Benutzerkonto, Passwörter).
- Testen Sie die Aufgabe zunächst manuell, bevor Sie sie produktiv schalten.
- Überwachen Sie regelmäßig den Status der Aufgaben und legen Sie ggf. Benachrichtigungen fest.

Arten der Umsetzung
- GUI-basiert über Task Scheduler (Windows-Standardoberfläche) für schnelle Ersteinrichtung.
- Befehlszeilenbasierte Umsetzung mit schtasks.exe oder mit PowerShell Modulen wie ScheduledTasks.
- Kombinationslösung: Skripte erzeugen bzw. aktualisieren Aufgaben dynamisch basierend auf Umgebung oder Zeitplänen.

Beispiele
- Schnelle Erstellung mit der Befehlszeile:
```
schtasks /Create /TN "BackupCheck" /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\BackupCheck.ps1" /SC DAILY /ST 02:00 /RU SYSTEM /RL HIGHEST
```
- Saubere Erstellung mit PowerShell (empfohlen, wenn Sie Versionierung und Portabilität bevorzugen):
```
$trigger = New-ScheduledTaskTrigger -Daily -At 02:00
$action  = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Scripts\BackupCheck.ps1"
Register-ScheduledTask -TaskName "BackupCheck" -Trigger $trigger -Action $action -Description "Prüft tägliche Backups" -User "SYSTEM" -RunLevel Highest
```
- Einfache GUI-Schritte (kurz skizziert):
  - Task Scheduler öffnen
  - Aufgabe erstellen → Trigger festlegen (z. B. Täglich um 02:00)
  - Aktion hinzufügen (Programm/Script: PowerShell.exe, Argument: -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\BackupCheck.ps1)
  - Bedingungen und Sicherheit konfigurieren
  - Aufgabe speichern und testen

Wichtige Hinweise
- Kompatibilität: Prüfen Sie, ob Skripte auf dem Zielsystem ohne Benutzerinteraktion laufen können.
- Pfad- und Berechtigungsproblem vermeiden: Verwenden Sie explizite Pfade und bevorzugen Sie SYSTEM oder ein dediziertes Dienstkonto.
- Logging: Protokollieren Sie Ausgaben der Skripte, idealerweise in eine zentrale Logdatei oder in das Eventlog.
- Wiederherstellbarkeit: Halten Sie Versionen der Skripte in einer Versionsverwaltung und dokumentieren Sie Abhängigkeiten.

Kodierte Beispiele (Skriptdateien)
- Beispielinhalt einer Skriptdatei (C:\Scripts\BackupCheck.ps1):
```
# BackupCheck.ps1
# Prüft, ob das Backup innerhalb des letzten Tages erfolgt ist, und meldet ggf. Alarm
param(
  [int]$MaxAgeDays = 1,
  [string]$LogPath = "C:\Logs\BackupCheck.log",
  [string]$MailTo = "admin@example.com",
  [string]$SmtpServer = "smtp.local"
)

# Versuche, zuletzt erfolgreiches Backup-Status zu erfassen
$lastBackup = $null
try {
  $wbStatus = wbadmin get status 2>$null
  if ($wbStatus) {
    foreach ($line in $wbStatus) {
      if ($line -match "The backup completed successfully on\s+(.+)") {
        $lastBackup = [DateTime]::ParseExact($matches[1], "M/d/yyyy h:mm:ss tt", $null)
        break
      }
    }
  }
} catch {
  # Fehlerprotokollierung
}

# Fallback: Eventlog-Ansatz (optional)
if (-not $lastBackup) {
  $e = Get-WinEvent -LogName "Microsoft-Windows-WBEngine/Operational" -MaxEvents 50 | 
       Where-Object { $_.Message -like "*backup completed successfully*" } | Select-Object -First 1
  if ($e) { $lastBackup = $e.TimeCreated }
}

$now = Get-Date
$ageDays = $lastBackup ? ($now - $lastBackup).TotalDays : [double]::PositiveInfinity
$status = if ($lastBackup -and $ageDays -le $MaxAgeDays) { "OK" } else { "ALARM" }

$report = @"
Backup Check Report - $now
Letzte erfolgreiche Sicherung: $lastBackup
Alter der letzten Sicherung: {0:N2} Tage
Status: $status
"@ -f $ageDays

$report | Out-File -FilePath $LogPath -Encoding UTF8 -Append

if ($status -eq "ALARM") {
  try {
    Send-MailMessage -To $MailTo -From "noreply@local" -SmtpServer $SmtpServer -Subject "BackupCheck Alarm" -Body $report
  } catch {
    # Fehler beim Versenden des Alarm-E-Mails protokollieren
  }
}
```

Tabelle: Aufgaben-Referenz (Beispiel)
```
+--------------------------+-------------------------------------------+
| Feld                     | Bedeutung                                   |
+--------------------------+-------------------------------------------+
| Trigger                  | Zeitpunkt bzw. Ereignis, wann die Aufgabe   |
|                          | gestartet wird                                 |
| Aktion                   |Was ausgeführt wird (PowerShell, Programm)     |
| Bedingungen              | Zusatzbedingungen (Netzwerk, Akku; optional)  |
| Ausführungsbenutzer      | Konto, mit dem die Aufgabe läuft              |
| RunLevel                 | Höchste Berechtigungen (Highest)              |
| Protokollierung          | Speicherort der Logs                          |
+--------------------------+-------------------------------------------+
```

### 6.2 Remoting, Hintergrundjobs und Runspaces

PowerShell bietet mehrere Mechanismen, um Aufgaben asynchron oder remote auszuführen. Relevante Konzepte sind Remoting (fernbediente Befehlsausführung), Hintergrundjobs (asynchrone Ausführung innerhalb des gleichen Clients) sowie Runspaces (leichte, isolierte Ausführungskontexte zur Parallelisierung). Die richtige Wahl hängt von der Anforderung ab: Fernzugriff auf andere Systeme, gleichzeitige Abfragen mehrerer Hosts oder performante Parallelisierung innerhalb eines Hosts.

Remoting
- Grundidee: Befehle werden auf entfernten Computern ausgeführt, entweder über eine persistente Sitzung (New-PSSession) oder per Invoke-Command.
- Voraussetzungen: WinRM-Dienst auf Zielsystemen aktiv, Netzwerkkonfigurierung und ggf. übergehörigeAuthentifizierung (Kerberos, NTLM, oder Zertifikate).

Beispiele
- Aktivieren von Remoting auf dem Client (nur einmal erforderlich):
```
Enable-PSRemoting -Force
```
- Eine Remote-Sitzung zu Server01 eröffnen:
```
$session = New-PSSession -ComputerName Server01 -Credential (Get-Credential)
```
- Befehle remote ausführen:
```
Invoke-Command -Session $session -ScriptBlock { Get-Service | Where-Object {$_.Status -eq 'Running'} }
```
- Sitzung schließen:
```
Remove-PSSession -Session $session
```

Hintergrundjobs
- Hintergrundjobs ermöglichen das asynchrone Ausführen eines ScriptBlocks im lokalen Kontext, ohne die Konsole zu blockieren.
- Grundlegende Befehle:
```
$job = Start-Job -ScriptBlock { Get-Process | Where-Object {$_.CPU -gt 100} }
Receive-Job -Job $job -Wait -AutoRemoveJob
```
- Remote-Umgebungen: Invoke-Command unterstützt -AsJob, um entfernte Skripte asynchron zu starten:
```
Invoke-Command -ComputerName Server01 -ScriptBlock { Get-EventLog -LogName Application -Newest 50 } -AsJob
```

Runspaces
- Runspaces sind leichtgewichtige Ausführungskontexte innerhalb derselben Konsole, geeignet zur parallelen, lokalen Verarbeitung, ohne separate Prozesse oder Remoting zu eröffnen.
- Grundidee: Mehrere Runspaces in einem Pool, um Aufgaben gleichzeitig abzuwickeln, aber mit geringeren Informations- und Sicherheitsauflagen als Remoting.
- Einfache, kompakte Parallelisierung-Beispiele (konfigurierter Pool):
```
$servers = @("Srv01","Srv02","Srv03")
$rp = [runspacefactory]::CreateRunspacePool(2, 4)
$rp.Open()

$psList = foreach ($s in $servers) {
  $ps = [powershell]::Create()
  $ps.RunspacePool = $rp
  $ps.AddScript("Invoke-Command -ComputerName '$s' -ScriptBlock { Get-Service | Where-Object {$_.Status -eq 'Running'} }")
  $ps
}
foreach ($p in $psList) { $p.BeginInvoke() | Out-Null }
foreach ($p in $psList) { $p.EndInvoke($p.BeginInvoke()) ; $p.Dispose() }
$rp.Close(); $rp.Dispose()
```

Hinweise zur Praxis
- Remoting ist geeignet, wenn viele Hosts oder komplexe Remote-Operationen nötig sind, jedoch erfordert es sorgfältige Sicherheits- und Netzwerkplanungen.
- Hintergrundjobs eignen sich gut für einfache asynchrone Tasks auf dem lokalen Host; bei Remote-Aufgaben bevorzugen Sie Invoke-Command oder Remoting-Sessions.
- Runspaces sind ideal, wenn eng gesteuerte Parallelisierung innerhalb eines Scripts nötig ist, ohne Netzwerklatenz.

### 6.3 Praxisbeispiel: Routine-Backup-Check automatisieren

Ziel dieses Praxisbeispiels ist die automatische Prüfung, ob Backups regelmäßig und erfolgreich laufen, inklusive Alarmierung bei Abweichungen. Die Lösung besteht aus einem PowerShell-Skript (BackupCheck.ps1), das den letzten erfolgreichen Backup ermittelt, dessen Alter bewertet und bei Bedarf eine Benachrichtigung versendet. Die tägliche Ausführung erfolgt über eine geplante Aufgabe (siehe 6.1). Dieses Beispiel lässt sich auch auf spezifische Backup-Tools anpassen, indem man die Quelle der Erfolgsinformation entsprechend erweitert (wbadmin, Windows-Backup-Engine, Log-Dateien des Backup-Tools etc.).

Funktionsumfang des Skripts
- Ermittlung des letzten erfolgreichen Backups über wbadmin oder Event-Logs.
- Berechnung der Zeit seit dem letzten Backup.
- Generierung eines kurzen Berichts inklusive Status OK oder Alarm.
- Logging des Berichts in eine zentrale Datei.
- Alarmierung per E-Mail bei Alarm (z. B. Backup seit mehr als 1 Tag). 

Beispielhafter Skriptinhalt (BackupCheck.ps1)
```
<# 
BackupCheck.ps1
Automatisiert Prüfung des letzten Backups
Parameter:
  [int]$MaxAgeDays = 1
  [string]$LogPath = "C:\Logs\BackupCheck.log"
  [string]$MailTo = "admin@example.com"
  [string]$SmtpServer = "smtp.local"
#>

param(
  [int]$MaxAgeDays = 1,
  [string]$LogPath = "C:\Logs\BackupCheck.log",
  [string]$MailTo = "admin@example.com",
  [string]$SmtpServer = "smtp.local"
)

# 1) Letzten Backup ermitteln
$lastBackup = $null
try {
  $wbStatus = wbadmin get status 2>$null
  if ($wbStatus) {
    foreach ($line in $wbStatus) {
      if ($line -match "The backup completed successfully on\s+(.+)") {
        $lastBackup = [DateTime]::ParseExact($matches[1], "M/d/yyyy h:mm:ss tt", $null)
        break
      }
    }
  }
} catch { }

# 2) Eventlog-Fallback (optional)
if (-not $lastBackup) {
  $e = Get-WinEvent -LogName "Microsoft-Windows-WBEngine/Operational" -MaxEvents 50 | 
       Where-Object { $_.Message -like "*backup completed successfully*" } | Select-Object -First 1
  if ($e) { $lastBackup = $e.TimeCreated }
}

$now = Get-Date
$ageDays = $lastBackup ? ($now - $lastBackup).TotalDays : [double]::PositiveInfinity
$isOK = $lastBackup -and ($ageDays -le $MaxAgeDays)

# 3) Bericht erstellen
$statusStr = if ($isOK) { "OK" } else { "ALARM" }
$report = @"
Backup Check Report - $now
Letzte erfolgreiche Sicherung: $lastBackup
Alter der letzten Sicherung: {0:N2} Tage
Status: $statusStr
"@ -f $ageDays

# 4) Logging
$report | Out-File -FilePath $LogPath -Append -Encoding UTF8

# 5) Alarmierung
if (-not $isOK) {
  Send-MailMessage -To $MailTo -From "noreply@local" -SmtpServer $SmtpServer -Subject "BackupCheck Alarm" -Body $report
}
```

Plan zur Automatisierung
- Erstellen Sie eine geplante Aufgabe (siehe 6.1), die dieses Skript täglich ausführt, z. B. um 03:00 Uhr.
- Optional: Erweiterungen für mehrere Standorte oder unterschiedliche Backup-Ziele (logische Trennung nach Servern) durch Parametrisierung oder zentrale Konfigurationsdatei.
- Ergänzen Sie Tests: Führen Sie das Skript manuell aus, prüfen Sie Logs und E-Mail-Benachrichtigungen, und simulieren Sie einen Alarm, um die Robustheit zu sichern.

Beispiele für Aufgabenreferenzen
- Geplante Aufgabe zur täglichen Prüfung:
```
$trigger = New-ScheduledTaskTrigger -Daily -At 03:00
$action  = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Scripts\BackupCheck.ps1"
Register-ScheduledTask -TaskName "DailyBackupCheck" -Trigger $trigger -Action $action -RunLevel Highest -User "SYSTEM"
```

- Alternative GUI-Optionen: Wie in 6.1 beschrieben, kann die gleiche Logik über die Task Scheduler GUI umgesetzt werden, inklusive Berichts- und Alarmierungsoptionen.

Zusammenfassung
Dieses Kapitel hat die Grundlagen der Automatisierung mit Task Scheduler, Remote- und paralleler Ausführung sowie ein praxisnahes Beispiel zur Routine-Backup-Überprüfung vorgestellt. Die beschriebenen Konzepte ermöglichen es, Sicherheits- und Betriebsprozesse zuverlässig zu automatisieren, Fehler frühzeitig zu erkennen und die Betriebskontinuität zu erhöhen.
## KAPITEL: Debugging, Fehlerbehandlung und Logging

### 7.1 Fehlerbehandlung mit Try/Catch/Finally

In PowerShell erfolgt die Fehlerbehandlung überwiegend über die Strukturen Try, Catch und Finally. Wesentliche Konzepte sind:

- Nicht-terminierende Fehler vs. terminierende Fehler: Viele Cmdlets erzeugen standardmäßig nicht-terminierende Fehler. Um diese in einen Catch-Block zu leiten, muss man sie in der Regel mit -ErrorAction Stop oder durch entsprechende Einstellungen zu terminierenden Fehlern machen.
- Fehler-Action- und Präferenzen: Die automatische Behandlung von Fehlern kann über -ErrorAction, $ErrorActionPreference und ähnliche Präferenzen gesteuert werden.
- Catch-Labels: Mehrere Catch-Blöcke ermöglichen das Abfangen konkreter Ausnahmearten (z. B. FileNotFoundException) vor dem allgemeinen Catch.

Anwendungsbeispiele in sauber aufgebauten Skripten:

1) Einfaches Muster mit konkreten Ausnahmebehandlungen
```
try {
  Get-Content -Path $Path -ErrorAction Stop
} catch [System.IO.FileNotFoundException] {
  Write-Error "Datei nicht gefunden: $($_.Exception.Message)"
} catch [System.UnauthorizedAccessException] {
  Write-Error "Zugriff verweigert: $($_.Exception.Message)"
} catch {
  Write-Error "Unbekannter Fehler: $($_.Exception.Message)"
}
```

2) Eine Funktion mit Wiederholungslogik und Finally
```
function Copy-FileWithRetry {
  param(
    [string]$Source,
    [string]$Destination,
    [int]$Retries = 3
  )

  $attempt = 0
  $lastError = $null

  while ($true) {
    try {
      Copy-Item -Path $Source -Destination $Destination -ErrorAction Stop
      Write-Verbose "Kopiervorgang erfolgreich: $Source -> $Destination"
      return
    } catch [System.IO.FileNotFoundException] {
      Write-Error "Quelldatei nicht gefunden: $($_.Exception.Message)"
      return
    } catch [System.UnauthorizedAccessException] {
      Write-Error "Zugriff verweigert: $($_.Exception.Message)"
      return
    } catch {
      $lastError = $_.Exception
      $attempt++
      if ($attempt -ge $Retries) {
        Throw "Kopiervorgang fehlgeschlagen nach $Retries Versuchen. Grund: $($lastError.Message)"
      } else {
        Start-Sleep -Seconds 2
      }
    } finally {
      # Ressourcenbereinigung, falls verwendet
      Write-Verbose "Durchlaufangabe: Versuch $attempt von $Retries"
    }
  }
}
```

3) Wichtige Hinweise zur Praxis
- Catch-Listen sollten so gestaltet sein, dass spezifische Fehler zuerst abgefangen werden, bevor der generische Catch folgt.
- Verwenden Sie Throw, um in einem Catch eine neue, kontextreiche Fehlermeldung zu erzeugen oder die Ausführung weiterzugeben.
- Um Debugging-Informationen zu erhalten, können Write-Verbose oder Write-Information eingesetzt werden, wobei der Aufrufer -Verbose bzw. -Debug aktivieren muss.

Beispiel mit Auswertung von JSON-Inhalten
```
try {
  $raw = Get-Content -Path $JsonPath -ErrorAction Stop
  $data = $raw | ConvertFrom-Json -ErrorAction Stop
} catch [System.IO.FileNotFoundException] {
  Write-Error "JSON-Datei nicht gefunden: $($_.Exception.Message)"
} catch [System.Text.Json.JsonException] {
  Write-Error "Ungültiges JSON-Format: $($_.Exception.Message)"
} catch {
  Write-Error "Fehler beim Verarbeiten von JSON: $($_.Exception.Message)"
} finally {
  # Ressourcen freigeben, falls nötig
}
```

Best Practices
- Verwenden Sie -ErrorAction Stop, wenn Sie Fehler gezielt im Try/Catch behandeln möchten.
- Setzen Sie klare, fehlerorientierte Catch-Blöcke auf, statt eine generische Ausnahme zu erwarten.
- Loggen Sie Fehler (z. B. über eine zentrale Logging-Funktion) statt nur Write-Error, um später Analysen zu ermöglichen.

### 7.2 Debugging-Tools, Breakpoints und Diagnostik

Effektives Debugging in PowerShell basiert auf einem systematischen Vorgehen und dem Einsatz geeigneter Werkzeuge. Die wichtigsten Konzepte:

- Debugging-Umgebungen: Visual Studio Code (mit PowerShell-Erweiterung) ist heute die Standardumgebung. In älteren Setups dienen PowerShell ISE oder die Windows PowerShell-Konsole mit Breakpoints und Debug-Ausgaben.
- Breakpoints: Ermöglichen es, die Skriptausführung an bestimmten Stellen zu stoppen oder bei Variablen-Änderungen zu unterbrechen.
- Debug-Streams und Informationslevel: Write-Debug, Write-Verbose, Write-Information geben auf unterschiedlichen Informationsstufen Ausgaben aus. Nutzer können -Debug, -Verbose oder -Information aktivieren, um mehr Kontext zu erhalten.
- Diagnostische Befehle: Get-PSCallStack, Get-PSBreakpoint, Get-Error, Measure-Command, Test-Path, Get-Process u. v. m. helfen, Muster von Fehlern und Leistungsprobleme zu identifizieren.

Typische Debugging-Strategien
- Reproduzieren des Fehlers unter kontrollierten Bedingungen.
- Breakpoints setzen, um Variablenzustände im Verlauf der Ausführung zu beobachten.
- Den Call-Stack analysieren, um die Fehlerursache in der Aufrufkette zu lokalisieren.
- Leistungsprobleme durch Timing-Messungen identifizieren.

Geeignete Befehle und Beispiele

- Breakpoints setzen und verwalten
```
"ScriptPath.ps1" -Line 42
Set-PSBreakpoint -Script "C:\Scripts\ScriptPath.ps1" -Line 42
Set-PSBreakpoint -Script "C:\Scripts\ScriptPath.ps1" -Variable "$processed" -Mode Read
Set-PSBreakpoint -Script "C:\Scripts\ScriptPath.ps1" -Command 'Process-Item'
Get-PSBreakpoint
Disable-PSBreakpoint -Id 1
Remove-PSBreakpoint -Id 2
```

- Debug- und Verhaltenssteuerung
```
$DebugPreference = "Continue"
Write-Debug "Starte Debug-Ausgabe"

function Compute {
  param([int]$a, [int]$b)
  Write-Debug "Berechne $a + $b"
  return $a + $b
}
Compute -a 5 -b 7
```

- Debuggen in VS Code (allgemein)
```
- Öffnen Sie den Ordner mit dem Script
- Setzen Sie Breakpoints (Klick in die linke Randspalte)
- Start Debugging (F5) bzw. Debug-Panel verwenden
- Nutzen Sie Debug-Konsole, Lokale Variablen und Call Stack
```

- Diagnostik rund um Fehlersuche
```
Get-Error -Newest 5
Get-PSCallStack
$PSDebuggerContext = Get-PSBreakpoint
Measure-Command { & "C:\Scripts\MyScript.ps1" }
```

- Praktische Vorgehensweise
  - Beginnen Sie mit Write-Verbose/Write-Debug, um sanfte Diagnoseinformationen zu liefern.
  - Fügen Sie Breakpoints nur dort hinzu, wo die Logik komplex ist oder Fehler häufig auftreten.
  - Verwenden Sie gezielt Call-Stack-Informationen, um die Ursprünge fehlerhafter Aufrufe zu erkennen.

Diagnostischer Workflow (Beispiel)
- Wiederkehrendes Problem in einer Funktion analysieren:
  1) Reproduzieren und Breakpoint an der vermuteten Stelle setzen.
  2) Mit Write-Debug gezielt Informationen ausgeben.
  3) Call-Stack inspizieren, um den Kontext zu verstehen.
  4) Leistungsaspekte mit Measure-Command überprüfen.

Hinweise zur Praxis
- Vermeiden Sie unnötiges Debugging-Verlust von Performance, indem Sie Debug-Ausgaben nur während der Entwicklung aktivieren.
- Nutzen Sie -Verbose und -Debug als Standard-Optionen, damit Skripte in verschiedenen Umgebungen gut steuerbar bleiben.
- In VS Code werden Parameter wie -Verbose automatisch durch das Debugging-Panel gesteuert; nutzen Sie diese Option, um Informationen gezielt anzuzeigen.

### 7.3 Logging und Auditing (Praxisbeispiel)

Ziel eines robusten Logging-Ansatzes ist es, Zuverlässigkeit, Fehlersuche und Compliance zu unterstützen. Ein sinnvoller Logging-Stack umfasst Textlog-Dateien, optionale Windows-Ereignisprotokolle und eine klare Trennung der Log-Level. Typische Level sind DEBUG, INFO, WARNING, ERROR, sowie INFORMATION für Write-Information.

Beispielhafter logging-fokussierter Aufbau

- Zentral definierte Logging-Funktionen
```
# Logging-Helfer
Param([string]$LogPath)

function Write-Log {
  param(
    [string]$Level = "INFO",
    [string]$Message,
    [string]$LogPathArg = $LogPath
  )
  $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $line = "{0} [{1}] {2}" -f $timestamp, $Level, $Message
  Add-Content -Path $LogPathArg -Value $line
}
```

- Hauptskript mit Logging
```
param(
  [string]$Folder = ".",
  [string]$LogPath = ".\process.log"
)

if (-Not (Test-Path $LogPath)) {
  New-Item -Path $LogPath -ItemType File -Force | Out-Null
}

Write-Log -Level "INFO" -Message "Script gestartet: Folder=$Folder"

$processed = 0
foreach ($file in Get-ChildItem -Path $Folder -Filter "*.csv" -File) {
  try {
    Write-Log -Level "DEBUG" -Message "Verarbeite Datei: $($file.FullName)"
    $rows = Import-Csv -Path $file.FullName -ErrorAction Stop
    $count = $rows.Count
    # Beispielhafte Verarbeitung
    foreach ($row in $rows) {
      # Platzhalter für konkrete Verarbeitung
    }
    $processed++
    Write-Log -Level "INFO" -Message "Datei $($file.Name) verarbeitet, Zeilen=$count"
  } catch {
    Write-Log -Level "ERROR" -Message "Fehler beim Verarbeiten von $($file.FullName): $($_.Exception.Message)"
    # Optional: zusätzliches Auditing in Windows-Ereignisprotokoll
    try {
      Write-EventLog -LogName Application -Source "CSVProcessor" -EventId 1002 -EntryType Error -Message "Datei $($file.Name): $($_.Exception.Message)"
    } catch {}
  }
}

Write-Log -Level "INFO" -Message "Script beendet. Insgesamt verarbeitete Dateien: $processed"
```

- Windows-Ereignislog (Auditing im Betriebssystem)
```
# Erster Ausführungsschritt (Erstellung der Quelle, nur admin):
If (-Not (Get-EventLog -LogName Application -Source "CSVProcessor" -ErrorAction SilentlyContinue)) {
  New-EventLog -LogName Application -Source "CSVProcessor"
}

# Danach Ereignis schreiben (Beispiel im Fehlerfall bereits im Code)
Write-EventLog -LogName Application -Source "CSVProcessor" -EventId 1001 -EntryType Information -Message "Script gestartet"
```

- Logrotation und Sicherheit
```
# Einfache Rotation (reset, wenn Dateigröße überschritten)
$maxSize = 10MB
if ((Get-Item $LogPath).Length -gt $maxSize) {
  Move-Item $LogPath -Destination ("{0}.bak" -f $LogPath)
  New-Item -Path $LogPath -ItemType File | Out-Null
}
```

- Hinweise zur Praxis
  - Vermeiden Sie das Speichern sensibler Informationen in Logs (Credentials, Tokens, Klartext-Passwörter).
  - Verwenden Sie strukturierte Logs, idealerweise mit Feldern wie Zeitstempel, Level, Quelle, Message.
  - Implementieren Sie eine einfache Rotation, damit Logs nicht unendlich groß werden.
  - Kombinieren Sie Dateilog mit Windows-Ereignisprotokoll bei sicherheitsrelevanten Vorgängen oder Auditing-Anforderungen.

- Tabellen (als Monospace-Block)
```
+------------+----------------------------------+
| Level      | Bedeutung                        |
+------------+----------------------------------+
| DEBUG      | Detaillierte Diagnostik-Infos     |
| INFO       | Normaler Betriebsstatus            |
| WARNING    | Potenziell problematische Situation  |
| ERROR      | Laufzeitfehler oder Ausnahmen      |
| INFORMATION| Allgemeine Information (Write-Information) |
+------------+----------------------------------+
```

- Praktische Hinweise zur Umsetzung
  - Verwenden Sie Write-Verbose/Write-Debug auf Entwicklungsständen und schalten Sie diese Informationen in der Produktivumgebung gemäß Bedarf aus.
  - Loggen Sie immer eine Initial- und Abschlussmeldung, damit Auditierbarkeit und Nachvollziehbarkeit sichergestellt sind.
  - Nutzen Sie, wenn möglich, zwei parallel laufende Logs: eine Textdatei für Menschen und eine strukturierte Form (z. B. JSON) für automatisierte Analysen.
## Sicherheit, Best Practices und Testing

### 8.1 Execution Policy, Signieren und sichere Skript-Verwaltung

PowerShell verfolgt ein Sicherheitsmodell, das über die reine Funktionsfähigkeit hinausgeht und das ungewollte Ausführen von Skripten verhindern soll. Zentraler Bestandteil ist die Execution Policy, die festlegt, unter welchen Bedingungen Skripte ausgeführt werden dürfen. Die Policy wirkt pro Benutzer- oder Maschinenkontext und lässt sich auch zeitweilig auf Prozessebene einstellen. Typische Werte sind Restricted, AllSigned, RemoteSigned, Unrestricted, Bypass und Undefined. Die Wahl der Policy hängt von der Sicherheitsstrategie der Organisation ab: Im produktiven Umfeld wird oft AllSigned oder RemoteSigned bevorzugt, um sicherzustellen, dass nur signierte Skripte ausgeführt oder Skripte, die lokal erstellt wurden, noch laufen dürfen.

Beispiele zur Abklärung und Änderung der Policy:
```
Get-ExecutionPolicy -List
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
Hinweis: Für Systemwechsel oder globale Änderungen sind Administratorrechte erforderlich (Scope LocalMachine). In vielen Umgebungen ist es sinnvoll, die policy über Gruppenrichtlinien zentral zu steuern.

Signieren von Skripten erhöht die Vertrauenswürdigkeit erheblich. Dazu benötigt man ein Code-Signing-Zertifikat aus einer vertrauenswürdigen CA oder einer internen PKI. Signierte Skripte lassen sich mit dem Authenticode-Standard verifizieren und müssen vor der Ausführung entsprechend gültig sein.
```
# Skript signieren (Beispiel)
$cert = Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object { $_.Subject -like '*Code Signing*' } | Sort-Object NotAfter -Descending | Select-Object -First 1
Set-AuthenticodeSignature -FilePath .\Deploy.ps1 -Certificate $cert

# Signatur prüfen
(Get-AuthenticodeSignature -FilePath .\Deploy.ps1).Status
```
Vor der Ausführung eines Skripts kann eine zusätzliche Sicherheitsprüfung erfolgen:
```
if ((Get-AuthenticodeSignature -FilePath .\Deploy.ps1).Status -eq 'Valid') {
    .\Deploy.ps1
} else {
    Write-Error 'Signatur ungültig oder fehlend.'
}
```

Für die sichere Skript-Verwaltung empfiehlt sich eine mehrstufige Strategie:
- Signieren aller Skripte, die außerhalb des Editors erstellt wurden.
- Nutzung einer Versionskontrolle mit freigegebenen Signatur-Richtlinien.
- Einsatz von AppLocker oder WDAC, um Script-Hashes, -Blocklisten oder -Pfadregeln durchzusetzen.
- Verifizierung von Skripten vor der Ausführung und-Verteilung über sichere Kanäle.

Praktische Grundregeln:
- Verhindern Sie das automatische Ausführen unsignierter Skripte.
- Signieren Sie regelmäßig Ihre Skripte bei jeder Änderung.
- Verwenden Sie dedizierte Administrationskonten und beschränkte Ausführungsrechte in Produktivumgebungen.
- Dokumentieren Sie Ihre Signatur-Policy und überprüfen Sie diese regelmäßig.

### 8.2 Sicheres Remoting, WinRM und Just Enough Administration

PowerShell-Remoting via WinRM ermöglicht die zentrale Verwaltung vernetzter Systeme. Gleichzeitig erhöht es das Risiko, wenn es nicht korrekt abgesichert ist. Wichtige Grundprinzipien umfassen sichere Verbindungen (TLS), starke Authentifizierung (Kerberos/NTLM) und minimale, rollenbasierte Rechtevergabe. Im Zuge der Praxis sollten Sie Remoting nur in abgeschotteten oder gemanagten Zonen betreiben und unnötige offene Angriffsflächen vermeiden.

Erste Schritte zur Aktivierung und Absicherung:
```
Enable-PSRemoting -Force
Set-WSManQuickConfig -Force
```
Überprüfen Sie die WinRM-Listener und setzen Sie TLS-Basiskonfigurationen, um unverschlüsselte Verbindungen zu verhindern:
```
Get-ChildItem WSMan:\localhost\Listener
```
Für eine sicherere Authentifizierung und Zugriffskontrolle ist Kerberos in Domänenumgebungen praktisch. In gemischten Umgebungen empfehlen sich TLS-basierte Verbindungen mit Zertifikaten. Grundsätzlich sollten Basic-Auth deaktiviert und nur Kerberos/NTLM-Transparenz verwendet werden:
```
Set-Item -Path WSMan:\localhost\Service\Auth\Basic -Value $false
```

Just Enough Administration (JEA) bietet eine sichere Möglichkeit, Administratoraufgaben zu delegieren, ohne Vollzugriff auf das System zu gewähren. JEA kapselt Rollen, Befuglichkeiten und zulässige Cmdlets in eine Endpunktkonfiguration, sodass Benutzer nur die vorgesehenen Aktionen durchführen können. Wichtige Schritte umfassen das Erstellen von Endpunktdateien, Rollen und die Registrierung des Endpunkts:

```
# Remoting aktivieren
Enable-PSRemoting -Force

# Endpunktkonfigurationsdatei erstellen (Beispiel)
New-PSSessionConfigurationFile -Path C:\Jea\MyJea.pssc -SessionType RestrictedRemoteServer -RunAsVirtualAccount
Register-PSSessionConfiguration -Name 'MyJea' -Path C:\Jea\MyJea.pssc -Force

# Rolle (Role Capability) erstellen (Beispiel)
New-PSRoleCapabilityFile -Path C:\Jea\RoleCapabilities\Diagnostics.psrc -VisibleCmdlets 'Get-Process','Get-Service'
```

Verbindungsbeispiele:
```
$cred = Get-Credential
Enter-PSSession -ComputerName server01 -ConfigurationName MyJea -Credential $cred
```

Beim Einsatz von JEA gilt es, sorgfältig zu definieren, welche Cmdlets sichtbar sind, welche Provider genutzt werden dürfen und wie viele Ressourcen der Endpunkt verwenden darf. Dokumentation, regelmäßige Audits und ein klar definiertes Zugriffskonzept sind dabei unabdingbar. Zudem sollten Sie Prozesse implementieren, die eine zeitnahe Reaktion auf Missbrauch oder Fehlfunktionen ermöglichen (Audit-Logs, Transkriptierung, Alarmierung).

### 8.3 Pester-Tests und Qualitätskriterien (Praxisbeispiel)

Pester ist das integrale Test-Framework für PowerShell. Es unterstützt Unit-, Integrations- und Akzeptanztests und fördert durch describe/context/it-Strukturen eine lesbare, klare Testlogik. Aus Sicht der Softwarequalität helfen Pester-Tests, Regressionen zu verhindern, API-Verträge zu sichern und sicherzustellen, dass Skripte erwartungsgemäß funktionieren, bevor sie in Produktion gehen.

Typische Testarten:
- Unit-Tests: Kapseln einzelne Funktionen, prüfen Randfälle und fehlerhafte Eingaben.
- Integrationstests: Prüfen Zusammenspiel mehrerer Module oder Scriptabschnitte.
- Smoke-Tests: Schnelle Prüfungen zentraler Funktionen, bevor komplexe Deployments erfolgen.

Praxisbeispiel 1: Kleine Hilfsfunktion testen
- Erstellen Sie eine einfache Funktion in einer Moduldatei (Utilities.psm1):
```
function Add-Numbers { param([int]$A, [int]$B) return $A + $B }
Export-ModuleMember -Function Add-Numbers
```

- Schreiben Sie dazu passende Tests:
```
# Tests/Utilities.Tests.ps1
Describe 'Add-Numbers' {
  It 'Addiert zwei Zahlen korrekt' {
     Add-Numbers -A 5 -B 7 | Should -Be 12
  }
  It 'Wirft keine Fehler bei gültiger Eingabe' {
     { Add-Numbers -A 0 -B 0 } | Should -Not -Throw
  }
}
```

Praxisbeispiel 2: Umfangreicheres Beispiel mit Get-FileHash
- Testdatei:
```
# Tests\Hash.Tests.ps1
Describe 'Get-FileHash' {
  It 'Gibt einen Hash für eine bekannte Datei zurück' {
     $hash = Get-FileHash -Algorithm SHA256 -Path 'C:\Windows\explorer.exe'
     $hash.Hash | Should -Not -BeNullOrEmpty
  }
  It 'Wird Fehler erzeugen bei ungültigem Pfad' {
     { Get-FileHash -Algorithm SHA256 -Path 'C:\NoSuchPath.exe' } | Should -Throw
  }
}
```

- Ausführung:
```
# Module oder Skript laden, Tests ausführen
Invoke-Pester -Path .\Tests
```

Empfohlene Qualitätskriterien für Tests:
- Isolierte, deterministische Tests mit definierten Eingaben.
- Vollständige Abdeckung der Kernlogik, inklusive Randfällen.
- Schnelle Ausführung, damit häufiges Ausführen praktikabel bleibt.
- Reproduzierbare Ergebnisse unabhängig von Uhrzeit oder Umgebung.
- Kontinuierliche Integration, z. B. eigenständige Pipelines, die bei Push-Events laufen.

Durch diese Praxis wird ein robustes Sicherheits- und Qualitätsfundament geschaffen: Signierte Skripte schützen vor Manipulation, sicheres Remoting beschränkt administrative Fähigkeiten auf das Notwendige, und Pester-Tests sichern die Stabilität der Automatisierung über den gesamten Lebenszyklus hinweg.
## KAPITEL: Fortgeschrittene Themen und Profi-Muster

### 9.1 Observability und fortgeschrittene Debugging-Techniken

Observability bedeutet, dass ein System aus seinen Metriken, Logs und Traces mitteilen kann, was intern geschieht. In PowerShell-Umgebungen ist dies essenziell, um Skripte zuverlässig zu betreiben, Fehler schnell zu lokalisieren und Performance-Engpässe zu erkennen. In diesem Abschnitt werden Konzepte, Best Practices und konkrete Techniken vorgestellt, mit denen fortgeschrittene Anwender robuste, nachvollziehbare Automatisierungen erstellen.

Grundlegende Konzepte
- Logs: Strukturiertes, maschinenlesbares Protokollieren von Ereignissen, Fehlern und Warnungen.
- Traces: Feinkörnige Aufzeichnung der Ausführungspfad einer Funktion oder eines Skripts (Call Stack, Funktionsaufrufe).
- Metriken: Zeitmessung, Ressourcennutzung (CPU, Arbeitsspeicher), Fehlerraten.
- Observability-Pipelines: Logs in Dateien, Datenbanken, oder zentrale Logging-Dienste pushen; Optionales Parsing/Filterung mit Skripten.

Fortgeschrittene Techniken
- Strukturierte Protokollierung (JSON-Lines)
  - Vorteile: Leichte Aggregation, Filterung und Suche mit Logging-Tools.
  - Vorgehen: Jede Logzeile als JSON-Objekt speichern.
- Timing und Performance-Metriken
  - Messung von Abschnitten mit Stopwatches oder Measure-Command.
  - Beispiel: Zeitmessung von kritischen Operationen, um Flaschenhälse zu identifizieren.
- Fehlerabsorber und resiliente Muster
  - Try/Catch/Finally sowie Trap nutzen, um Ressourcen freizugeben und konsistente Zustände sicherzustellen.
  - Verwendung von -ErrorAction SilentlyContinue in kontrollierten Fällen vermeiden; stattdessen klare Fehlerpfade definieren.
- Debugging-Streams und Breakpoints
  - Set-PSBreakpoint auf Cmdlet-, Funktions- oder Zeilenebene.
  - Set-PSDebug -Trace 1 oder -Trace 2 für Zeilen- bzw. Funktionsaufruf-Trace.
  - $DebugPreference, $VerbosePreference und Write-Verbose/Write-Debug gezielt einsetzen.
- Transkription und Laufzeitkontext
  - Start-Transcript aktiviert Protokollierung der gesamten Sitzungen; geeignet für Audits, weniger für fortlaufende Produktion.

Konkrete Implementierungsideen
- Zentrales Log-Modul
  - Zentrale Log-Datei pro Skriptlauf, mit rotiertem Dateinamen.
  - Level-System (INFO, WARN, ERROR, DEBUG).
- Interner Health-Check
  - Am Ende jeder größeren Operation eine Health-Check-Logik einbauen (z. B. Prüfung von Dateien, Verzeichnissen, Diensten).
- Observability in Funktionen
  - Jede Funktion loggt Ein- und Ausgabewerte (anonymisiert, falls erforderlich) sowie Ausführungsdauer.
- Beispiel: Strukturiertes Logging mit JSON
```
```
```
# Von Ihnen gewünschter Code hier eingefügt
```
```
Beispiel: Einfaches Observability-Demo-Skript
```
```
```

Praxisbeispiele
- Beispiel 1: Logging-Helper und Timer
```
```
```

- Beispiel 2: Breakpoint-gestützte Fehleranalyse
```
```

Praxisleitfaden
- Beginnen Sie mit einem kleinen, klaren Logging-Format und erweitern Sie schrittweise.
- Verwenden Sie optionale Parameter wie -Verbose und -Debug dort, wo es sinnvoll ist, statt globale Änderungen am Skript vorzunehmen.
- Dokumentieren Sie Ihre Observability-Strategie im Repository-Readme (Logpfade, Log-Level, Rotationspolitik).

Zusammenfassung
Fortgeschrittene Observability in PowerShell bedeutet, klare, strukturierte Protokolle, reproduzierbare Trace-Informationen und gezielte Debugging-Muster in den Arbeitsfluss zu integrieren. Durch gut gestaltete Logik, Logging-Level und robuste Fehlerbehandlung erhöhen Sie Wartbarkeit, Stabilität und Vertrauen in Ihre Automatisierungen.

Code- und Beispiel-Schnipsel dienen der Illustration und sollten je nach Anwendungsfall angepasst werden. Achten Sie darauf, sensible Informationen vor der Protokollierung zu entschärfen.

### 9.2 Desired State Configuration (DSC) Grundlagen

Desired State Configuration (DSC) ist ein deklarativer Ansatz zur Konfigurationsverwaltung unter Windows. Anstatt prozedurale Schritte zu codieren, beschreibt DSC den gewünschten Systemzustand und lässt das System selbstständig die notwendigen Schritte durchführen, um diesen Zustand zu erreichen. Das Modell basiert auf Konfigurationen, MOF-Dateien (Managed Object Format) und dem Local Configuration Manager (LCM).

Zentrale Konzepte
- Konfiguration (Configuration): Ein deklarativer Block, der den gewünschten Zustand beschreibt, z. B. Installationen, Dateisysteme, Dienste.
- Node: Die Zielmaschine(n), auf denen die Konfiguration angewendet wird.
- Ressourcen (Resources): Bausteine, die konkrete Zustände definieren, z. B. File, Service, WindowsFeature, Registry, Package.
- MOF-Dateien: Kompilierte Repräsentationen der Konfiguration für jeden Node.
- LCM: Local Configuration Manager – travel-Behind-Service, der MOF-Dateien ausführt, Veränderungen überwacht und den Zielzustand aufrechterhält (Pull- oder Push-Modell).

Arbeitsablauf
1. Schreiben einer DSC-Konfiguration (Configuration-Block).
2. Kompilieren der Konfiguration in MOF-Dateien.
3. Anwenden der MOF-Dateien mit Start-DscConfiguration.
4. Prüfen des aktuellen Zustands mit Get-DscConfiguration bzw. Test-DscConfiguration.
5. Langfristige Aufrechterhaltung via LCM-Konfiguration.

Wichtige Ressourcen und Grundlagen
- Eingebaute Ressourcen: File, Service, WindowsFeature, Registry, Package, Environment, User, Group, Script.
- Import-DscResource: Laden externer Ressourcen aus Modulen wie xDSCResources.
- Meta-Konfiguration oder LCM-Einstellungen: Ensures, RebootOnDisruptiveChange, ConfigurationMode, ConfigurationModeFrequencySeconds.
- Test-DscConfiguration und Get-DscConfigurationStatus helfen beim Monitoring des DSC-Laufes.

Grundlegendes Beispiel: Web-Server mit DSC
- Ziel: IIS installieren, Webseiten-Verzeichnis erstellen und eine Standardindex-Datei ablegen.
```
```
```
# Datei: WebServerConfig.ps1
Configuration WebServerConfig {
  Import-DscResource -ModuleName PSDesiredStateConfiguration
  Node "localhost" {
    WindowsFeature IIS {
      Name = "Web-Server"
      Ensure = "Present"
    }

    File DefaultSiteDir {
      DestinationPath = "C:\inetpub\wwwroot"
      Type = "Directory"
      Ensure = "Present"
    }

    File WelcomeIndex {
      DestinationPath = "C:\inetpub\wwwroot\index.html"
      Contents = "<html><body><h1>DSC Web-Server</h1></body></html>"
      Ensure = "Present"
    }
  }
}
```

Kompilieren und Anwenden
```
```
```
WebServerConfig
```
```
```
# Pfad der MOF-Dateien anlegen (Standardpfad)
```
```
```
$OutputPath = "C:\DSC\WebServer"
```
```
```
# MOF-Dateien erzeugen
```
```
```
WebServerConfig -OutputPath $OutputPath
```
```
```
# Anwenden der MOF-Dateien
```
```
```
Start-DscConfiguration -Path $OutputPath -Wait -Verbose -Force
```
```
```
# Status prüfen
```
```
```
Get-DscConfigurationStatus
```
```

Best Practices und Hinweise
- Idempotenz sicherstellen: DSC soll wiederholbare Ergebnisse liefern, unabhängig von der Häufigkeit der Anwendung.
- Fehlerdiagnose: Test-DscConfiguration vor Start-DscConfiguration verwenden, um zu prüfen, ob der gewünschte Zustand erreichbar ist.
- Ressourcenwahl: Verwenden Sie robuste, gut unterstützte Ressourcen; externen Ressourcen nur aus vertrauenswürdigen Quellen nutzen.
- Sicherheit: MOF-Dateien können sensible Details enthalten; schützen Sie deren Zugriff, insbesondere in geteilten Repositorien.
- Drift-Management: Nutzen Sie ConfigurationModeFrequencySeconds und ConfigurationMode, um Drift im System zu minimieren.

Zusammenfassung
DSC bietet eine robuste, deklarative Methode zur Verwaltung von Konfigurationen auf Windows-Systemen. Durch klare Zustandsdefinitionen, den Einsatz von Ressourcen und den LCM-Mechanismen lassen sich Systeme zuverlässig in den gewünschten Zustand versetzen und dort halten.

### 9.3 Praxisprojekt: End-to-End Verwaltungs-Skriptpaket (Praxisbeispiel)

Ziel dieses Praxisprojekts ist die Entwicklung eines modularen End-to-End-Verwaltungspakets, das Routineaufgaben strukturiert übernimmt. Das Paket soll eine zentrale Logging-Komponente, Fehlerbehandlung, Wiederholungslogik und modulare Tasks enthalten. Es eignet sich sowohl für einzelne Hosts als auch für kleine Infrastrukturumgebungen mit mehreren Maschinen.

Projektstruktur (Vorschlag)
- src/
  - Utilities.psm1: Hilfsfunktionen, Logging, Fehlerbehandlung, Versionierung
  - Inventory.ps1: System- und Anwendungsinventar
  - Tasks.ps1: Wiederverwendbare Aufgaben (Installationen, Dateien, Dienste)
  - Orchestrator.ps1: Hauptsteuerung, Laden von Modulen, Ausführen von Tasks gemäß Manifest
- manifests/
  - deploy.json: JSON-Wafer mit Ziel-Tasks und Parametern
- logs/
- README.md

Beispielhafte Funktionsbausteine
- Logging-Modul
```
```
```
```

- Inventar-Funktion
```
```

- Task-Funktionen
```
```

- Orchestrator (Main)
```
```

Beispielmanifest (JSON)
```
```

Durchführungsschritte
1. Vorbereitung
   - Legen Sie die Projektstruktur an.
   - Implementieren Sie Utilities.psm1 mit Logging, Fehlerbehandlung und robusten Interfaces.
2. Manifest definieren
   - Erstellen Sie deploy.json mit Zielen, Tasks und Parametern.
3. Orchestrator implementieren
   - Orchestrator.ps1 lädt Utilities, liest das Manifest, und ruft je Task-Funktion auf.
   - Implementieren Sie eine einfache Retry-Logik bei Fehlern.
4. Test und Validierung
   - Führen Sie den Orchestrator mehrfach aus, prüfen Sie Logs.
   - Verifizieren Sie idempotente Ergebnisse (erneute Ausführung verändert nichts Unerwartetes).
5. Einsatzszenarien
   - Lokale Automatisierung, Remote-Verwaltung per WinRM/PowerShell Remoting, oder als CI/CD-Teil.

Beispiel-Umsetzung: Orchestrator.ps1 (Vereinfachung)
```
```
```
# Orchestrator.ps1
Import-Module "$PSScriptRoot\src\Utilities.psm1"

# Manifest laden
$ManifestPath = "$PSScriptRoot\manifests\deploy.json"
$manifest = Get-Content -Path $ManifestPath -Raw | ConvertFrom-Json

foreach ($target in $manifest.Targets) {
  foreach ($task in $target.Tasks) {
     switch ($task.Type) {
       "InstallFeature"  { Install-Feature -Name $task.Name -ComputerName $target.ComputerName }
       "CreateDirectory" { Ensure-Directory -Path $task.Path -ComputerName $target.ComputerName }
       "DeployFile"      { Deploy-File -Source $task.Source -Destination $task.Destination -ComputerName $target.ComputerName }
       default { Write-Log "Unbekannter TaskType '$($task.Type)'" -Level "WARN" }
     }
  }
}
```

Beispiel-Funktionen (Auszug)
```
```
```
function Install-Feature {
  param([string]$Name, [string]$ComputerName = "localhost")
  $script = {
    param($f)
    if (Get-WindowsFeature -Name $f | Where-Object { $_.InstallState -eq "Installed" }) { return }
    Install-WindowsFeature -Name $f -IncludeManagementTools
  }
  if ($ComputerName -eq "localhost") {
    & $script $Name
  } else {
    Invoke-Command -ComputerName $ComputerName -ScriptBlock $script -ArgumentList $Name
  }
}
```

```
function Ensure-Directory {
  param([string]$Path, [string]$ComputerName = "localhost")
  $script = {
    param($p)
    if (-Not (Test-Path -Path $p)) { New-Item -Path $p -ItemType Directory -Force | Out-Null }
  }
  if ($ComputerName -eq "localhost") { & $script $Path } else { Invoke-Command -ComputerName $ComputerName -ScriptBlock $script -ArgumentList $Path }
}
```

Beispiel-Manifest (deploy.json)
```
```
{
  "Targets": [
    {
      "ComputerName": "localhost",
      "Tasks": [
        {"Type": "InstallFeature", "Name": "Web-Server"},
        {"Type": "CreateDirectory", "Path": "C:\\Data\\Logs"},
        {"Type": "DeployFile", "Source": "C:\\Artifacts\\index.html", "Destination": "C:\\inetpub\\wwwroot\\index.html"}
      ]
    }
  ]
}
```

Best Practices
- Modulares Design: Jede Funktion ist klein, testbar und idempotent.
- Logging: Nutzen Sie das zentrale Utilities-Modul für konsistente Log-Ausgabe.
- Fehlerbehandlung: Retry-Logik, klare Fehlermeldungen und Stopbedingungen.
- Sicherheit: Sensible Pfade, Credentials und Tokens sicher handhaben (Secret-Management, z. B. Windows Credential Manager, Azure Key Vault sofern verfügbar).
- Tests: Unit-Tests mit Pester für Kernfunktionen; Integrationstests mit simulierten Tasks.

Zusammenfassung
Dieses Praxisprojekt demonstriert, wie man ein End-to-End-Verwaltungspaket modular, testbar und erweiterbar aufbaut. Die Trennung von Utility-Funktionen, Task-Logik und Orchestrator-Logik erleichtert Wartung, Wiederverwendung und Erweiterung. Für den Einsatz in produktiven Umgebungen empfiehlt es sich, das Paket schrittweise zu erweitern, umfangreiche Logging- und Monitoring-Komponenten hinzuzufügen und Sicherheitsaspekte konsequent zu berücksichtigen.
